<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="conteudo-principal" class="error-page"><div class="shell"><p class="error-page__code">404</p><h1><?php esc_html_e( 'O caminho que você procura não está por aqui.', 'captec-asfaltos' ); ?></h1><p><?php esc_html_e( 'Volte à página inicial ou envie sua solicitação para que possamos ajudar.', 'captec-asfaltos' ); ?></p><?php echo captec_site_button_markup( 'not_found_home', array( 'label' => 'Ir para Quem somos', 'action' => 'url', 'url' => home_url( '/' ), 'style' => 'yellow' ), array( 'icon' => 'arrow-right' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></main>
<?php get_footer();

# CAPTEC Asfaltos — Tema WordPress

Tema institucional customizado para a CAPTEC Asfaltos. Foi construído sem page builder, com HTML semântico, CSS e JavaScript locais, tipos de conteúdo próprios e uma área administrativa pensada para atualização por equipes não técnicas.

> **Importante:** contatos, URLs sociais, estados atendidos, indicadores, clientes, certificações, unidades, frota e anos de mercado não foram inventados. Os campos que dependem de validação da empresa começam vazios ou neutros e devem ser preenchidos antes da publicação.

## Instalação

1. Compacte a pasta `captec-asfaltos-theme` em `.zip` (ou use o arquivo `captec-asfaltos-theme.zip` entregue junto ao projeto).
2. No WordPress, acesse **Aparência > Temas > Adicionar novo > Enviar tema**.
3. Envie o ZIP, instale e ative.
4. Em **Configurações > Leitura**, selecione uma página estática como página inicial. O arquivo `front-page.php` será usado nela.
5. Em **Aparência > Personalizar > CAPTEC — Configurações**, preencha todos os itens institucionais.

## O que pode ser administrado

### Personalizar > CAPTEC — Configurações

- Hero: título, texto, poster e vídeo de fundo.
- Quem somos: etiqueta, textos, imagem e botões globais correspondentes.
- Trabalhe conosco: textos, e-mail de currículos e botão correspondente.
- Página principal **Quem somos**, que reúne o institucional, Aplicações, Diferenciais e Processo; além de páginas individuais para Produtos, Unidades, Cobertura, Conteúdos, Trabalhe conosco e Cotação.
- Contatos: telefone, WhatsApp, e-mail, Instagram, LinkedIn, Google Maps, localização e e-mail de destino das cotações.
- Mapa de cobertura: estados em destaque e mensagem exibida após selecionar um estado.
- Indicadores: os cinco números e rótulos, além de estados a destacar no mapa.
- Privacidade: URLs da Política de Privacidade e Política de Cookies.
- Integrações: IDs de Google Analytics 4 e Meta Pixel.

As tags de Analytics e Meta Pixel só são carregadas após a pessoa aceitar cookies analíticos no banner LGPD.

### Produtos CAPTEC

O menu **Produtos CAPTEC** permite criar ou substituir os cards da Home. Cada produto aceita:

- Título;
- imagem destacada;
- categoria curta;
- descrição resumida;
- aplicações;
- arquivo de ficha técnica selecionado da Biblioteca de Mídia.

Se nenhum produto for criado, o tema apresenta os sete itens solicitados: CAP 30/45, CAP 50/70, RR-1C, RR-2C, RL-1C, EAI e Asfaltos Modificados. Ao cadastrar produtos próprios, eles passam a ser exibidos no lugar dos exemplos. Use **Atributos > Ordem** para controlar a ordem dos cards.

### Aplicações CAPTEC

O menu **Aplicações CAPTEC** permite criar e ordenar os cards de aplicação. Use uma imagem horizontal destacada e preencha a linha de apoio. Sem itens cadastrados, o tema exibe os oito contextos definidos no briefing.

### Cotações

O formulário é nativo do tema e inclui:

- nonce WordPress e honeypot anti-spam;
- limite simples de envio por origem (2 minutos);
- validação de campos obrigatórios;
- upload opcional de PDF, Office, JPG e PNG até 10 MB;
- armazenamento como registro privado em **Cotações**;
- envio por e-mail para o endereço configurado no Personalizar.

Para maior confiabilidade na entrega de e-mails, configure um serviço SMTP transacional no WordPress antes de publicar. Como os envios podem incluir dados pessoais, defina uma rotina de retenção e exclusão dos registros em **Cotações**.

## Menu

Crie um menu em **Aparência > Menus** e atribua-o à localização **Menu principal**. Para a Home one-page, use links personalizados como:

- `/` — Quem somos
- `/produtos/`
- `/unidades/`
- `/cobertura/`
- `/blog/`
- `/trabalhe-conosco/`
- `/cotacao/`

Enquanto o menu não estiver configurado, o tema exibe uma navegação de fallback com esses mesmos destinos. As antigas URLs `/empresa/`, `/aplicacoes/` e `/diferenciais/` redirecionam para Quem somos.

## Conteúdo editorial

A área de Blog usa os posts nativos do WordPress. Quando ainda não existem posts publicados, a Home apresenta apenas sugestões de pautas, sem apresentá-las como artigos publicados:

1. Diferença entre CAP e Emulsão;
2. O que é RR-1C;
3. Como escolher um fornecedor de asfalto;
4. Como funciona a logística dos asfaltos;
5. Qual produto utilizar na pintura de ligação.

## Políticas e LGPD

Antes da publicação, crie as páginas **Política de Privacidade** (slug `politica-de-privacidade`) e **Política de Cookies** (slug `politica-de-cookies`) no WordPress, revise o conteúdo com responsável jurídico e informe suas URLs em **Personalizar > CAPTEC — Configurações > Privacidade e LGPD**.

O banner implementa escolha entre “Aceitar todos” e “Somente essenciais”. O consentimento é armazenado localmente no navegador. O tema não ativa GA4 ou Meta Pixel sem a escolha de cookies analíticos.

## Desempenho e SEO

- HTML semântico, acessível e responsivo;
- imagens com `loading="lazy"` e `decoding="async"` fora do hero;
- vídeo de hero local com `preload="metadata"` e poster;
- preload da imagem de hero;
- SVGs e ícones locais, sem biblioteca de ícones remota;
- mapa do Brasil local;
- metatags e JSON-LD `Organization` leves;
- compatibilidade com Yoast, Rank Math, AIOSEO e SEOPress: se um deles estiver ativo, o tema não duplica a meta description;
- página 404 personalizada;
- suporte a modo escuro e preferência de redução de movimento.

Para produção, converta as imagens enviadas para WebP/AVIF e substitua o vídeo incluso por uma versão MP4/WebM final e comprimida da operação CAPTEC, caso exista material aprovado.

## Identidade provisória

Como o arquivo do logotipo oficial não foi fornecido, o tema mostra uma marca tipográfica simples “CAPTEC ASFALTOS” apenas como fallback visual. Substitua-a em **Aparência > Personalizar > Identidade do site > Logo** por um arquivo oficial da marca, preferencialmente PNG ou WebP. Para usar SVG, adote antes uma solução de sanitização de SVG aprovada pela equipe técnica; o tema não libera SVG de forma insegura.

## Dependência local do mapa

O mapa interativo foi incluído localmente em `assets/js/brazil-map.umd.min.js`, sem CDN pública. A licença BSD 2-Clause correspondente está em `assets/LICENSES/brazil-map-LICENSE.txt`.

## Painel administrativo visual

Para administrar o portal em uma experiência unificada, instale também o plugin **Portal Administrativo CAPTEC** (`captec-portal-admin.zip`). Ele centraliza a edição de toda a Home, produtos, aplicações, blog, cotações, marca, contatos, indicadores, mapa, integrações e LGPD em **Portal CAPTEC** no WordPress.

## Requisitos

- WordPress 6.2 ou superior;
- PHP 7.4 ou superior;
- HTTPS em produção;
- SMTP configurado para a entrega confiável de cotações.

## Navegação e alinhamento

A estrutura de páginas pode ser criada em **Portal CAPTEC > Páginas e menu**. Cada item do menu passa a apontar para uma página WordPress própria. A grade pública usa espaçamento lateral responsivo, mantendo Hero, cabeçalho e seções alinhados com margem segura em relação aos cantos da tela.

## Personalização do menu

O Portal CAPTEC inclui a tela **Aparências**, onde é possível ajustar fundo das páginas, áreas suaves, barras, largura do conteúdo, margens, espaços, cabeçalho, menu e rodapé. O menu mantém controles de cor, tipografia, tamanho, espaçamento entre itens e comportamento de fundo.

## Atualização 3.3

- A tela **Aparência do menu** foi ampliada e renomeada para **Aparências**.
- Fundo das páginas, barras, largura, espaços, cabeçalho, menu e rodapé são configuráveis pelo Portal CAPTEC.
- A página Produtos usa fundo branco atrás da vitrine.
- O mapa de cobertura usa quadro compacto e mapa visualmente maior.
- Os cinco indicadores institucionais padrão são criados publicados, com valores vazios até validação.
- Botões recebem opção de posição: padrão, esquerda, centro ou direita.

## Atualização 3.2

- A área de título das páginas internas foi compactada para reduzir o espaço vertical.
- O mapa de cobertura ganhou área ampliada; estados configurados permanecem destacados depois do clique.
- Botões e informações do rodapé são gerenciados pelo Portal Administrativo CAPTEC, com status publicado/rascunho.
- Indicadores institucionais podem ser criados, editados, publicados, deixados em rascunho ou excluídos.

## Atualização 2.6

A logomarca configurada no WordPress é aplicada no cabeçalho público, tela de acesso do WordPress e página de manutenção. O formulário de cotação usa Estado antes de Cidade e carrega municípios pelo endpoint público do IBGE, com fallback local para BA, RJ e AM.


## Atualização 3.4

- As antigas páginas **Aplicações** e **Diferenciais** foram unificadas em **Quem somos**.
- O conteúdo da página Quem somos é armazenado no WordPress por meio dos shortcodes `captec_quem_somos`, `captec_aplicacoes` e `captec_diferenciais`.
- Páginas estruturais recebem conteúdo de referência no editor nativo do WordPress e o Portal CAPTEC mostra uma prévia desse conteúdo em **Páginas e menu**.

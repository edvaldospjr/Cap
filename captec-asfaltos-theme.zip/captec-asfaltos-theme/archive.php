<?php
defined( 'ABSPATH' ) || exit;
get_header();
$title = post_type_archive_title( '', false );
if ( ! $title ) { $title = get_the_archive_title(); }
?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php esc_html_e( 'CAPTEC Asfaltos', 'captec-asfaltos' ); ?></p><h1 class="section-title"><?php echo esc_html( $title ); ?></h1></div></header>
	<section class="section"><div class="shell">
		<?php if ( have_posts() ) : ?><div class="blog-grid">
			<?php while ( have_posts() ) : the_post(); ?><article <?php post_class( 'article-card article-card--post' ); ?>><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'large', array( 'class' => 'article-card__image', 'loading' => 'lazy', 'decoding' => 'async' ) ); } ?><div class="article-card__content"><span class="article-card__category"><?php echo esc_html( get_post_type() === 'post' ? __( 'Conteúdo', 'captec-asfaltos' ) : __( 'Solução CAPTEC', 'captec-asfaltos' ) ); ?></span><h2><?php the_title(); ?></h2><a class="text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Ver detalhes', 'captec-asfaltos' ); ?><span class="arrow">→</span></a></div></article><?php endwhile; ?></div>
			<?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => '←', 'next_text' => '→' ) ); ?>
		<?php else : ?><div class="entry-content"><h2><?php esc_html_e( 'Conteúdos em preparação', 'captec-asfaltos' ); ?></h2><p><?php esc_html_e( 'Em breve, esta área receberá novos conteúdos.', 'captec-asfaltos' ); ?></p></div><?php endif; ?>
	</div></section>
</main>
<?php get_footer();

/* Seletor de arquivo da ficha técnica no painel WordPress. */
(function ($) {
  'use strict';
  $(document).on('click', '.captec-select-media', function (event) {
    event.preventDefault();
    var button = $(this);
    var target = $(button.data('target'));
    var frame = wp.media({
      title: 'Selecionar ficha técnica',
      button: { text: 'Usar este arquivo' },
      multiple: false
    });
    frame.on('select', function () {
      var file = frame.state().get('selection').first().toJSON();
      target.val(file.url).trigger('change');
    });
    frame.open();
  });
}(jQuery));

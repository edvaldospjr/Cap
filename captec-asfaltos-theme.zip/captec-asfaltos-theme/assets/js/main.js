/* CAPTEC Asfaltos — interações sem dependências externas */
(function () {
  'use strict';

  var settings = window.CaptecSettings || { tracking: {} };
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  function showToast(message) {
    var region = document.querySelector('[data-toast-region]');
    if (!region || !message) return;
    window.clearTimeout(region._toastTimer);
    region.textContent = message;
    region.classList.add('is-visible');
    region._toastTimer = window.setTimeout(function () {
      region.classList.remove('is-visible');
    }, 4200);
  }

  function safelyStore(key, value) {
    try { window.localStorage.setItem(key, value); } catch (e) { /* storage may be blocked */ }
  }
  function readStore(key) {
    try { return window.localStorage.getItem(key); } catch (e) { return null; }
  }

  function setTheme(theme) {
    document.documentElement.dataset.theme = theme;
    safelyStore('captec-theme', theme);
    var toggle = document.querySelector('[data-theme-toggle]');
    if (toggle) {
      toggle.setAttribute('aria-label', theme === 'dark' ? 'Alternar para tema claro' : 'Alternar para tema escuro');
      toggle.setAttribute('title', theme === 'dark' ? 'Usar tema claro' : 'Usar tema escuro');
    }
  }

  function initHeader() {
    var header = document.querySelector('[data-site-header]');
    var nav = document.querySelector('[data-primary-nav]');
    var toggle = document.querySelector('[data-nav-toggle]');
    var icon = document.querySelector('[data-nav-icon]');
    if (!header) return;

    function updateHeader() {
      header.classList.toggle('is-scrolled', window.scrollY > 18);
    }
    updateHeader();
    window.addEventListener('scroll', updateHeader, { passive: true });

    if (!nav || !toggle) return;
    function closeNav() {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Abrir menu');
      document.body.classList.remove('no-scroll');
      if (icon) icon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
    }
    function openNav() {
      nav.classList.add('is-open');
      toggle.setAttribute('aria-expanded', 'true');
      toggle.setAttribute('aria-label', 'Fechar menu');
      document.body.classList.add('no-scroll');
      if (icon) icon.innerHTML = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
    }
    toggle.addEventListener('click', function () {
      nav.classList.contains('is-open') ? closeNav() : openNav();
    });
    nav.querySelectorAll('a').forEach(function (link) { link.addEventListener('click', closeNav); });
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape') closeNav(); });
  }

  function initReveal() {
    var nodes = document.querySelectorAll('[data-reveal]');
    if (!nodes.length) return;
    if (reduceMotion || !('IntersectionObserver' in window)) {
      nodes.forEach(function (node) { node.classList.add('is-revealed'); });
      return;
    }
    var observer = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-revealed');
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -35px' });
    nodes.forEach(function (node) { observer.observe(node); });
  }

  function animateCounter(node) {
    if (!node || node.dataset.counted === 'true') return;
    var target = parseInt(node.dataset.counter || '', 10);
    if (!Number.isFinite(target)) return;
    node.dataset.counted = 'true';
    var suffix = node.dataset.suffix || '';
    if (reduceMotion) {
      node.textContent = new Intl.NumberFormat('pt-BR').format(target) + (suffix ? ' ' + suffix : '');
      return;
    }
    var start = null;
    var duration = Math.min(1800, Math.max(800, 600 + Math.log10(Math.max(target, 10)) * 330));
    var formatter = new Intl.NumberFormat('pt-BR');
    function tick(timestamp) {
      if (!start) start = timestamp;
      var progress = Math.min((timestamp - start) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 4);
      node.textContent = formatter.format(Math.round(target * eased)) + (suffix ? ' ' + suffix : '');
      if (progress < 1) window.requestAnimationFrame(tick);
    }
    window.requestAnimationFrame(tick);
  }

  function initCounters() {
    var counters = document.querySelectorAll('[data-counter]');
    if (!counters.length) return;
    if (reduceMotion || !('IntersectionObserver' in window)) {
      counters.forEach(animateCounter);
      return;
    }
    var observer = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.42 });
    counters.forEach(function (counter) { observer.observe(counter); });
  }

  function initProductSelection() {
    var select = document.querySelector('#quote-product');
    document.querySelectorAll('[data-select-product]').forEach(function (link) {
      link.addEventListener('click', function () {
        if (!select) return;
        var value = link.getAttribute('data-select-product');
        window.setTimeout(function () {
          select.value = value;
          select.dispatchEvent(new Event('change', { bubbles: true }));
        }, 60);
      });
    });
  }

  function initFileNames() {
    document.querySelectorAll('input[type="file"]').forEach(function (input) {
      input.addEventListener('change', function () {
        var label = input.closest('.form-file');
        var name = label && label.querySelector('[data-file-name]');
        if (!name) return;
        name.textContent = input.files && input.files[0] ? input.files[0].name : 'Anexar arquivo';
      });
    });
  }

  function initCitySelectors() {
    var fallbackCities = {
      BA: ['Salvador', 'Feira de Santana', 'Vitória da Conquista', 'Camaçari', 'Lauro de Freitas'],
      RJ: ['Rio de Janeiro', 'Duque de Caxias', 'Niterói', 'São Gonçalo', 'Nova Iguaçu'],
      AM: ['Manaus', 'Parintins', 'Itacoatiara', 'Manacapuru', 'Tefé']
    };
    function populate(select, cities, previous) {
      select.innerHTML = '<option value="">Selecione a cidade</option>';
      (cities || []).forEach(function (city) {
        var option = document.createElement('option');
        option.value = city;
        option.textContent = city;
        if (city === previous) option.selected = true;
        select.appendChild(option);
      });
      select.disabled = false;
    }
    function loadCities(stateSelect, citySelect) {
      var uf = stateSelect.value;
      var previous = citySelect.dataset.selected || citySelect.value || '';
      if (!uf) {
        citySelect.disabled = true;
        citySelect.innerHTML = '<option value="">Selecione primeiro o estado</option>';
        return;
      }
      citySelect.disabled = true;
      citySelect.innerHTML = '<option value="">Carregando municípios…</option>';
      if (!settings.ajaxUrl || !window.fetch) {
        populate(citySelect, fallbackCities[uf] || [], previous);
        return;
      }
      var separator = settings.ajaxUrl.indexOf('?') === -1 ? '?' : '&';
      window.fetch(settings.ajaxUrl + separator + 'action=' + encodeURIComponent(settings.cityAction || 'captec_get_cities') + '&uf=' + encodeURIComponent(uf), { credentials: 'same-origin' })
        .then(function (response) { return response.json(); })
        .then(function (response) {
          if (!response || !response.success || !response.data || !Array.isArray(response.data.cities)) throw new Error('invalid');
          populate(citySelect, response.data.cities, previous);
        })
        .catch(function () {
          populate(citySelect, fallbackCities[uf] || [], previous);
          if (!citySelect.options.length || citySelect.options.length === 1) {
            citySelect.innerHTML = '<option value="">Municípios indisponíveis — informe na mensagem</option>';
          }
        });
    }
    document.querySelectorAll('[data-state-select]').forEach(function (stateSelect) {
      var form = stateSelect.closest('form');
      var citySelect = form && form.querySelector('[data-city-select]');
      if (!citySelect) return;
      stateSelect.addEventListener('change', function () { loadCities(stateSelect, citySelect); });
      if (stateSelect.value) loadCities(stateSelect, citySelect);
    });
  }

  function initMap() {
    var map = document.querySelector('brazil-component');
    var status = document.querySelector('[data-map-status]');
    if (!map) return;
    var names = {
      AC: 'Acre', AL: 'Alagoas', AP: 'Amapá', AM: 'Amazonas', BA: 'Bahia', CE: 'Ceará', DF: 'Distrito Federal', ES: 'Espírito Santo', GO: 'Goiás', MA: 'Maranhão', MT: 'Mato Grosso', MS: 'Mato Grosso do Sul', MG: 'Minas Gerais', PA: 'Pará', PB: 'Paraíba', PR: 'Paraná', PE: 'Pernambuco', PI: 'Piauí', RJ: 'Rio de Janeiro', RN: 'Rio Grande do Norte', RS: 'Rio Grande do Sul', RO: 'Rondônia', RR: 'Roraima', SC: 'Santa Catarina', SP: 'São Paulo', SE: 'Sergipe', TO: 'Tocantins'
    };
    var availabilityMessage = String(settings.mapStatusMessage || 'disponível para atendimento').trim() || 'disponível para atendimento';
    function stateCode(detail) {
      if (typeof detail === 'string') return detail.replace(/^BR-/, '');
      if (detail && typeof detail.state === 'string') return detail.state.replace(/^BR-/, '');
      if (detail && typeof detail.id === 'string') return detail.id.replace(/^BR-/, '');
      return '';
    }
    function activeCodes() {
      return (map.getAttribute('data-active-states') || '').split(',').map(function (item) { return item.trim().toUpperCase(); }).filter(Boolean);
    }
    function keepConfiguredStatesMarked() {
      if (!map.shadowRoot) return;
      activeCodes().forEach(function (code) {
        var node = map.shadowRoot.querySelector('#BR-' + code);
        var acronym = map.shadowRoot.querySelector('#' + code);
        if (node) {
          node.style.fill = '#F2A300';
          node.style.stroke = '#111111';
        }
        if (acronym) acronym.style.fill = '#111111';
      });
    }
    function scheduleConfiguredStateRestore() {
      window.setTimeout(keepConfiguredStatesMarked, 0);
    }
    map.addEventListener('onStateSelected', function (event) {
      var state = stateCode(event.detail);
      if (status && state && names[state]) status.textContent = names[state] + ': ' + availabilityMessage;
      scheduleConfiguredStateRestore();
    });
    if (window.customElements && window.customElements.whenDefined) {
      window.customElements.whenDefined('brazil-component').then(function () {
        window.setTimeout(function () {
          keepConfiguredStatesMarked();
          if (map.shadowRoot) {
            // A biblioteca altera cores em hover/click. Reaplicamos somente os estados
            // configurados depois da interação para que eles nunca percam o destaque.
            map.shadowRoot.addEventListener('mouseout', scheduleConfiguredStateRestore, true);
            map.shadowRoot.addEventListener('click', scheduleConfiguredStateRestore, true);
          }
        }, 80);
      });
    }
  }

  function appendScript(src, id) {
    if (document.getElementById(id)) return;
    var script = document.createElement('script');
    script.id = id;
    script.async = true;
    script.src = src;
    document.head.appendChild(script);
  }

  function loadTracking() {
    var tracking = settings.tracking || {};
    if (tracking.ga4 && /^G-[A-Z0-9]+$/i.test(tracking.ga4)) {
      window.dataLayer = window.dataLayer || [];
      window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };
      window.gtag('js', new Date());
      window.gtag('config', tracking.ga4, { anonymize_ip: true });
      appendScript('https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(tracking.ga4), 'captec-ga4');
    }
    if (tracking.pixel && /^\d+$/.test(String(tracking.pixel))) {
      window.fbq = window.fbq || function () { (window.fbq.q = window.fbq.q || []).push(arguments); };
      if (!window._fbq) window._fbq = window.fbq;
      window.fbq('init', String(tracking.pixel));
      window.fbq('track', 'PageView');
      appendScript('https://connect.facebook.net/en_US/fbevents.js', 'captec-meta-pixel');
    }
  }

  function initCookies() {
    var banner = document.querySelector('[data-cookie-banner]');
    var consent = readStore('captec-cookie-consent');
    if (consent === 'all') loadTracking();
    if (!banner) return;
    if (!consent) {
      window.setTimeout(function () { banner.classList.add('is-visible'); }, 650);
    }
    var accept = banner.querySelector('[data-cookie-accept]');
    var essential = banner.querySelector('[data-cookie-essential]');
    if (accept) accept.addEventListener('click', function () {
      safelyStore('captec-cookie-consent', 'all');
      banner.classList.remove('is-visible');
      loadTracking();
      try { window.dispatchEvent(new CustomEvent('captec:analytics-consent')); } catch (e) {}
    });
    if (essential) essential.addEventListener('click', function () {
      safelyStore('captec-cookie-consent', 'essential');
      banner.classList.remove('is-visible');
    });
  }

  function initDemoForm() {
    var form = document.querySelector('form[data-demo-form]');
    if (!form) return;
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      form.reset();
      showToast('Demonstração: solicitação simulada com sucesso. No WordPress, ela é salva em Cotações e enviada por e-mail.');
    });
  }

  ready(function () {
    initHeader();
    initReveal();
    initCounters();
    initProductSelection();
    initFileNames();
    initCitySelectors();
    initMap();
    initCookies();
    initDemoForm();

    document.querySelectorAll('[data-toast]').forEach(function (button) {
      button.addEventListener('click', function () { showToast(button.getAttribute('data-toast')); });
    });
    var themeToggle = document.querySelector('[data-theme-toggle]');
    if (themeToggle) {
      setTheme(document.documentElement.dataset.theme || 'light');
      themeToggle.addEventListener('click', function () {
        setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
      });
    }
    if (reduceMotion) {
      document.querySelectorAll('video[autoplay]').forEach(function (video) { video.pause(); });
    }
  });
}());

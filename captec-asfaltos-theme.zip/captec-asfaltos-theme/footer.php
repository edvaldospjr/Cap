<?php
defined( 'ABSPATH' ) || exit;
$instagram = esc_url( captec_mod( 'captec_instagram', '' ) );
$linkedin  = esc_url( captec_mod( 'captec_linkedin', '' ) );
$maps      = esc_url( captec_mod( 'captec_maps_url', '' ) );
$location  = captec_mod( 'captec_location_label', 'Salvador/BA' );

$footer_navigation = captec_footer_items( 'navigation', array(
	array( 'label' => 'Quem somos', 'action' => 'home' ),
	array( 'label' => 'Produtos', 'action' => 'url', 'url' => captec_page_url( 'produtos', home_url( '/produtos/' ) ) ),
	array( 'label' => 'Unidades', 'action' => 'url', 'url' => captec_page_url( 'unidades', home_url( '/unidades/' ) ) ),
	array( 'label' => 'Cobertura', 'action' => 'url', 'url' => captec_page_url( 'cobertura', home_url( '/cobertura/' ) ) ),
	array( 'label' => 'Conteúdos', 'action' => 'url', 'url' => captec_page_url( 'blog', home_url( '/blog/' ) ) ),
	array( 'label' => 'Trabalhe conosco', 'action' => 'url', 'url' => captec_page_url( 'trabalhe-conosco', home_url( '/trabalhe-conosco/' ) ) ),
) );
$footer_service = captec_footer_items( 'atendimento', array(
	array( 'label' => captec_mod( 'captec_phone', 'Telefone' ), 'action' => 'phone' ),
	array( 'label' => 'Falar pelo WhatsApp', 'action' => 'whatsapp', 'target' => 'new' ),
	array( 'label' => 'E-mail comercial', 'action' => 'email' ),
	array( 'label' => 'Solicitar cotação', 'action' => 'quote' ),
) );
$footer_institutional = captec_footer_items( 'institucional', array(
	array( 'label' => 'Política de Privacidade', 'action' => 'privacy' ),
	array( 'label' => 'Política de Cookies', 'action' => 'cookies' ),
	array( 'label' => 'Google Maps', 'action' => 'maps', 'target' => 'new' ),
) );
$footer_bottom = captec_footer_items( 'bottom', array(
	array( 'label' => 'Privacidade', 'action' => 'privacy' ),
	array( 'label' => 'Cookies', 'action' => 'cookies' ),
) );
$footer_navigation_markup    = captec_footer_items_markup( $footer_navigation );
$footer_service_markup       = captec_footer_items_markup( $footer_service );
$footer_institutional_markup = captec_footer_items_markup( $footer_institutional );
$footer_bottom_markup        = captec_footer_items_markup( $footer_bottom );
$footer_custom_buttons = array();
foreach ( array( 'footer_custom_1', 'footer_custom_2', 'footer_custom_3' ) as $footer_slot ) {
	$footer_custom_buttons[] = captec_site_button_markup( $footer_slot, array( 'visible' => false ), array( 'icon' => 'arrow-right' ) );
}
$footer_custom_buttons = array_filter( $footer_custom_buttons );
$floating_button = captec_site_button( 'floating_whatsapp', array( 'label' => 'Falar pelo WhatsApp', 'action' => 'whatsapp', 'style' => 'yellow', 'target' => 'new', 'visible' => true ) );
$floating_url    = ! empty( $floating_button['visible'] ) ? captec_site_button_url( $floating_button, array( 'message' => 'Olá, gostaria de solicitar uma cotação.' ) ) : '';
$floating_target = 'new' === $floating_button['target'] && 0 === strpos( $floating_url, 'http' ) ? ' target="_blank" rel="noopener noreferrer"' : '';
?>
<footer class="site-footer">
	<div class="shell footer-top">
		<div class="footer-brand">
			<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'CAPTEC Asfaltos — Quem somos', 'captec-asfaltos' ); ?>">
				<?php echo captec_brand_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
			<p><?php echo esc_html( captec_mod( 'captec_footer_text', 'Soluções inteligentes para pavimentação e infraestrutura, com atendimento consultivo e foco em eficiência.' ) ); ?></p>
			<?php if ( $location ) : ?>
				<div class="footer-location"><?php echo captec_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( $location ); ?></span></div>
			<?php endif; ?>
			<?php if ( $instagram || $linkedin || $maps ) : ?>
				<div class="social-links" aria-label="<?php esc_attr_e( 'Canais digitais', 'captec-asfaltos' ); ?>">
					<?php if ( $instagram ) : ?><a class="social-link" href="<?php echo $instagram; ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><?php echo captec_icon( 'instagram' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a><?php endif; ?>
					<?php if ( $linkedin ) : ?><a class="social-link" href="<?php echo $linkedin; ?>" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn"><?php echo captec_icon( 'linkedin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a><?php endif; ?>
					<?php if ( $maps ) : ?><a class="social-link" href="<?php echo $maps; ?>" target="_blank" rel="noopener noreferrer" aria-label="Google Maps"><?php echo captec_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a><?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( $footer_custom_buttons ) : ?><div class="footer-cta-buttons"><?php echo implode( '', $footer_custom_buttons ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
		</div>
		<?php if ( $footer_navigation_markup ) : ?>
			<div>
				<h2 class="footer-heading"><?php esc_html_e( 'Navegação', 'captec-asfaltos' ); ?></h2>
				<ul class="footer-menu"><?php echo $footer_navigation_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></ul>
			</div>
		<?php endif; ?>
		<?php if ( $footer_service_markup ) : ?>
			<div>
				<h2 class="footer-heading"><?php esc_html_e( 'Atendimento', 'captec-asfaltos' ); ?></h2>
				<ul class="footer-menu"><?php echo $footer_service_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></ul>
			</div>
		<?php endif; ?>
		<?php if ( $footer_institutional_markup ) : ?>
			<div>
				<h2 class="footer-heading"><?php esc_html_e( 'Institucional', 'captec-asfaltos' ); ?></h2>
				<ul class="footer-menu"><?php echo $footer_institutional_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></ul>
			</div>
		<?php endif; ?>
	</div>
	<div class="shell footer-bottom">
		<p>© <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php esc_html_e( 'CAPTEC Asfaltos. Todos os direitos reservados.', 'captec-asfaltos' ); ?></p>
		<?php if ( $footer_bottom_markup ) : ?><nav aria-label="<?php esc_attr_e( 'Links legais', 'captec-asfaltos' ); ?>"><?php echo $footer_bottom_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></nav><?php endif; ?>
	</div>
</footer>

<?php if ( captec_feature_enabled( 'whatsapp', true ) && $floating_url ) : ?>
	<a class="floating-whatsapp" href="<?php echo esc_url( $floating_url ); ?>"<?php echo $floating_target; ?> aria-label="<?php echo esc_attr( $floating_button['label'] ); ?>" title="<?php echo esc_attr( $floating_button['label'] ); ?>">
		<?php echo captec_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</a>
<?php endif; ?>

<div class="cookie-banner" data-cookie-banner role="dialog" aria-labelledby="cookie-title" aria-describedby="cookie-description" aria-live="polite">
	<h2 id="cookie-title"><?php esc_html_e( 'Sua privacidade importa', 'captec-asfaltos' ); ?></h2>
	<p id="cookie-description"><?php esc_html_e( 'Usamos cookies essenciais para o funcionamento do site e, com seu consentimento, cookies de medição para aprimorar a experiência.', 'captec-asfaltos' ); ?> <a href="<?php echo esc_url( captec_policy_url( 'cookies' ) ); ?>"><?php esc_html_e( 'Saiba mais', 'captec-asfaltos' ); ?></a>.</p>
	<div class="cookie-actions">
		<button class="button button--yellow" type="button" data-cookie-accept><?php esc_html_e( 'Aceitar todos', 'captec-asfaltos' ); ?></button>
		<button class="button button--ghost" type="button" data-cookie-essential><?php esc_html_e( 'Somente essenciais', 'captec-asfaltos' ); ?></button>
	</div>
</div>
<div class="toast" data-toast-region role="status" aria-live="polite"></div>
<?php wp_footer(); ?>
</body>
</html>

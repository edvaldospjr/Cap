<?php
/** Página Quem somos: Hero e seções institucionais unificadas, salvas no WordPress. */
defined( 'ABSPATH' ) || exit;
get_header();

$hero_title    = captec_mod( 'captec_hero_title', 'CAPTEC ASFALTOS' );
$hero_subtitle = captec_mod( 'captec_hero_subtitle', 'Soluções inteligentes para pavimentação e infraestrutura.' );
$hero_text     = captec_mod( 'captec_hero_text', 'Especialistas no fornecimento de produtos asfálticos para obras públicas e privadas com atendimento consultivo, eficiência logística e compromisso com resultados.' );
$hero_poster   = captec_mod( 'captec_hero_poster', captec_asset( 'assets/images/hero-paving.jpg' ) );
$hero_video    = captec_mod( 'captec_hero_video_url', captec_asset( 'assets/videos/captec-hero.mp4' ) );
$hero_quote_button = captec_site_button_markup(
	'hero_quote',
	array( 'label' => captec_mod( 'captec_hero_quote_label', 'Solicitar Cotação' ), 'action' => 'quote', 'style' => 'yellow' ),
	array( 'icon' => 'arrow-right' )
);
$hero_whatsapp_button = captec_site_button_markup(
	'hero_whatsapp',
	array( 'label' => captec_mod( 'captec_hero_whatsapp_label', 'Falar pelo WhatsApp' ), 'action' => 'whatsapp', 'style' => 'ghost', 'target' => 'new' ),
	array( 'icon' => 'whatsapp', 'icon_before' => true, 'message' => 'Olá, gostaria de falar com a CAPTEC Asfaltos.' )
);
$hero_cards    = array(
	array( 'icon' => 'quality', 'title' => captec_mod( 'captec_hero_card_1_title', 'Produtos de Qualidade' ), 'text' => captec_mod( 'captec_hero_card_1_text', 'Soluções alinhadas ao projeto' ) ),
	array( 'icon' => 'headset', 'title' => captec_mod( 'captec_hero_card_2_title', 'Atendimento Especializado' ), 'text' => captec_mod( 'captec_hero_card_2_text', 'Escuta e orientação comercial' ) ),
	array( 'icon' => 'route', 'title' => captec_mod( 'captec_hero_card_3_title', 'Logística Eficiente' ), 'text' => captec_mod( 'captec_hero_card_3_text', 'Planejamento para cada demanda' ) ),
	array( 'icon' => 'handshake', 'title' => captec_mod( 'captec_hero_card_4_title', 'Suporte Comercial' ), 'text' => captec_mod( 'captec_hero_card_4_text', 'Acompanhamento do início ao pós-venda' ) ),
);
?>
<main id="conteudo-principal">
	<section class="hero hero--home" id="quem-somos" aria-label="<?php esc_attr_e( 'Apresentação CAPTEC Asfaltos', 'captec-asfaltos' ); ?>">
		<div class="hero-media" aria-hidden="true">
			<?php if ( captec_feature_enabled( 'hero_video', true ) ) : ?>
				<video class="hero-video" autoplay muted loop playsinline preload="metadata" poster="<?php echo esc_url( $hero_poster ); ?>">
					<source src="<?php echo esc_url( $hero_video ); ?>" type="video/mp4">
				</video>
			<?php endif; ?>
		</div>
		<div class="shell">
			<div class="hero-content" data-reveal>
				<div class="hero-kicker"><?php echo esc_html( captec_mod( 'captec_hero_kicker', 'Produtos asfálticos para infraestrutura' ) ); ?></div>
				<h1 class="hero-title"><?php echo esc_html( preg_replace( '/\s+/', ' ', str_replace( ' ASFALTOS', ' ', $hero_title ) ) ); ?><span><?php echo esc_html( false !== strpos( $hero_title, 'ASFALTOS' ) ? 'ASFALTOS' : '' ); ?></span></h1>
				<p class="hero-subtitle"><?php echo esc_html( $hero_subtitle ); ?></p>
				<p class="hero-copy"><?php echo esc_html( $hero_text ); ?></p>
				<?php if ( $hero_quote_button || $hero_whatsapp_button ) : ?><div class="hero-actions">
					<?php echo $hero_quote_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo $hero_whatsapp_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div><?php endif; ?>
			</div>
		</div>
		<div class="hero-stats-wrap">
			<div class="shell">
				<div class="hero-stats" data-reveal data-reveal-delay="2">
					<?php foreach ( $hero_cards as $hero_card ) : ?>
						<div class="hero-stat"><span class="hero-stat__icon"><?php echo captec_icon( $hero_card['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><div><strong><?php echo esc_html( $hero_card['title'] ); ?></strong><span><?php echo esc_html( $hero_card['text'] ); ?></span></div></div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</section>
	<?php
	// O conteúdo institucional é armazenado no editor da página Quem somos.
	// Na primeira carga, o Portal CAPTEC preenche os três shortcodes abaixo.
	$wordpress_content = get_queried_object_id() ? get_post_field( 'post_content', get_queried_object_id() ) : '';
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			if ( trim( (string) $wordpress_content ) ) {
				the_content();
			} else {
				echo do_shortcode( captec_quem_somos_shortcodes() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	} else {
		echo do_shortcode( captec_quem_somos_shortcodes() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	?>
</main>
<?php get_footer(); ?>

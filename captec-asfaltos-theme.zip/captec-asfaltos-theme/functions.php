<?php
/**
 * Funções-base do tema CAPTEC Asfaltos.
 *
 * O tema não depende de page builders. Conteúdos estratégicos são gerenciáveis
 * pelo WordPress nativo, pelo Personalizar e por tipos de conteúdo próprios.
 */

defined( 'ABSPATH' ) || exit;

define( 'CAPTEC_VERSION', '3.4.0' );
define( 'CAPTEC_DIR', get_template_directory() );
define( 'CAPTEC_URI', get_template_directory_uri() );

require_once CAPTEC_DIR . '/inc/content-types.php';
require_once CAPTEC_DIR . '/inc/customizer.php';
require_once CAPTEC_DIR . '/inc/form-handler.php';
require_once CAPTEC_DIR . '/inc/seo.php';
require_once CAPTEC_DIR . '/inc/portal-components.php';
require_once CAPTEC_DIR . '/inc/login-branding.php';
require_once CAPTEC_DIR . '/inc/presentation-controls.php';

/** Configuração do tema. */
function captec_setup() {
	load_theme_textdomain( 'captec-asfaltos', CAPTEC_DIR . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 320,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'assets/css/main.css' );
	add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );

	register_nav_menus( array(
		'primary' => __( 'Menu principal', 'captec-asfaltos' ),
		'footer'  => __( 'Menu do rodapé', 'captec-asfaltos' ),
	) );
}
add_action( 'after_setup_theme', 'captec_setup' );

/** Arquivos públicos. */
function captec_enqueue_assets() {
	$css_path       = CAPTEC_DIR . '/assets/css/main.css';
	$pages_css_path = CAPTEC_DIR . '/assets/css/pages.css';
	$js_path        = CAPTEC_DIR . '/assets/js/main.js';

	wp_enqueue_style( 'captec-style', get_stylesheet_uri(), array(), CAPTEC_VERSION );
	wp_enqueue_style( 'captec-main', CAPTEC_URI . '/assets/css/main.css', array( 'captec-style' ), file_exists( $css_path ) ? (string) filemtime( $css_path ) : CAPTEC_VERSION );
	wp_add_inline_style( 'captec-main', captec_menu_custom_css() );
	if ( ! is_front_page() ) {
		wp_enqueue_style( 'captec-pages', CAPTEC_URI . '/assets/css/pages.css', array( 'captec-main' ), file_exists( $pages_css_path ) ? (string) filemtime( $pages_css_path ) : CAPTEC_VERSION );
	}

	// O mapa é local; não há dependência de CDN no site público.
	if ( is_page( 'cobertura' ) ) {
		$map_path = CAPTEC_DIR . '/assets/js/brazil-map.umd.min.js';
		wp_enqueue_script( 'captec-brazil-map', CAPTEC_URI . '/assets/js/brazil-map.umd.min.js', array(), file_exists( $map_path ) ? (string) filemtime( $map_path ) : CAPTEC_VERSION, true );
	}

	$main_dependencies = is_page( 'cobertura' ) ? array( 'captec-brazil-map' ) : array();
	wp_enqueue_script( 'captec-main', CAPTEC_URI . '/assets/js/main.js', $main_dependencies, file_exists( $js_path ) ? (string) filemtime( $js_path ) : CAPTEC_VERSION, true );

	$tracking = array(
		'ga4'   => sanitize_text_field( get_theme_mod( 'captec_ga4_id', '' ) ),
		'pixel' => preg_replace( '/[^0-9]/', '', (string) get_theme_mod( 'captec_meta_pixel_id', '' ) ),
	);
	wp_add_inline_script( 'captec-main', 'window.CaptecSettings = ' . wp_json_encode( array(
		'tracking' => $tracking,
		'homeUrl'  => home_url( '/' ),
		'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
		'cityAction'=> 'captec_get_cities',
		'mapStatusMessage' => sanitize_text_field( captec_mod( 'captec_map_status_message', 'disponível para atendimento' ) ),
	) ) . ';', 'before' );
}
add_action( 'wp_enqueue_scripts', 'captec_enqueue_assets' );

/** Admin leve para selecionar a ficha técnica no cadastro de produtos. */
function captec_admin_assets( $hook ) {
	global $post_type;
	if ( 'captec_product' !== $post_type && 'post.php' !== $hook && 'post-new.php' !== $hook ) {
		return;
	}
	if ( 'captec_product' !== $post_type ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_script( 'captec-admin', CAPTEC_URI . '/assets/js/admin.js', array( 'jquery' ), CAPTEC_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'captec_admin_assets' );


/** Lista de municípios por UF via fonte oficial IBGE, com cache local. */
function captec_get_cities_by_state() {
	$uf = isset( $_REQUEST['uf'] ) ? strtoupper( preg_replace( '/[^A-Za-z]/', '', sanitize_text_field( wp_unslash( $_REQUEST['uf'] ) ) ) ) : '';
	$allowed = array( 'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO' );
	if ( ! in_array( $uf, $allowed, true ) ) {
		wp_send_json_error( array( 'message' => __( 'Estado inválido.', 'captec-asfaltos' ) ), 400 );
	}
	$cache_key = 'captec_ibge_cities_' . strtolower( $uf );
	$cities = get_transient( $cache_key );
	if ( false === $cities ) {
		$response = wp_remote_get( 'https://servicodados.ibge.gov.br/api/v1/localidades/estados/' . rawurlencode( $uf ) . '/municipios', array( 'timeout' => 12 ) );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			wp_send_json_error( array( 'message' => __( 'Não foi possível carregar os municípios neste momento.', 'captec-asfaltos' ) ), 503 );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$cities = array();
		if ( is_array( $body ) ) {
			foreach ( $body as $city ) {
				if ( ! empty( $city['nome'] ) ) {
					$cities[] = sanitize_text_field( $city['nome'] );
				}
			}
		}
		set_transient( $cache_key, $cities, MONTH_IN_SECONDS );
	}
	wp_send_json_success( array( 'cities' => $cities ) );
}
add_action( 'wp_ajax_captec_get_cities', 'captec_get_cities_by_state' );
add_action( 'wp_ajax_nopriv_captec_get_cities', 'captec_get_cities_by_state' );

/** Utilitários de apresentação. */
function captec_asset( $path ) {
	return esc_url( CAPTEC_URI . '/' . ltrim( $path, '/' ) );
}

function captec_mod( $key, $default = '' ) {
	if ( function_exists( 'captec_is_admin_preview' ) && captec_is_admin_preview() ) {
		$draft = get_option( 'captec_portal_draft_settings', array() );
		if ( is_array( $draft ) && array_key_exists( $key, $draft ) ) {
			$value = $draft[ $key ];
			return ( '' === $value || null === $value ) ? $default : $value;
		}
	}
	$value = get_theme_mod( $key, $default );
	return ( '' === $value || null === $value ) ? $default : $value;
}

function captec_clean_phone( $value ) {
	return preg_replace( '/[^0-9+]/', '', (string) $value );
}

function captec_whatsapp_url( $message = '' ) {
	$number = preg_replace( '/\D+/', '', (string) captec_mod( 'captec_whatsapp', '' ) );
	if ( ! $number ) {
		return '#cotacao';
	}
	$url = 'https://wa.me/' . $number;
	if ( $message ) {
		$url .= '?text=' . rawurlencode( $message );
	}
	return esc_url( $url );
}

function captec_policy_url( $kind = 'privacy' ) {
	$setting = 'privacy' === $kind ? 'captec_privacy_url' : 'captec_cookie_url';
	$url     = esc_url_raw( captec_mod( $setting, '' ) );
	if ( $url ) {
		return $url;
	}
	$slug = 'privacy' === $kind ? 'politica-de-privacidade' : 'politica-de-cookies';
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' );
}

function captec_page_url( $slug, $fallback = '#' ) {
	$page = get_page_by_path( $slug );
	if ( ! $page || ( ! captec_is_admin_preview() && 'publish' !== get_post_status( $page ) ) ) {
		return $fallback;
	}
	return get_permalink( $page );
}

/** Redireciona páginas institucionais unificadas para Quem somos. */
function captec_redirect_legacy_merged_pages() {
	if ( is_admin() || wp_doing_ajax() ) {
		return;
	}
	$request_uri  = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$request_path = trim( (string) wp_parse_url( $request_uri, PHP_URL_PATH ), '/' );
	$home_path    = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $home_path && 0 === strpos( $request_path . '/', $home_path . '/' ) ) {
		$request_path = trim( substr( $request_path, strlen( $home_path ) ), '/' );
	}
	if ( ! in_array( $request_path, array( 'empresa', 'aplicacoes', 'diferenciais' ), true ) ) {
		return;
	}
	wp_safe_redirect( home_url( '/' ), 301 );
	exit;
}
add_action( 'template_redirect', 'captec_redirect_legacy_merged_pages', 1 );

/** URL da página de cotação, com produto opcional pré-selecionado. */
function captec_quote_url( $product = '' ) {
	$url = captec_page_url( 'cotacao', home_url( '/#cotacao' ) );
	if ( $product ) {
		$url = add_query_arg( 'produto', $product, $url );
	}
	return $url;
}

/** Chave de funcionalidade editável no Portal CAPTEC. */
function captec_feature_enabled( $feature, $default = true ) {
	$value = captec_mod( 'captec_feature_' . sanitize_key( $feature ), $default ? '1' : '0' );
	return ! in_array( (string) $value, array( '0', 'false', 'off', '' ), true );
}

/** Modo de prévia protegido para o iframe do Portal CAPTEC. */
function captec_is_admin_preview() {
	return is_user_logged_in() && ( current_user_can( 'captec_manage_portal' ) || current_user_can( 'manage_options' ) ) && isset( $_GET['captec_admin_preview'] ) && '1' === sanitize_text_field( wp_unslash( $_GET['captec_admin_preview'] ) );
}

function captec_hide_admin_bar_in_preview( $show ) {
	return captec_is_admin_preview() ? false : $show;
}
add_filter( 'show_admin_bar', 'captec_hide_admin_bar_in_preview' );

function captec_menu_hex( $value, $fallback ) {
	$color = sanitize_hex_color( (string) $value );
	return $color ? $color : $fallback;
}

function captec_menu_font_stack( $font ) {
	$fonts = array(
		'inter'  => 'Inter, Arial, Helvetica, sans-serif',
		'poppins'=> 'Poppins, "Segoe UI", Arial, Helvetica, sans-serif',
		'system' => '-apple-system, BlinkMacSystemFont, "Segoe UI", Arial, sans-serif',
		'serif'  => 'Georgia, "Times New Roman", serif',
	);
	return isset( $fonts[ $font ] ) ? $fonts[ $font ] : $fonts['inter'];
}

function captec_menu_custom_css() {
	$background = captec_menu_hex( captec_mod( 'captec_menu_background_color', '#111111' ), '#111111' );
	$text       = captec_menu_hex( captec_mod( 'captec_menu_text_color', '#FFFFFF' ), '#FFFFFF' );
	$size       = min( 24, max( 10, absint( captec_mod( 'captec_menu_font_size', '13' ) ) ) );
	$opacity    = min( 100, max( 35, absint( captec_mod( 'captec_menu_overlay_opacity', '92' ) ) ) ) / 100;
	$font       = captec_menu_font_stack( captec_mod( 'captec_menu_font_family', 'inter' ) );
	$menu_logo  = min( 320, max( 150, absint( captec_mod( 'captec_menu_logo_size', '224' ) ) ) );
	$footer_logo = min( 260, max( 90, absint( captec_mod( 'captec_footer_logo_size', '164' ) ) ) );

	$page_background = captec_menu_hex( captec_mod( 'captec_page_background_color', '#FFFFFF' ), '#FFFFFF' );
	$page_surface    = captec_menu_hex( captec_mod( 'captec_page_surface_color', '#F4F4F4' ), '#F4F4F4' );
	$page_bar        = captec_menu_hex( captec_mod( 'captec_page_bar_color', '#111111' ), '#111111' );
	$page_bar_ink    = captec_menu_hex( captec_mod( 'captec_page_bar_text_color', '#FFFFFF' ), '#FFFFFF' );
	$site_width      = min( 1800, max( 960, absint( captec_mod( 'captec_site_width', '1360' ) ) ) );
	$page_gutter     = min( 120, max( 16, absint( captec_mod( 'captec_page_gutter', '80' ) ) ) );
	$section_spacing = min( 190, max( 42, absint( captec_mod( 'captec_section_spacing', '120' ) ) ) );
	$header_height   = min( 140, max( 64, absint( captec_mod( 'captec_header_height', '92' ) ) ) );
	$menu_gap        = min( 42, max( 6, absint( captec_mod( 'captec_menu_item_gap', '22' ) ) ) );
	$footer_spacing  = min( 150, max( 32, absint( captec_mod( 'captec_footer_spacing', '74' ) ) ) );
	$footer_bottom   = max( 18, (int) round( $footer_spacing * 0.42 ) );
	$tight_spacing   = max( 34, (int) round( $section_spacing * 0.72 ) );

	return ':root{--captec-menu-bg:' . $background . ';--captec-menu-ink:' . $text . ';--captec-menu-font-size:' . absint( $size ) . 'px;--captec-menu-font:' . $font . ';--captec-menu-overlay-opacity:' . (string) $opacity . ';--captec-menu-logo-size:' . absint( $menu_logo ) . 'px;--captec-footer-logo-size:' . absint( $footer_logo ) . 'px;--captec-page-background:' . $page_background . ';--captec-page-surface:' . $page_surface . ';--captec-page-bar-color:' . $page_bar . ';--captec-page-bar-text:' . $page_bar_ink . ';--captec-site-width:' . absint( $site_width ) . 'px;--captec-page-gutter:' . absint( $page_gutter ) . 'px;--captec-section-spacing:' . absint( $section_spacing ) . 'px;--captec-tight-section-spacing:' . absint( $tight_spacing ) . 'px;--captec-header-height:' . absint( $header_height ) . 'px;--captec-menu-item-gap:' . absint( $menu_gap ) . 'px;--captec-footer-spacing:' . absint( $footer_spacing ) . 'px;--captec-footer-bottom-spacing:' . absint( $footer_bottom ) . 'px;}';
}

/** Ícones SVG locais — sem biblioteca externa. */
function captec_icon( $name, $class = '' ) {
	$class_attr = $class ? ' class="' . esc_attr( $class ) . '"' : '';
	$icons = array(
		'arrow-right' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'arrow-up-right' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M6 18 18 6M9 6h9v9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'check' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12 4.2 4.2L19 6.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'droplet' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3.8S5.8 10.1 5.8 14.4A6.2 6.2 0 0 0 18.2 14.4C18.2 10.1 12 3.8 12 3.8Z" stroke="currentColor" stroke-width="1.8"/><path d="M9.5 15.3c.2 1.3 1.1 2.2 2.5 2.4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
		'file' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M14 3H6.8A1.8 1.8 0 0 0 5 4.8v14.4A1.8 1.8 0 0 0 6.8 21h10.4a1.8 1.8 0 0 0 1.8-1.8V7L14 3Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M13.5 3v4.5H18M8.6 12h6.8M8.6 15.5h6.8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
		'quality' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 3 7 3v5.4c0 4.4-2.9 7.9-7 9.6-4.1-1.7-7-5.2-7-9.6V6l7-3Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="m8.7 12 2.1 2.1 4.6-4.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'headset' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 13v-1a8 8 0 0 1 16 0v1M4 13v4a2 2 0 0 0 2 2h1v-7H6a2 2 0 0 0-2 2Zm16 0v4a2 2 0 0 1-2 2h-1v-7h1a2 2 0 0 1 2 2Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="M17 19c0 1.1-.9 2-2 2h-2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
		'route' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 18.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4ZM17 12.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z" stroke="currentColor" stroke-width="1.7"/><path d="M9.8 13.1c1.2-1.8 1.9-3.6 4.3-4.1" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-dasharray="2.6 2.6"/></svg>',
		'handshake' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m7.5 12.2 3.1 3.1a1.6 1.6 0 0 0 2.3 0l.2-.2.4.4a1.6 1.6 0 0 0 2.3 0l1.7-1.8M4 8.3l2.3-2.2 2.4 1.2 2.1-1.3a2.4 2.4 0 0 1 2.4 0l3.1 1.9 2.1 2.2-3.3 3.2-2.5-1.5-1.5 1.5a2 2 0 0 1-2.9 0L7.1 11.8 5.8 13 3.5 10.7 4 8.3Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'layers' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 3 8 4.3-8 4.3-8-4.3L12 3Zm-8 9 8 4.3 8-4.3M4 16.7l8 4.3 8-4.3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'clock' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.7"/><path d="M12 7v5.2l3.4 2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'calendar' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="5.5" width="16" height="14" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3.5v4M16 3.5v4M4 10h16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
		'truck' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M3.5 6.5h11v10h-11zM14.5 10h3.3l2.2 2.5v4H14.5z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><circle cx="7" cy="18" r="1.7" stroke="currentColor" stroke-width="1.7"/><circle cx="17" cy="18" r="1.7" stroke="currentColor" stroke-width="1.7"/></svg>',
		'message' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 11.4a7.3 7.3 0 0 1-7.6 7.1 8.5 8.5 0 0 1-3.3-.7L4 19l1.4-4.2a6.8 6.8 0 0 1-.8-3.2A7.3 7.3 0 0 1 12.2 4 7.4 7.4 0 0 1 20 11.4Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.5 11.5h.01M12 11.5h.01M15.5 11.5h.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
		'phone' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7.4 4.4 5.2 5.5c-.8.4-1.2 1.3-.9 2.2 1.7 5.6 6.1 10 11.7 11.7.9.3 1.8-.1 2.2-.9l1.1-2.2a1.5 1.5 0 0 0-.7-2l-3-1.3a1.5 1.5 0 0 0-1.7.4l-1.1 1.3a11 11 0 0 1-3.8-3.8l1.3-1.1a1.5 1.5 0 0 0 .4-1.7l-1.3-3a1.5 1.5 0 0 0-2-.7Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
		'whatsapp' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 11.4a7.7 7.7 0 0 1-11.4 6.8L4 19.5l1.3-4.3A7.7 7.7 0 1 1 20 11.4Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.1 8.2c.2-.4.4-.4.7-.4h.5c.2 0 .4.1.5.4l.6 1.5c.1.3.1.5-.1.7l-.5.6c.5 1 1.2 1.7 2.2 2.2l.6-.5c.2-.2.4-.2.7-.1l1.5.6c.3.1.4.3.4.5v.5c0 .3-.1.5-.4.7-.4.2-.9.3-1.3.2-3.1-.9-5.5-3.3-6.4-6.4-.1-.4 0-.9.2-1.3Z" fill="currentColor" stroke="none"/></svg>',
		'mail' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="5.5" width="17" height="13" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="m4.5 7 7.5 5.6L19.5 7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'pin' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 10.2c0 5-7 10.3-7 10.3s-7-5.3-7-10.3a7 7 0 1 1 14 0Z" stroke="currentColor" stroke-width="1.7"/><circle cx="12" cy="10" r="2.2" stroke="currentColor" stroke-width="1.7"/></svg>',
		'instagram' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="3.5" width="17" height="17" rx="4.5" stroke="currentColor" stroke-width="1.7"/><circle cx="12" cy="12" r="3.8" stroke="currentColor" stroke-width="1.7"/><circle cx="17.4" cy="6.7" r="1" fill="currentColor"/></svg>',
		'linkedin' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 10v6M8 7.5v.1M11.5 16v-3.3a2.3 2.3 0 0 1 4.5 0V16M11.5 12.7V10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
		'upload' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 15V4m0 0L8 8m4-4 4 4M5 15.5v3A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5v-3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
		'info' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.7"/><path d="M12 11v5M12 8v.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
		'sun' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="3.8" stroke="currentColor" stroke-width="1.7"/><path d="M12 2.8v2M12 19.2v2M21.2 12h-2M4.8 12h-2M18.5 5.5l-1.4 1.4M6.9 17.1l-1.4 1.4M18.5 18.5l-1.4-1.4M6.9 6.9 5.5 5.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
		'moon' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19.5 15.2A8.2 8.2 0 0 1 8.8 4.5 8.2 8.2 0 1 0 19.5 15.2Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
		'menu' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
		'close' => '<svg' . $class_attr . ' viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
	);
	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

/** Marca tipográfica temporária usada enquanto o logo oficial não é enviado. */
function captec_brand_markup() {
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( function_exists( 'captec_is_admin_preview' ) && captec_is_admin_preview() ) {
		$draft = get_option( 'captec_portal_draft_settings', array() );
		if ( is_array( $draft ) && isset( $draft['custom_logo_id'] ) ) {
			$logo_id = absint( $draft['custom_logo_id'] );
		}
	}
	if ( $logo_id ) {
		$logo    = wp_get_attachment_image( $logo_id, 'full', false, array( 'class' => 'brand-custom-logo', 'alt' => get_bloginfo( 'name' ) ) );
		if ( $logo ) {
			return $logo;
		}
	}
	return '<span class="brand-mark" aria-label="CAPTEC Asfaltos"><span class="brand-mark__top"><i class="brand-mark__stripe"></i>CAPTEC</span><span class="brand-mark__bottom">ASFALTOS</span></span>';
}

/** Menu de fallback para uma instalação recém-ativada. */
function captec_primary_menu_fallback() {
	$items = array(
		'/'                  => 'Quem somos',
		'produtos'           => 'Produtos',
		'unidades'           => 'Unidades',
		'cobertura'          => 'Cobertura',
		'blog'               => 'Conteúdos',
		'trabalhe-conosco'   => 'Trabalhe conosco',
		'cotacao'            => 'Cotação',
	);
	echo '<ul>';
	foreach ( $items as $slug => $label ) {
		if ( '/' !== $slug ) {
			$page = get_page_by_path( $slug );
			if ( ! $page || ( ! captec_is_admin_preview() && 'publish' !== get_post_status( $page ) ) ) {
				continue;
			}
		}
		$url = '/' === $slug ? home_url( '/' ) : captec_page_url( $slug, home_url( '/' . $slug . '/' ) );
		echo '<li><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
	}
	echo '</ul>';
}

/** Produtos padrão solicitados. Podem ser substituídos pelo CPT no painel. */
function captec_default_products() {
	$asset = 'assets/images/';
	return array(
		array( 'title' => 'CAP 30/45', 'type' => 'Cimento asfáltico', 'description' => 'Cimento asfáltico de petróleo para projetos com especificação CAP 30/45.', 'applications' => 'Aplicações definidas em projeto e especificação técnica.', 'image' => $asset . 'hero-paving.jpg', 'file' => '' ),
		array( 'title' => 'CAP 50/70', 'type' => 'Cimento asfáltico', 'description' => 'Cimento asfáltico de petróleo para projetos com especificação CAP 50/70.', 'applications' => 'Aplicações definidas em projeto e especificação técnica.', 'image' => $asset . 'app-highways.jpg', 'file' => '' ),
		array( 'title' => 'RR-1C', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica catiônica de ruptura rápida, conforme a demanda da obra.', 'applications' => 'Aplicações definidas no projeto de pavimentação.', 'image' => $asset . 'app-urban.jpg', 'file' => '' ),
		array( 'title' => 'RR-2C', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica catiônica de ruptura rápida para aplicações previstas em especificação.', 'applications' => 'Aplicações definidas no projeto de pavimentação.', 'image' => $asset . 'app-airport.jpg', 'file' => '' ),
		array( 'title' => 'RL-1C', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica catiônica de ruptura lenta, conforme a demanda técnica da obra.', 'applications' => 'Aplicações previstas em especificação.', 'image' => $asset . 'app-industrial.jpg', 'file' => '' ),
		array( 'title' => 'EAI', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica para imprimação, conforme a solução técnica definida para a obra.', 'applications' => 'Preparação de base, conforme especificação.', 'image' => $asset . 'app-municipal.jpg', 'file' => '' ),
		array( 'title' => 'Asfaltos Modificados', 'type' => 'Soluções especiais', 'description' => 'Soluções para requisitos específicos de desempenho e projeto.', 'applications' => 'Projetos com necessidades técnicas particulares.', 'image' => $asset . 'about-highway.jpg', 'file' => '' ),
	);
}

function captec_products() {
	$query = new WP_Query( array(
		'post_type'      => 'captec_product',
		'post_status'    => captec_is_admin_preview() ? array( 'publish', 'draft' ) : 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	) );
	if ( ! $query->have_posts() ) {
		return captec_default_products();
	}

	$items     = array();
	$fallbacks = captec_default_products();
	foreach ( $query->posts as $index => $post ) {
		$meta = get_post_meta( $post->ID );
		$image = get_the_post_thumbnail_url( $post, 'large' );
		$items[] = array(
			'id'           => $post->ID,
			'title'        => get_the_title( $post ),
			'type'         => isset( $meta['_captec_product_type'][0] ) ? $meta['_captec_product_type'][0] : 'Produto asfáltico',
			'description'   => isset( $meta['_captec_product_description'][0] ) ? $meta['_captec_product_description'][0] : wp_trim_words( $post->post_content, 24, '' ),
			'applications'  => isset( $meta['_captec_product_applications'][0] ) ? $meta['_captec_product_applications'][0] : '',
			'image'         => $image ? $image : $fallbacks[ $index % count( $fallbacks ) ]['image'],
			'file'          => isset( $meta['_captec_product_file'][0] ) ? $meta['_captec_product_file'][0] : '',
		);
	}
	return $items;
}

function captec_default_applications() {
	$asset = 'assets/images/';
	return array(
		array( 'title' => 'Rodovias', 'subtitle' => 'Infraestrutura viária', 'image' => $asset . 'app-highways.jpg' ),
		array( 'title' => 'Pavimentação Urbana', 'subtitle' => 'Cidades em movimento', 'image' => $asset . 'app-urban.jpg' ),
		array( 'title' => 'Condomínios', 'subtitle' => 'Acessos e vias internas', 'image' => $asset . 'app-condo.jpg' ),
		array( 'title' => 'Portos', 'subtitle' => 'Áreas logísticas', 'image' => $asset . 'app-industrial.jpg' ),
		array( 'title' => 'Aeroportos', 'subtitle' => 'Operações aeroportuárias', 'image' => $asset . 'app-airport.jpg' ),
		array( 'title' => 'Concessionárias', 'subtitle' => 'Manutenção viária', 'image' => $asset . 'app-concession.jpg' ),
		array( 'title' => 'Prefeituras', 'subtitle' => 'Infraestrutura urbana', 'image' => $asset . 'app-municipal.jpg' ),
		array( 'title' => 'Obras Industriais', 'subtitle' => 'Pátios e acessos', 'image' => $asset . 'app-industrial.jpg' ),
	);
}

function captec_applications() {
	$query = new WP_Query( array(
		'post_type'      => 'captec_application',
		'post_status'    => captec_is_admin_preview() ? array( 'publish', 'draft' ) : 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	) );
	if ( ! $query->have_posts() ) {
		return captec_default_applications();
	}
	$items     = array();
	$fallbacks = captec_default_applications();
	foreach ( $query->posts as $index => $post ) {
		$image = get_the_post_thumbnail_url( $post, 'large' );
		$items[] = array(
			'id'       => $post->ID,
			'title'    => get_the_title( $post ),
			'subtitle' => get_post_meta( $post->ID, '_captec_application_subtitle', true ),
			'image'    => $image ? $image : $fallbacks[ $index % count( $fallbacks ) ]['image'],
		);
	}
	return $items;
}

/** Unidades institucionais. Se ainda não houver cadastros, usa os dados verificados nos comprovantes enviados. */
function captec_default_locations() {
	return array(
		array(
			'title'        => 'Matriz — Duque de Caxias/RJ',
			'kind'         => 'headquarters',
			'company_name' => 'CAPTEC ASFALTOS LTDA',
			'cnpj'         => '63.476.653/0001-61',
			'street'       => 'R. Mascarenhas de Morais',
			'number'       => '2105',
			'complement'   => 'Quadra 24F, Lote 34',
			'neighborhood' => 'Figueira',
			'city'         => 'Duque de Caxias',
			'state'        => 'RJ',
			'cep'          => '25.231-050',
			'phone'        => '(92) 9556-2152',
			'email'        => 'captec.asfalto@hotmail.com',
			'map_url'      => '',
		),
		array(
			'title'        => 'Filial — Salvador/BA',
			'kind'         => 'branch',
			'company_name' => 'CAPTEC ASFALTOS LTDA',
			'cnpj'         => '63.476.653/0002-42',
			'street'       => 'R. da Mauritânia',
			'number'       => '40',
			'complement'   => 'Galpão 0002',
			'neighborhood' => 'Granjas Rurais Presidente Vargas',
			'city'         => 'Salvador',
			'state'        => 'BA',
			'cep'          => '41.230-040',
			'phone'        => '(92) 9556-2152',
			'email'        => 'captec.asfalto@hotmail.com',
			'map_url'      => '',
		),
		array(
			'title'        => 'Filial — Manaus/AM',
			'kind'         => 'branch',
			'company_name' => 'CAPTEC ASFALTOS LTDA',
			'cnpj'         => '63.476.653/0003-23',
			'street'       => 'BC Jurema',
			'number'       => '50',
			'complement'   => '',
			'neighborhood' => 'Vila Buriti',
			'city'         => 'Manaus',
			'state'        => 'AM',
			'cep'          => '69.072-010',
			'phone'        => '(92) 9472-3574',
			'email'        => 'captec.asfalto@hotmail.com',
			'map_url'      => '',
		),
	);
}

function captec_locations() {
	$query = new WP_Query( array(
		'post_type'      => 'captec_location',
		'post_status'    => captec_is_admin_preview() ? array( 'publish', 'draft' ) : 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	) );
	if ( ! $query->have_posts() ) {
		return captec_default_locations();
	}
	$items = array();
	foreach ( $query->posts as $post ) {
		$meta = array();
		foreach ( array( 'kind', 'company_name', 'cnpj', 'street', 'number', 'complement', 'neighborhood', 'city', 'state', 'cep', 'phone', 'email', 'map_url' ) as $key ) {
			$meta[ $key ] = get_post_meta( $post->ID, '_captec_location_' . $key, true );
		}
		$meta['id']    = $post->ID;
		$meta['title'] = get_the_title( $post );
		$items[]       = $meta;
	}
	return $items;
}

function captec_location_address( $location ) {
	$parts = array_filter( array(
		trim( ( isset( $location['street'] ) ? $location['street'] : '' ) . ( ! empty( $location['number'] ) ? ', ' . $location['number'] : '' ) ),
		isset( $location['complement'] ) ? $location['complement'] : '',
		isset( $location['neighborhood'] ) ? $location['neighborhood'] : '',
		trim( ( isset( $location['city'] ) ? $location['city'] : '' ) . ( ! empty( $location['state'] ) ? '/' . $location['state'] : '' ) ),
		isset( $location['cep'] ) ? 'CEP ' . $location['cep'] : '',
	) );
	return implode( ' — ', $parts );
}

function captec_location_map_url( $location ) {
	if ( ! empty( $location['map_url'] ) ) {
		return esc_url( $location['map_url'] );
	}
	$query = captec_location_address( $location );
	return $query ? esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $query ) ) : '';
}

function captec_stats() {
	if ( post_type_exists( 'captec_stat' ) ) {
		$records = get_posts( array(
			'post_type'      => 'captec_stat',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) );
		if ( $records || get_option( 'captec_stats_configured', false ) ) {
			$items = array();
			foreach ( $records as $record ) {
				if ( 'draft' === $record->post_status && ! captec_is_admin_preview() ) {
					continue;
				}
				$label = sanitize_text_field( get_post_meta( $record->ID, '_captec_stat_label', true ) );
				$items[] = array(
					'label' => $label ? $label : get_the_title( $record ),
					'value' => sanitize_text_field( get_post_meta( $record->ID, '_captec_stat_value', true ) ),
				);
			}
			return $items;
		}
	}

	$labels = array( 'Clientes Atendidos', 'Estados Atendidos', 'Produtos Comercializados', 'Obras Atendidas', 'Toneladas Fornecidas' );
	$stats  = array();
	foreach ( $labels as $index => $label ) {
		$key      = $index + 1;
		$stats[] = array(
			'label' => sanitize_text_field( captec_mod( 'captec_stat_' . $key . '_label', $label ) ),
			'value' => sanitize_text_field( captec_mod( 'captec_stat_' . $key . '_value', '' ) ),
		);
	}
	return $stats;
}

/** Separa valor numérico e sufixo para o contador animado. */
function captec_counter_parts( $value ) {
	$value = trim( (string) $value );
	if ( ! preg_match( '/^([0-9][0-9.\s,]*)(.*)$/u', $value, $matches ) ) {
		return array( 'number' => '', 'suffix' => $value );
	}
	$number = (int) preg_replace( '/\D+/', '', $matches[1] );
	return array( 'number' => $number, 'suffix' => trim( $matches[2] ) );
}

/** Limpa as regras após ativar o tema, incluindo URLs dos conteúdos CAPTEC. */
function captec_theme_activated() {
	captec_register_content_types();
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'captec_theme_activated' );

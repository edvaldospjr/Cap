<?php
 defined( 'ABSPATH' ) || exit;
 $menu_mode = captec_mod( 'captec_menu_mode', 'scroll' );
 if ( ! in_array( $menu_mode, array( 'scroll', 'image', 'fixed' ), true ) ) {
 	$menu_mode = 'scroll';
 }
 $header_class = 'site-header captec-menu--' . $menu_mode . ( is_front_page() ? '' : ' site-header--solid' );
 $header_quote_button = captec_site_button_markup(
 	'header_quote',
 	array( 'label' => 'Solicitar cotação', 'action' => 'quote', 'style' => 'yellow' ),
 	array( 'class' => 'button--small header-quote', 'icon' => 'arrow-right' )
 );
?>
<!doctype html>
<html <?php language_attributes(); ?> data-theme="light">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#111111">
	<script>document.documentElement.classList.add('js');try{document.documentElement.dataset.theme=localStorage.getItem('captec-theme')||'light';}catch(e){}</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="screen-reader-text" href="#conteudo-principal"><?php esc_html_e( 'Pular para o conteúdo', 'captec-asfaltos' ); ?></a>
<header class="<?php echo esc_attr( $header_class ); ?>" data-site-header>
	<div class="shell header-inner">
		<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php esc_attr_e( 'CAPTEC Asfaltos — Quem somos', 'captec-asfaltos' ); ?>">
			<?php echo captec_brand_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup SVG/logo do tema. ?>
		</a>
		<nav class="primary-nav" id="primary-navigation" aria-label="<?php esc_attr_e( 'Navegação principal', 'captec-asfaltos' ); ?>" data-primary-nav>
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'fallback_cb'    => 'captec_primary_menu_fallback',
				'depth'          => 1,
			) );
			?>
		</nav>
		<div class="header-actions">
			<?php echo $header_quote_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<button class="nav-toggle" type="button" data-nav-toggle aria-expanded="false" aria-controls="primary-navigation" aria-label="<?php esc_attr_e( 'Abrir menu', 'captec-asfaltos' ); ?>">
				<span data-nav-icon><?php echo captec_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</button>
		</div>
	</div>
</header>

<?php
defined( 'ABSPATH' ) || exit;
get_header();
$preview_query = captec_is_admin_preview() ? new WP_Query( array( 'post_type' => 'post', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => get_option( 'posts_per_page' ), 'paged' => max( 1, get_query_var( 'paged' ) ) ) ) : null;
$query = $preview_query ? $preview_query : $wp_query;
?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_blog_eyebrow', 'Conteúdos' ) ); ?></p><h1 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_blog_title', 'Informação técnica para decisões mais claras.' ) ) ); ?></h1><p class="page-hero__intro"><?php esc_html_e( 'Artigos e referências para apoiar conversas sobre pavimentação, produtos e infraestrutura.', 'captec-asfaltos' ); ?></p></div></header>
	<?php if ( captec_feature_enabled( 'blog', true ) ) : ?>
	<section class="section"><div class="shell">
		<?php if ( $query->have_posts() ) : ?><div class="blog-grid"><?php while ( $query->have_posts() ) : $query->the_post(); ?><article <?php post_class( 'article-card article-card--post' ); ?>><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'large', array( 'class' => 'article-card__image', 'loading' => 'lazy', 'decoding' => 'async' ) ); } ?><div class="article-card__content"><span class="article-card__category"><?php echo esc_html( 'draft' === get_post_status() ? __( 'Prévia de rascunho', 'captec-asfaltos' ) : ( get_the_category_list( ', ' ) ? wp_strip_all_tags( get_the_category_list( ', ' ) ) : __( 'Conteúdo', 'captec-asfaltos' ) ) ); ?></span><h2><?php the_title(); ?></h2><a class="text-link" href="<?php echo esc_url( captec_is_admin_preview() && 'draft' === get_post_status() ? get_preview_post_link( get_the_ID() ) : get_permalink() ); ?>"><?php esc_html_e( 'Ler artigo', 'captec-asfaltos' ); ?><span class="arrow">→</span></a></div></article><?php endwhile; ?></div><?php if ( ! captec_is_admin_preview() ) { the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => '←', 'next_text' => '→' ) ); } ?>
		<?php else : ?><div class="entry-content"><h2><?php esc_html_e( 'Conteúdos em preparação', 'captec-asfaltos' ); ?></h2><p><?php esc_html_e( 'Em breve, esta área receberá novos conteúdos. Referências oficiais sobre asfaltos e pavimentação estão disponíveis na página de Produtos.', 'captec-asfaltos' ); ?></p></div><?php endif; ?>
	</div></section>
	<?php endif; ?>
</main>
<?php if ( $preview_query ) { wp_reset_postdata(); } get_footer();

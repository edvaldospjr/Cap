<?php
/** Tipos de conteúdo e campos nativos administráveis. */

defined( 'ABSPATH' ) || exit;

function captec_register_content_types() {
	register_post_type( 'captec_product', array(
		'labels' => array(
			'name'               => __( 'Produtos', 'captec-asfaltos' ),
			'singular_name'      => __( 'Produto', 'captec-asfaltos' ),
			'add_new'            => __( 'Adicionar produto', 'captec-asfaltos' ),
			'add_new_item'       => __( 'Adicionar produto', 'captec-asfaltos' ),
			'edit_item'          => __( 'Editar produto', 'captec-asfaltos' ),
			'new_item'           => __( 'Novo produto', 'captec-asfaltos' ),
			'view_item'          => __( 'Ver produto', 'captec-asfaltos' ),
			'search_items'       => __( 'Buscar produtos', 'captec-asfaltos' ),
			'not_found'          => __( 'Nenhum produto encontrado.', 'captec-asfaltos' ),
			'menu_name'          => __( 'Produtos CAPTEC', 'captec-asfaltos' ),
		),
		'public'             => true,
		'has_archive'        => false,
		'rewrite'            => array( 'slug' => 'produto' ),
		'menu_icon'          => 'dashicons-admin-generic',
		'show_in_rest'       => true,
		'supports'           => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'menu_position'      => 21,
		'publicly_queryable' => true,
	) );

	register_post_type( 'captec_application', array(
		'labels' => array(
			'name'               => __( 'Aplicações', 'captec-asfaltos' ),
			'singular_name'      => __( 'Aplicação', 'captec-asfaltos' ),
			'add_new'            => __( 'Adicionar aplicação', 'captec-asfaltos' ),
			'add_new_item'       => __( 'Adicionar aplicação', 'captec-asfaltos' ),
			'edit_item'          => __( 'Editar aplicação', 'captec-asfaltos' ),
			'new_item'           => __( 'Nova aplicação', 'captec-asfaltos' ),
			'view_item'          => __( 'Ver aplicação', 'captec-asfaltos' ),
			'search_items'       => __( 'Buscar aplicações', 'captec-asfaltos' ),
			'not_found'          => __( 'Nenhuma aplicação encontrada.', 'captec-asfaltos' ),
			'menu_name'          => __( 'Aplicações CAPTEC', 'captec-asfaltos' ),
		),
		'public'             => true,
		'has_archive'        => false,
		'rewrite'            => array( 'slug' => 'aplicacao' ),
		'menu_icon'          => 'dashicons-location-alt',
		'show_in_rest'       => true,
		'supports'           => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
		'menu_position'      => 22,
		'publicly_queryable' => true,
	) );

	register_post_type( 'captec_location', array(
		'labels' => array(
			'name'               => __( 'Unidades', 'captec-asfaltos' ),
			'singular_name'      => __( 'Unidade', 'captec-asfaltos' ),
			'add_new'            => __( 'Adicionar unidade', 'captec-asfaltos' ),
			'add_new_item'       => __( 'Adicionar unidade', 'captec-asfaltos' ),
			'edit_item'          => __( 'Editar unidade', 'captec-asfaltos' ),
			'new_item'           => __( 'Nova unidade', 'captec-asfaltos' ),
			'view_item'          => __( 'Ver unidade', 'captec-asfaltos' ),
			'search_items'       => __( 'Buscar unidades', 'captec-asfaltos' ),
			'not_found'          => __( 'Nenhuma unidade encontrada.', 'captec-asfaltos' ),
			'menu_name'          => __( 'Unidades CAPTEC', 'captec-asfaltos' ),
		),
		'public'             => true,
		'has_archive'        => false,
		'rewrite'            => array( 'slug' => 'unidade' ),
		'menu_icon'          => 'dashicons-building',
		'show_in_rest'       => true,
		'supports'           => array( 'title', 'thumbnail', 'page-attributes' ),
		'menu_position'      => 23,
		'publicly_queryable' => true,
	) );

	register_post_type( 'captec_button', array(
		'labels' => array(
			'name'          => __( 'Botões do site', 'captec-asfaltos' ),
			'singular_name' => __( 'Botão do site', 'captec-asfaltos' ),
		),
		'public'             => false,
		'show_ui'            => false,
		'show_in_menu'       => false,
		'show_in_rest'       => false,
		'supports'           => array( 'title', 'page-attributes' ),
		'capability_type'    => 'post',
		'map_meta_cap'       => true,
		'publicly_queryable' => false,
	) );

	register_post_type( 'captec_footer_item', array(
		'labels' => array(
			'name'          => __( 'Itens do rodapé', 'captec-asfaltos' ),
			'singular_name' => __( 'Item do rodapé', 'captec-asfaltos' ),
		),
		'public'             => false,
		'show_ui'            => false,
		'show_in_menu'       => false,
		'show_in_rest'       => false,
		'supports'           => array( 'title', 'page-attributes' ),
		'capability_type'    => 'post',
		'map_meta_cap'       => true,
		'publicly_queryable' => false,
	) );

	register_post_type( 'captec_stat', array(
		'labels' => array(
			'name'          => __( 'Indicadores institucionais', 'captec-asfaltos' ),
			'singular_name' => __( 'Indicador institucional', 'captec-asfaltos' ),
		),
		'public'             => false,
		'show_ui'            => false,
		'show_in_menu'       => false,
		'show_in_rest'       => false,
		'supports'           => array( 'title', 'page-attributes' ),
		'capability_type'    => 'post',
		'map_meta_cap'       => true,
		'publicly_queryable' => false,
	) );

	register_post_type( 'captec_quote', array(
		'labels' => array(
			'name'          => __( 'Cotações', 'captec-asfaltos' ),
			'singular_name' => __( 'Cotação', 'captec-asfaltos' ),
			'menu_name'     => __( 'Cotações', 'captec-asfaltos' ),
			'edit_item'     => __( 'Detalhes da cotação', 'captec-asfaltos' ),
			'not_found'     => __( 'Nenhuma cotação recebida.', 'captec-asfaltos' ),
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-clipboard',
		'menu_position'   => 24,
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
		'map_meta_cap'    => true,
	) );
}
add_action( 'init', 'captec_register_content_types' );

function captec_add_meta_boxes() {
	add_meta_box( 'captec_product_information', __( 'Informações do produto', 'captec-asfaltos' ), 'captec_product_meta_box', 'captec_product', 'normal', 'high' );
	add_meta_box( 'captec_application_information', __( 'Informações da aplicação', 'captec-asfaltos' ), 'captec_application_meta_box', 'captec_application', 'normal', 'high' );
	add_meta_box( 'captec_location_information', __( 'Informações da unidade', 'captec-asfaltos' ), 'captec_location_meta_box', 'captec_location', 'normal', 'high' );
	add_meta_box( 'captec_quote_information', __( 'Dados da solicitação', 'captec-asfaltos' ), 'captec_quote_meta_box', 'captec_quote', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'captec_add_meta_boxes' );

function captec_product_meta_box( $post ) {
	wp_nonce_field( 'captec_save_product_meta', 'captec_product_meta_nonce' );
	$type         = get_post_meta( $post->ID, '_captec_product_type', true );
	$description  = get_post_meta( $post->ID, '_captec_product_description', true );
	$applications = get_post_meta( $post->ID, '_captec_product_applications', true );
	$file         = get_post_meta( $post->ID, '_captec_product_file', true );
	?>
	<p><label for="captec_product_type"><strong><?php esc_html_e( 'Categoria curta', 'captec-asfaltos' ); ?></strong></label><br>
	<input class="widefat" id="captec_product_type" name="captec_product_type" type="text" value="<?php echo esc_attr( $type ); ?>" placeholder="Ex.: Emulsão asfáltica"></p>
	<p><label for="captec_product_description"><strong><?php esc_html_e( 'Descrição resumida', 'captec-asfaltos' ); ?></strong></label><br>
	<textarea class="widefat" id="captec_product_description" name="captec_product_description" rows="3" placeholder="Texto exibido no card."><?php echo esc_textarea( $description ); ?></textarea></p>
	<p><label for="captec_product_applications"><strong><?php esc_html_e( 'Aplicações', 'captec-asfaltos' ); ?></strong></label><br>
	<input class="widefat" id="captec_product_applications" name="captec_product_applications" type="text" value="<?php echo esc_attr( $applications ); ?>" placeholder="Ex.: Aplicações definidas no projeto técnico."></p>
	<p><label for="captec_product_file"><strong><?php esc_html_e( 'Ficha técnica (arquivo da Biblioteca de Mídia)', 'captec-asfaltos' ); ?></strong></label><br>
	<input class="widefat captec-media-url" id="captec_product_file" name="captec_product_file" type="url" value="<?php echo esc_url( $file ); ?>" placeholder="https://.../ficha-tecnica.pdf" style="max-width:75%;">
	<button type="button" class="button captec-select-media" data-target="#captec_product_file"><?php esc_html_e( 'Selecionar arquivo', 'captec-asfaltos' ); ?></button><br>
	<small><?php esc_html_e( 'Use a imagem destacada para a foto do card. Use PDF para a ficha técnica sempre que possível.', 'captec-asfaltos' ); ?></small></p>
	<?php
}

function captec_application_meta_box( $post ) {
	wp_nonce_field( 'captec_save_application_meta', 'captec_application_meta_nonce' );
	$subtitle = get_post_meta( $post->ID, '_captec_application_subtitle', true );
	?>
	<p><label for="captec_application_subtitle"><strong><?php esc_html_e( 'Linha de apoio', 'captec-asfaltos' ); ?></strong></label><br>
	<input class="widefat" id="captec_application_subtitle" name="captec_application_subtitle" type="text" value="<?php echo esc_attr( $subtitle ); ?>" placeholder="Ex.: Infraestrutura viária"></p>
	<p><small><?php esc_html_e( 'Defina uma imagem destacada em formato horizontal para o card da Home.', 'captec-asfaltos' ); ?></small></p>
	<?php
}

function captec_location_meta_box( $post ) {
	wp_nonce_field( 'captec_save_location_meta', 'captec_location_meta_nonce' );
	$values = array();
	$keys   = array( 'kind', 'company_name', 'cnpj', 'street', 'number', 'complement', 'neighborhood', 'city', 'state', 'cep', 'phone', 'email', 'map_url' );
	foreach ( $keys as $key ) {
		$values[ $key ] = get_post_meta( $post->ID, '_captec_location_' . $key, true );
	}
	?>
	<p><label for="captec_location_kind"><strong><?php esc_html_e( 'Tipo de unidade', 'captec-asfaltos' ); ?></strong></label><br>
	<select id="captec_location_kind" name="captec_location_kind"><option value="headquarters" <?php selected( $values['kind'], 'headquarters' ); ?>><?php esc_html_e( 'Matriz', 'captec-asfaltos' ); ?></option><option value="branch" <?php selected( $values['kind'], 'branch' ); ?>><?php esc_html_e( 'Filial', 'captec-asfaltos' ); ?></option></select></p>
	<table class="form-table" role="presentation"><tbody>
	<tr><th><label for="captec_location_company_name"><?php esc_html_e( 'Razão social', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_company_name" name="captec_location_company_name" type="text" value="<?php echo esc_attr( $values['company_name'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_cnpj"><?php esc_html_e( 'CNPJ', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_cnpj" name="captec_location_cnpj" type="text" value="<?php echo esc_attr( $values['cnpj'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_street"><?php esc_html_e( 'Logradouro', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_street" name="captec_location_street" type="text" value="<?php echo esc_attr( $values['street'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_number"><?php esc_html_e( 'Número', 'captec-asfaltos' ); ?></label></th><td><input class="small-text" id="captec_location_number" name="captec_location_number" type="text" value="<?php echo esc_attr( $values['number'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_complement"><?php esc_html_e( 'Complemento', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_complement" name="captec_location_complement" type="text" value="<?php echo esc_attr( $values['complement'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_neighborhood"><?php esc_html_e( 'Bairro', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_neighborhood" name="captec_location_neighborhood" type="text" value="<?php echo esc_attr( $values['neighborhood'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_city"><?php esc_html_e( 'Cidade', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_city" name="captec_location_city" type="text" value="<?php echo esc_attr( $values['city'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_state"><?php esc_html_e( 'UF', 'captec-asfaltos' ); ?></label></th><td><input class="small-text" maxlength="2" id="captec_location_state" name="captec_location_state" type="text" value="<?php echo esc_attr( $values['state'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_cep"><?php esc_html_e( 'CEP', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_cep" name="captec_location_cep" type="text" value="<?php echo esc_attr( $values['cep'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_phone"><?php esc_html_e( 'Telefone', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_phone" name="captec_location_phone" type="text" value="<?php echo esc_attr( $values['phone'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_email"><?php esc_html_e( 'E-mail', 'captec-asfaltos' ); ?></label></th><td><input class="regular-text" id="captec_location_email" name="captec_location_email" type="email" value="<?php echo esc_attr( $values['email'] ); ?>"></td></tr>
	<tr><th><label for="captec_location_map_url"><?php esc_html_e( 'URL do mapa', 'captec-asfaltos' ); ?></label></th><td><input class="widefat" id="captec_location_map_url" name="captec_location_map_url" type="url" value="<?php echo esc_url( $values['map_url'] ); ?>" placeholder="https://www.google.com/maps/..."></td></tr>
	</tbody></table>
	<?php
}

function captec_quote_meta_box( $post ) {
	$fields = array(
		'_captec_quote_company'   => __( 'Empresa', 'captec-asfaltos' ),
		'_captec_quote_phone'     => __( 'Telefone', 'captec-asfaltos' ),
		'_captec_quote_whatsapp'  => __( 'WhatsApp', 'captec-asfaltos' ),
		'_captec_quote_city'      => __( 'Cidade', 'captec-asfaltos' ),
		'_captec_quote_state'     => __( 'Estado', 'captec-asfaltos' ),
		'_captec_quote_product'   => __( 'Produto', 'captec-asfaltos' ),
		'_captec_quote_quantity'  => __( 'Quantidade', 'captec-asfaltos' ),
		'_captec_quote_message'   => __( 'Mensagem', 'captec-asfaltos' ),
		'_captec_quote_file_url'  => __( 'Arquivo enviado', 'captec-asfaltos' ),
	);
	$name = get_post_meta( $post->ID, '_captec_quote_name', true );
	if ( $name ) {
		echo '<p><strong>' . esc_html__( 'Nome:', 'captec-asfaltos' ) . '</strong> ' . esc_html( $name ) . '</p>';
	}
	echo '<table class="widefat striped" style="border:0">';
	foreach ( $fields as $meta_key => $label ) {
		$value = get_post_meta( $post->ID, $meta_key, true );
		if ( '' === $value ) {
			continue;
		}
		echo '<tr><td style="width:180px"><strong>' . esc_html( $label ) . '</strong></td><td>';
		if ( '_captec_quote_file_url' === $meta_key ) {
			echo '<a href="' . esc_url( $value ) . '" target="_blank" rel="noopener">' . esc_html__( 'Abrir arquivo', 'captec-asfaltos' ) . '</a>';
		} elseif ( '_captec_quote_message' === $meta_key ) {
			echo nl2br( esc_html( $value ) );
		} else {
			echo esc_html( $value );
		}
		echo '</td></tr>';
	}
	echo '</table>';
	echo '<p><small>' . esc_html__( 'Dados pessoais recebidos exclusivamente para atendimento da solicitação. Elimine registros que não sejam mais necessários, conforme sua política de retenção.', 'captec-asfaltos' ) . '</small></p>';
}

function captec_save_product_meta( $post_id ) {
	if ( ! isset( $_POST['captec_product_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['captec_product_meta_nonce'] ) ), 'captec_save_product_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$fields = array(
		'captec_product_type'         => '_captec_product_type',
		'captec_product_description'  => '_captec_product_description',
		'captec_product_applications' => '_captec_product_applications',
	);
	foreach ( $fields as $input => $meta ) {
		if ( isset( $_POST[ $input ] ) ) {
			update_post_meta( $post_id, $meta, sanitize_textarea_field( wp_unslash( $_POST[ $input ] ) ) );
		}
	}
	if ( isset( $_POST['captec_product_file'] ) ) {
		update_post_meta( $post_id, '_captec_product_file', esc_url_raw( wp_unslash( $_POST['captec_product_file'] ) ) );
	}
}
add_action( 'save_post_captec_product', 'captec_save_product_meta' );

function captec_save_application_meta( $post_id ) {
	if ( ! isset( $_POST['captec_application_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['captec_application_meta_nonce'] ) ), 'captec_save_application_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['captec_application_subtitle'] ) ) {
		update_post_meta( $post_id, '_captec_application_subtitle', sanitize_text_field( wp_unslash( $_POST['captec_application_subtitle'] ) ) );
	}
}
add_action( 'save_post_captec_application', 'captec_save_application_meta' );

function captec_save_location_meta( $post_id ) {
	if ( ! isset( $_POST['captec_location_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['captec_location_meta_nonce'] ) ), 'captec_save_location_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$fields = array( 'kind', 'company_name', 'cnpj', 'street', 'number', 'complement', 'neighborhood', 'city', 'state', 'cep', 'phone', 'email', 'map_url' );
	foreach ( $fields as $field ) {
		$input = 'captec_location_' . $field;
		if ( ! isset( $_POST[ $input ] ) ) {
			continue;
		}
		$value = wp_unslash( $_POST[ $input ] );
		if ( 'map_url' === $field ) {
			$value = esc_url_raw( $value );
		} elseif ( 'email' === $field ) {
			$value = sanitize_email( $value );
		} elseif ( 'state' === $field ) {
			$value = strtoupper( preg_replace( '/[^A-Za-z]/', '', sanitize_text_field( $value ) ) );
		} elseif ( 'kind' === $field ) {
			$value = in_array( $value, array( 'headquarters', 'branch' ), true ) ? $value : 'branch';
		} else {
			$value = sanitize_text_field( $value );
		}
		update_post_meta( $post_id, '_captec_location_' . $field, $value );
	}
}
add_action( 'save_post_captec_location', 'captec_save_location_meta' );

function captec_quote_columns( $columns ) {
	return array(
		'cb'       => '<input type="checkbox" />',
		'title'    => __( 'Solicitante', 'captec-asfaltos' ),
		'product'  => __( 'Produto', 'captec-asfaltos' ),
		'location' => __( 'Localidade', 'captec-asfaltos' ),
		'date'     => __( 'Recebida em', 'captec-asfaltos' ),
	);
}
add_filter( 'manage_captec_quote_posts_columns', 'captec_quote_columns' );

function captec_quote_column_content( $column, $post_id ) {
	if ( 'product' === $column ) {
		echo esc_html( get_post_meta( $post_id, '_captec_quote_product', true ) );
	}
	if ( 'location' === $column ) {
		$city  = get_post_meta( $post_id, '_captec_quote_city', true );
		$state = get_post_meta( $post_id, '_captec_quote_state', true );
		echo esc_html( trim( $city . ( $city && $state ? ' / ' : '' ) . $state ) );
	}
}
add_action( 'manage_captec_quote_posts_custom_column', 'captec_quote_column_content', 10, 2 );

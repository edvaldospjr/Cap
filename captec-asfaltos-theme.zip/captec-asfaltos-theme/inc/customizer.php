<?php
/** Opções editáveis no Personalizar > CAPTEC — Configurações. */

defined( 'ABSPATH' ) || exit;

function captec_sanitize_textarea( $value ) {
	return sanitize_textarea_field( $value );
}
function captec_sanitize_url( $value ) {
	return esc_url_raw( $value );
}
function captec_sanitize_phone( $value ) {
	return preg_replace( '/[^0-9+()\-\s]/', '', (string) $value );
}
function captec_sanitize_state_codes( $value ) {
	$value = strtoupper( preg_replace( '/[^A-Za-z,\s]/', '', (string) $value ) );
	$parts = array_filter( array_map( 'trim', explode( ',', $value ) ) );
	return implode( ', ', array_unique( $parts ) );
}
function captec_sanitize_tracking_id( $value ) {
	return preg_replace( '/[^A-Za-z0-9\-_]/', '', (string) $value );
}
function captec_sanitize_pixel_id( $value ) {
	return preg_replace( '/\D+/', '', (string) $value );
}

function captec_customize_register( $wp_customize ) {
	$wp_customize->add_panel( 'captec_settings', array(
		'title'       => __( 'CAPTEC — Configurações', 'captec-asfaltos' ),
		'description' => __( 'Conteúdos institucionais, contatos e integrações do portal.', 'captec-asfaltos' ),
		'priority'    => 28,
	) );

	$wp_customize->add_section( 'captec_hero', array(
		'title'    => __( 'Hero da Home', 'captec-asfaltos' ),
		'panel'    => 'captec_settings',
		'priority' => 10,
	) );
	captec_customizer_text( $wp_customize, 'captec_hero_title', 'captec_hero', __( 'Título principal', 'captec-asfaltos' ), 'CAPTEC ASFALTOS' );
	captec_customizer_text( $wp_customize, 'captec_hero_subtitle', 'captec_hero', __( 'Subtítulo', 'captec-asfaltos' ), 'Soluções inteligentes para pavimentação e infraestrutura.' );
	captec_customizer_textarea( $wp_customize, 'captec_hero_text', 'captec_hero', __( 'Texto de apoio', 'captec-asfaltos' ), 'Especialistas no fornecimento de produtos asfálticos para obras públicas e privadas com atendimento consultivo, eficiência logística e compromisso com resultados.' );
	captec_customizer_media( $wp_customize, 'captec_hero_poster', 'captec_hero', __( 'Imagem de fallback do vídeo', 'captec-asfaltos' ), __( 'Exibida enquanto o vídeo carrega e em dispositivos que bloquearem reprodução automática.', 'captec-asfaltos' ) );
	captec_customizer_url( $wp_customize, 'captec_hero_video_url', 'captec_hero', __( 'URL do vídeo de fundo', 'captec-asfaltos' ), __( 'Envie um MP4 otimizado para a Biblioteca de Mídia e cole a URL. Sem preenchimento, o vídeo otimizado incluso no tema é utilizado.', 'captec-asfaltos' ) );

	$wp_customize->add_section( 'captec_about', array(
		'title'    => __( 'Quem somos', 'captec-asfaltos' ),
		'panel'    => 'captec_settings',
		'priority' => 15,
	) );
	captec_customizer_text( $wp_customize, 'captec_about_eyebrow', 'captec_about', __( 'Etiqueta', 'captec-asfaltos' ), 'Quem somos' );
	captec_customizer_textarea( $wp_customize, 'captec_about_title', 'captec_about', __( 'Título', 'captec-asfaltos' ), 'Distribuição que conecta qualidade, planejamento e resultado.' );
	captec_customizer_textarea( $wp_customize, 'captec_about_text_1', 'captec_about', __( 'Primeiro parágrafo', 'captec-asfaltos' ), 'A CAPTEC Asfaltos atua na distribuição de produtos asfálticos para obras públicas e privadas, com foco em qualidade, relacionamento e eficiência.' );
	captec_customizer_textarea( $wp_customize, 'captec_about_text_2', 'captec_about', __( 'Segundo parágrafo', 'captec-asfaltos' ), 'Da demanda inicial à entrega, trabalhamos para tornar o processo comercial mais claro e alinhado às necessidades de cada projeto.' );
	captec_customizer_media( $wp_customize, 'captec_about_image', 'captec_about', __( 'Imagem da seção', 'captec-asfaltos' ), __( 'Use uma imagem horizontal de rodovia ou infraestrutura.', 'captec-asfaltos' ) );

	$wp_customize->add_section( 'captec_careers', array(
		'title'       => __( 'Trabalhe conosco', 'captec-asfaltos' ),
		'description' => __( 'Personalize a página de candidaturas. Se o e-mail específico ficar vazio, o e-mail comercial é usado.', 'captec-asfaltos' ),
		'panel'       => 'captec_settings',
		'priority'    => 18,
	) );
	captec_customizer_text( $wp_customize, 'captec_careers_eyebrow', 'captec_careers', __( 'Etiqueta', 'captec-asfaltos' ), 'Trabalhe conosco' );
	captec_customizer_textarea( $wp_customize, 'captec_careers_title', 'captec_careers', __( 'Título', 'captec-asfaltos' ), 'Construa caminhos com a CAPTEC.' );
	captec_customizer_textarea( $wp_customize, 'captec_careers_text', 'captec_careers', __( 'Texto de apresentação', 'captec-asfaltos' ), 'Se você deseja fazer parte do nosso time, envie seu currículo para análise.' );
	captec_customizer_textarea( $wp_customize, 'captec_careers_instruction', 'captec_careers', __( 'Orientação para candidatura', 'captec-asfaltos' ), 'No e-mail, informe sua cidade/UF, área de interesse e envie o currículo em PDF.' );
	captec_customizer_text( $wp_customize, 'captec_careers_email', 'captec_careers', __( 'E-mail para currículos', 'captec-asfaltos' ), '', 'sanitize_email', __( 'Opcional. Se ficar vazio, será usado o e-mail comercial.', 'captec-asfaltos' ) );
	captec_customizer_text( $wp_customize, 'captec_careers_button_label', 'captec_careers', __( 'Texto do botão', 'captec-asfaltos' ), 'Enviar currículo' );
	captec_customizer_textarea( $wp_customize, 'captec_careers_note', 'captec_careers', __( 'Observação final', 'captec-asfaltos' ), 'As candidaturas são avaliadas conforme as necessidades da empresa.' );

	$wp_customize->add_section( 'captec_contact', array(
		'title'       => __( 'Contatos e rodapé', 'captec-asfaltos' ),
		'description' => __( 'Preencha os canais oficiais antes de publicar o site. Campos vazios não exibem dados inventados.', 'captec-asfaltos' ),
		'panel'       => 'captec_settings',
		'priority'    => 20,
	) );
	captec_customizer_text( $wp_customize, 'captec_phone', 'captec_contact', __( 'Telefone', 'captec-asfaltos' ), '', 'captec_sanitize_phone' );
	captec_customizer_text( $wp_customize, 'captec_whatsapp', 'captec_contact', __( 'WhatsApp (somente números com DDI)', 'captec-asfaltos' ), '', 'captec_sanitize_phone', __( 'Ex.: 5571XXXXXXXXX. Usado nos botões de WhatsApp.', 'captec-asfaltos' ) );
	captec_customizer_text( $wp_customize, 'captec_email', 'captec_contact', __( 'E-mail comercial', 'captec-asfaltos' ), '', 'sanitize_email' );
	captec_customizer_url( $wp_customize, 'captec_instagram', 'captec_contact', __( 'URL do Instagram', 'captec-asfaltos' ) );
	captec_customizer_url( $wp_customize, 'captec_linkedin', 'captec_contact', __( 'URL do LinkedIn', 'captec-asfaltos' ) );
	captec_customizer_url( $wp_customize, 'captec_maps_url', 'captec_contact', __( 'URL do Google Maps', 'captec-asfaltos' ) );
	captec_customizer_text( $wp_customize, 'captec_location_label', 'captec_contact', __( 'Localização exibida', 'captec-asfaltos' ), 'Salvador/BA' );
	captec_customizer_text( $wp_customize, 'captec_quote_email', 'captec_contact', __( 'E-mail que recebe as cotações', 'captec-asfaltos' ), get_option( 'admin_email' ), 'sanitize_email', __( 'Se ficar em branco, a cotação é enviada para o e-mail administrativo do WordPress.', 'captec-asfaltos' ) );

	$wp_customize->add_section( 'captec_stats', array(
		'title'       => __( 'Números e mapa', 'captec-asfaltos' ),
		'description' => __( 'Preencha somente números aprovados pela empresa. Os cards permanecem neutros até serem configurados.', 'captec-asfaltos' ),
		'panel'       => 'captec_settings',
		'priority'    => 25,
	) );
	$stat_labels = array( 'Clientes Atendidos', 'Estados Atendidos', 'Produtos Comercializados', 'Obras Atendidas', 'Toneladas Fornecidas' );
	foreach ( $stat_labels as $index => $label ) {
		$key = $index + 1;
		captec_customizer_text( $wp_customize, 'captec_stat_' . $key . '_label', 'captec_stats', sprintf( __( 'Rótulo %d', 'captec-asfaltos' ), $key ), $label );
		captec_customizer_text( $wp_customize, 'captec_stat_' . $key . '_value', 'captec_stats', sprintf( __( 'Valor %d', 'captec-asfaltos' ), $key ), '', 'sanitize_text_field', __( 'Aceita valor numérico e sufixo, como “250+” ou “1.500 t”.', 'captec-asfaltos' ) );
	}
	captec_customizer_text( $wp_customize, 'captec_active_states', 'captec_stats', __( 'Estados em destaque (siglas separadas por vírgula)', 'captec-asfaltos' ), '', 'captec_sanitize_state_codes', __( 'Ex.: BA, SE, AL. A configuração está pronta para expansão; não informe estados não atendidos.', 'captec-asfaltos' ) );
	captec_customizer_text( $wp_customize, 'captec_map_status_message', 'captec_stats', __( 'Mensagem após selecionar um estado', 'captec-asfaltos' ), 'disponível para atendimento', 'sanitize_text_field', __( 'Ex.: “disponível para atendimento”. O nome do estado é incluído automaticamente no mapa.', 'captec-asfaltos' ) );

	$wp_customize->add_section( 'captec_legal', array(
		'title'       => __( 'Privacidade e LGPD', 'captec-asfaltos' ),
		'description' => __( 'Crie e revise as políticas com orientação jurídica antes da publicação.', 'captec-asfaltos' ),
		'panel'       => 'captec_settings',
		'priority'    => 30,
	) );
	captec_customizer_url( $wp_customize, 'captec_privacy_url', 'captec_legal', __( 'URL da Política de Privacidade', 'captec-asfaltos' ) );
	captec_customizer_url( $wp_customize, 'captec_cookie_url', 'captec_legal', __( 'URL da Política de Cookies', 'captec-asfaltos' ) );

	$wp_customize->add_section( 'captec_integrations', array(
		'title'       => __( 'Medição e integrações', 'captec-asfaltos' ),
		'description' => __( 'As tags só são carregadas após o consentimento de cookies analíticos.', 'captec-asfaltos' ),
		'panel'       => 'captec_settings',
		'priority'    => 35,
	) );
	captec_customizer_text( $wp_customize, 'captec_ga4_id', 'captec_integrations', __( 'ID do Google Analytics 4', 'captec-asfaltos' ), '', 'captec_sanitize_tracking_id', __( 'Ex.: G-XXXXXXXXXX. Deixe vazio para não carregar o Google Analytics.', 'captec-asfaltos' ) );
	captec_customizer_text( $wp_customize, 'captec_meta_pixel_id', 'captec_integrations', __( 'ID do Meta Pixel', 'captec-asfaltos' ), '', 'captec_sanitize_pixel_id', __( 'Informe somente os números. Deixe vazio para não carregar o Pixel.', 'captec-asfaltos' ) );
}
add_action( 'customize_register', 'captec_customize_register' );

function captec_customizer_text( $customize, $id, $section, $label, $default = '', $sanitize = 'sanitize_text_field', $description = '' ) {
	$customize->add_setting( $id, array( 'default' => $default, 'sanitize_callback' => $sanitize, 'transport' => 'refresh' ) );
	$customize->add_control( $id, array( 'label' => $label, 'section' => $section, 'type' => 'text', 'description' => $description ) );
}
function captec_customizer_textarea( $customize, $id, $section, $label, $default = '', $description = '' ) {
	$customize->add_setting( $id, array( 'default' => $default, 'sanitize_callback' => 'captec_sanitize_textarea', 'transport' => 'refresh' ) );
	$customize->add_control( $id, array( 'label' => $label, 'section' => $section, 'type' => 'textarea', 'description' => $description ) );
}
function captec_customizer_url( $customize, $id, $section, $label, $description = '' ) {
	$customize->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'captec_sanitize_url', 'transport' => 'refresh' ) );
	$customize->add_control( $id, array( 'label' => $label, 'section' => $section, 'type' => 'url', 'description' => $description ) );
}
function captec_customizer_media( $customize, $id, $section, $label, $description = '' ) {
	$customize->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw', 'transport' => 'refresh' ) );
	$customize->add_control( new WP_Customize_Media_Control( $customize, $id, array( 'label' => $label, 'section' => $section, 'mime_type' => 'image', 'description' => $description ) ) );
}

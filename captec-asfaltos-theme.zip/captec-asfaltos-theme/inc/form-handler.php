<?php
/** Processamento seguro do formulário de cotação. */

defined( 'ABSPATH' ) || exit;

function captec_quote_redirect( $status ) {
	$referer = wp_get_referer();
	$target  = $referer ? wp_validate_redirect( $referer, home_url( '/' ) ) : home_url( '/' );
	$target  = remove_query_arg( 'quote', $target );
	$target  = add_query_arg( 'quote', $status, $target );
	wp_safe_redirect( $target . '#cotacao' );
	exit;
}

function captec_quote_client_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return 'captec_quote_' . hash( 'sha256', $ip . wp_salt( 'nonce' ) );
}

function captec_handle_quote() {
	if ( ! isset( $_POST['captec_quote_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['captec_quote_nonce'] ) ), 'captec_submit_quote' ) ) {
		captec_quote_redirect( 'error' );
	}

	// Campo invisível anti-spam. Robôs tendem a preenchê-lo; pessoas não.
	if ( ! empty( $_POST['website'] ) ) {
		captec_quote_redirect( 'sent' );
	}

	$rate_key = captec_quote_client_key();
	if ( get_transient( $rate_key ) ) {
		captec_quote_redirect( 'rate-limit' );
	}

	$fields = array(
		'name'     => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
		'company'  => isset( $_POST['company'] ) ? sanitize_text_field( wp_unslash( $_POST['company'] ) ) : '',
		'phone'    => isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '',
		'whatsapp' => isset( $_POST['whatsapp'] ) ? sanitize_text_field( wp_unslash( $_POST['whatsapp'] ) ) : '',
		'city'     => isset( $_POST['city'] ) ? sanitize_text_field( wp_unslash( $_POST['city'] ) ) : '',
		'state'    => isset( $_POST['state'] ) ? strtoupper( preg_replace( '/[^A-Za-z]/', '', sanitize_text_field( wp_unslash( $_POST['state'] ) ) ) ) : '',
		'product'  => isset( $_POST['product'] ) ? sanitize_text_field( wp_unslash( $_POST['product'] ) ) : '',
		'quantity' => isset( $_POST['quantity'] ) ? sanitize_text_field( wp_unslash( $_POST['quantity'] ) ) : '',
		'message'  => isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '',
	);

	if ( ! $fields['name'] || ! $fields['whatsapp'] || ! $fields['product'] || ! isset( $_POST['lgpd_consent'] ) ) {
		captec_quote_redirect( 'error' );
	}

	$file_url = '';
	if ( isset( $_FILES['quote_file'] ) && ! empty( $_FILES['quote_file']['name'] ) ) {
		$file = $_FILES['quote_file']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- validado pelo WordPress abaixo.
		if ( ! empty( $file['size'] ) && (int) $file['size'] > 10 * 1024 * 1024 ) {
			captec_quote_redirect( 'file-error' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$upload = wp_handle_upload( $file, array(
			'test_form' => false,
			'mimes'     => array(
				'pdf'  => 'application/pdf',
				'doc'  => 'application/msword',
				'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'xls'  => 'application/vnd.ms-excel',
				'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				'jpg|jpeg' => 'image/jpeg',
				'png'  => 'image/png',
			),
		) );
		if ( isset( $upload['error'] ) ) {
			captec_quote_redirect( 'file-error' );
		}
		$file_url = isset( $upload['url'] ) ? esc_url_raw( $upload['url'] ) : '';
	}

	$post_id = wp_insert_post( array(
		'post_type'   => 'captec_quote',
		'post_status' => 'private',
		'post_title'  => sprintf( __( 'Cotação — %1$s — %2$s', 'captec-asfaltos' ), $fields['name'], wp_date( 'd/m/Y H:i' ) ),
	), true );
	if ( is_wp_error( $post_id ) || ! $post_id ) {
		captec_quote_redirect( 'error' );
	}

	foreach ( $fields as $key => $value ) {
		update_post_meta( $post_id, '_captec_quote_' . $key, $value );
	}
	update_post_meta( $post_id, '_captec_quote_file_url', $file_url );
	update_post_meta( $post_id, '_captec_quote_lgpd_consent_at', current_time( 'mysql' ) );

	$recipient = sanitize_email( captec_mod( 'captec_quote_email', get_option( 'admin_email' ) ) );
	if ( ! $recipient ) {
		$recipient = get_option( 'admin_email' );
	}
	$subject = sprintf( '[CAPTEC] Nova solicitação de cotação — %s', $fields['name'] );
	$rows    = array(
		'Nome'        => $fields['name'],
		'Empresa'      => $fields['company'],
		'Telefone'     => $fields['phone'],
		'WhatsApp'     => $fields['whatsapp'],
		'Cidade'       => $fields['city'],
		'Estado'       => $fields['state'],
		'Produto'      => $fields['product'],
		'Quantidade'   => $fields['quantity'],
		'Mensagem'     => $fields['message'],
	);
	$body = '<h2>Nova solicitação de cotação</h2><table cellpadding="7" cellspacing="0" border="1" style="border-collapse:collapse;border-color:#ddd">';
	foreach ( $rows as $label => $value ) {
		if ( '' !== $value ) {
			$body .= '<tr><th align="left">' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( $value ) ) . '</td></tr>';
		}
	}
	if ( $file_url ) {
		$body .= '<tr><th align="left">Arquivo</th><td><a href="' . esc_url( $file_url ) . '">Abrir arquivo enviado</a></td></tr>';
	}
	$body .= '</table><p><small>Registro interno #' . absint( $post_id ) . '</small></p>';
	$mail_sent = wp_mail( $recipient, $subject, $body, array( 'Content-Type: text/html; charset=UTF-8' ) );
	update_post_meta( $post_id, '_captec_quote_mail_status', $mail_sent ? 'sent' : 'failed' );

	// Limite simples: uma solicitação por origem a cada dois minutos.
	set_transient( $rate_key, 1, 2 * MINUTE_IN_SECONDS );
	captec_quote_redirect( 'sent' );
}
add_action( 'admin_post_nopriv_captec_submit_quote', 'captec_handle_quote' );
add_action( 'admin_post_captec_submit_quote', 'captec_handle_quote' );

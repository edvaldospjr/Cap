<?php
/** Personalização da tela de acesso do WordPress com a marca CAPTEC. */

defined( 'ABSPATH' ) || exit;

function captec_login_logo_url() {
	$logo_id = absint( get_theme_mod( 'custom_logo', 0 ) );
	return $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium_large' ) : '';
}

function captec_login_branding() {
	$logo = esc_url( captec_login_logo_url() );
	$logo_style = $logo ? "background-image:url('" . $logo . "');" : 'background-image:none;';
	?>
	<style>
		body.login { background:#111111; }
		body.login #login { width:min(390px,calc(100% - 40px)); padding:8vh 0 28px; }
		body.login h1 a { width:300px; height:98px; margin:0 auto 28px; background-position:center; background-size:contain; background-repeat:no-repeat; <?php echo $logo_style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> }
		<?php if ( ! $logo ) : ?>
		body.login h1 a { position:relative; text-indent:0; color:#ffffff; font-size:0; }
		body.login h1 a:before { content:'CAPTEC'; position:absolute; inset:21px 0 auto; color:#ffffff; font:900 32px/1 Arial,sans-serif; letter-spacing:.12em; text-align:center; }
		body.login h1 a:after { content:'ASFALTOS'; position:absolute; inset:61px 0 auto; color:#f2a300; font:800 11px/1 Arial,sans-serif; letter-spacing:.33em; text-align:center; }
		<?php endif; ?>
		body.login #loginform, body.login #lostpasswordform, body.login #registerform { padding:28px; border:1px solid rgba(255,255,255,.15); border-radius:18px; background:#ffffff; box-shadow:0 25px 60px rgba(0,0,0,.26); }
		body.login label { color:#333333; font-weight:700; }
		body.login .button-primary { width:100%; min-height:42px; border-color:#f2a300; background:#f2a300; color:#111111; font-weight:800; text-shadow:none; box-shadow:none; }
		body.login .button-primary:hover, body.login .button-primary:focus { border-color:#ffb51d; background:#ffb51d; color:#111111; }
		body.login #nav a, body.login #backtoblog a { color:rgba(255,255,255,.72); }
		body.login #nav a:hover, body.login #backtoblog a:hover { color:#f2a300; }
		body.login .message, body.login .notice, body.login .success { border-left-color:#f2a300; border-radius:8px; }
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'captec_login_branding' );

function captec_login_header_url() {
	return home_url( '/' );
}
add_filter( 'login_headerurl', 'captec_login_header_url' );

function captec_login_header_text() {
	return get_bloginfo( 'name' ) ?: 'CAPTEC Asfaltos';
}
add_filter( 'login_headertext', 'captec_login_header_text' );

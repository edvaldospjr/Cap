<?php
/** Componentes reutilizáveis das páginas institucionais CAPTEC. */

defined( 'ABSPATH' ) || exit;

function captec_portal_image_url( $image ) {
	if ( 0 === strpos( (string) $image, 'assets/' ) ) {
		return captec_asset( $image );
	}
	return esc_url( $image );
}

function captec_render_products_grid( $products = null ) {
	$products = is_array( $products ) ? $products : captec_products();
	?>
	<div class="products-grid products-grid--page" role="list">
		<?php foreach ( $products as $index => $product ) : ?>
			<article class="product-card" role="listitem">
				<img class="product-card__media" src="<?php echo esc_url( captec_portal_image_url( $product['image'] ) ); ?>" alt="" loading="lazy" decoding="async">
				<span class="product-card__top"><?php echo captec_icon( 'droplet' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<div class="product-card__body">
					<span class="product-card__type"><?php echo esc_html( $product['type'] ); ?></span>
					<h3><?php echo esc_html( $product['title'] ); ?></h3>
					<p><?php echo esc_html( $product['description'] ); ?></p>
					<span class="product-card__apps"><strong><?php esc_html_e( 'Aplicações:', 'captec-asfaltos' ); ?></strong> <?php echo esc_html( $product['applications'] ); ?></span>
					<div class="product-card__actions">
						<?php echo captec_site_button_markup( 'product_quote', array( 'label' => 'Solicitar cotação', 'action' => 'quote', 'style' => 'line' ), array( 'class' => 'product-card__quote', 'bare' => true, 'icon' => 'arrow-right', 'product' => $product['title'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php if ( ! empty( $product['file'] ) ) : ?>
							<a class="product-card__file" href="<?php echo esc_url( $product['file'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( sprintf( __( 'Baixar ficha técnica de %s', 'captec-asfaltos' ), $product['title'] ) ); ?>"><?php echo captec_icon( 'file' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
						<?php endif; ?>
					</div>
				</div>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

function captec_render_applications_grid( $applications = null ) {
	$applications = is_array( $applications ) ? $applications : captec_applications();
	?>
	<div class="applications-grid" role="list">
		<?php foreach ( $applications as $index => $application ) : ?>
			<article class="application-card" role="listitem">
				<img class="application-card__image" src="<?php echo esc_url( captec_portal_image_url( $application['image'] ) ); ?>" alt="" loading="lazy" decoding="async">
				<div class="application-card__body"><div><small><?php echo esc_html( $application['subtitle'] ); ?></small><h3><?php echo esc_html( $application['title'] ); ?></h3></div><span class="application-card__arrow"><?php echo captec_icon( 'arrow-up-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span></div>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

function captec_render_locations_grid( $locations = null ) {
	$locations = is_array( $locations ) ? $locations : captec_locations();
	?>
	<div class="locations-grid" role="list">
		<?php foreach ( $locations as $location ) : ?>
			<?php $is_hq = isset( $location['kind'] ) && 'headquarters' === $location['kind']; ?>
			<article class="location-card" role="listitem">
				<span class="location-card__type"><?php echo esc_html( $is_hq ? __( 'Matriz', 'captec-asfaltos' ) : __( 'Filial', 'captec-asfaltos' ) ); ?></span>
				<h3><?php echo esc_html( $location['title'] ); ?></h3>
				<?php if ( ! empty( $location['company_name'] ) ) : ?><p class="location-card__company"><?php echo esc_html( $location['company_name'] ); ?></p><?php endif; ?>
				<?php if ( ! empty( $location['cnpj'] ) ) : ?><p class="location-card__cnpj"><strong>CNPJ</strong> <?php echo esc_html( $location['cnpj'] ); ?></p><?php endif; ?>
				<p class="location-card__address"><?php echo captec_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( captec_location_address( $location ) ); ?></span></p>
				<div class="location-card__contacts">
					<?php if ( ! empty( $location['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( captec_clean_phone( $location['phone'] ) ); ?>"><?php echo captec_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( $location['phone'] ); ?></span></a><?php endif; ?>
					<?php if ( ! empty( $location['email'] ) ) : ?><a href="mailto:<?php echo antispambot( $location['email'] ); ?>"><?php echo captec_icon( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo antispambot( $location['email'] ); ?></span></a><?php endif; ?>
				</div>
				<?php $map_url = captec_location_map_url( $location ); if ( $map_url ) : ?><a class="text-link location-card__map" href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Abrir no mapa', 'captec-asfaltos' ); ?><span class="arrow">→</span></a><?php endif; ?>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

function captec_render_industry_resources() {
	$resources = array(
		array(
			'title'  => 'Asfalto e requisitos de qualidade',
			'source' => 'ANP',
			'text'   => 'Página institucional sobre a distribuição de asfalto, requisitos de qualidade e referências regulatórias aplicáveis ao setor.',
			'url'    => 'https://www.gov.br/anp/pt-br/assuntos/producao-de-derivados-de-petroleo-e-processamento-de-gas-natural/producao-de-derivados-de-petroleo-e-processamento-de-gas-natural/asfalto',
		),
		array(
			'title'  => 'Resolução ANP nº 897/2022',
			'source' => 'Diário Oficial da União',
			'text'   => 'Referência para classificações e especificações de asfaltos e emulsões para pavimentação, incluindo RR-1C, RR-2C, RL-1C e EAI.',
			'url'    => 'https://portal.in.gov.br/web/dou/-/resolucao-anp-n-897-de-18-de-novembro-de-2022-445759308',
		),
		array(
			'title'  => 'Norma DNIT 385/2026',
			'source' => 'DNIT',
			'text'   => 'Especificação de serviço publicada em julho de 2026 para pavimentação com concreto asfáltico com ligante.',
			'url'    => 'https://www.gov.br/dnit/pt-br/assuntos/planejamento-e-pesquisa/ipr/coletanea-de-normas/coletanea-de-normas/especificacao-de-servico-es/dnit_385_2026_es.pdf',
		),
		array(
			'title'  => 'Manutenção rodoviária e segurança viária',
			'source' => 'Ministério dos Transportes',
			'text'   => 'Nota técnica de maio de 2026 com dados e evidências sobre conservação rodoviária e segurança viária.',
			'url'    => 'https://www.gov.br/transportes/pt-br/assuntos/noticias/2026/arquivos/NotaTcnican_052026.pdf',
		),
	);
	?>
	<div class="resource-grid" role="list">
		<?php foreach ( $resources as $resource ) : ?>
			<article class="resource-card" role="listitem">
				<span><?php echo esc_html( $resource['source'] ); ?></span>
				<h3><?php echo esc_html( $resource['title'] ); ?></h3>
				<p><?php echo esc_html( $resource['text'] ); ?></p>
				<a class="text-link" href="<?php echo esc_url( $resource['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Consultar fonte oficial', 'captec-asfaltos' ); ?><span class="arrow">→</span></a>
			</article>
		<?php endforeach; ?>
	</div>
	<p class="resource-note"><?php echo captec_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Referências externas para consulta. A definição de produto e aplicação deve seguir o projeto, a especificação vigente e a avaliação técnica responsável.', 'captec-asfaltos' ); ?></span></p>
	<?php
}

function captec_render_quote_form_section() {
	$products     = captec_products();
	$phone         = captec_clean_phone( captec_mod( 'captec_phone', '' ) );
	$phone_label   = captec_mod( 'captec_phone', '' );
	$whatsapp      = captec_mod( 'captec_whatsapp', '' );
	$email         = sanitize_email( captec_mod( 'captec_email', '' ) );
	$quote_status  = isset( $_GET['quote'] ) ? sanitize_key( wp_unslash( $_GET['quote'] ) ) : '';
	$selected_prod = isset( $_GET['produto'] ) ? sanitize_text_field( wp_unslash( $_GET['produto'] ) ) : '';
	$quote_submit = captec_site_button( 'quote_submit', array( 'label' => captec_mod( 'captec_quote_form_title', 'Solicitar cotação' ), 'style' => 'yellow', 'visible' => true ) );
	$quote_submit_style = in_array( $quote_submit['style'], array( 'yellow', 'dark', 'ghost', 'line' ), true ) ? $quote_submit['style'] : 'yellow';
	?>
	<section class="section section--tight" id="cotacao">
		<div class="shell quote-shell">
			<aside class="quote-aside">
				<p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_quote_eyebrow', 'Fale com a CAPTEC' ) ); ?></p>
				<h2 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_quote_title', 'Vamos entender a sua demanda.' ) ) ); ?></h2>
				<p><?php echo nl2br( esc_html( captec_mod( 'captec_quote_text', 'Envie as informações da obra. Quanto mais contexto você compartilhar, mais objetiva será a análise comercial.' ) ) ); ?></p>
				<ul class="contact-list">
					<?php if ( $phone && $phone_label ) : ?><li><?php echo captec_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone_label ); ?></a></li><?php endif; ?>
					<?php if ( $whatsapp ) : ?><li><?php echo captec_icon( 'whatsapp' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><a href="<?php echo captec_whatsapp_url( 'Olá, gostaria de solicitar uma cotação.' ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Atendimento via WhatsApp', 'captec-asfaltos' ); ?></a></li><?php endif; ?>
					<?php if ( $email ) : ?><li><?php echo captec_icon( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><a href="mailto:<?php echo antispambot( $email ); ?>"><?php echo antispambot( $email ); ?></a></li><?php endif; ?>
					<?php if ( ! $phone && ! $whatsapp && ! $email ) : ?><li><?php echo captec_icon( 'message' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Preencha o formulário para iniciar seu atendimento.', 'captec-asfaltos' ); ?></span></li><?php endif; ?>
					<li><?php echo captec_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( captec_mod( 'captec_location_label', 'Salvador/BA' ) ); ?></span></li>
				</ul>
			</aside>
			<div class="quote-form-wrap">
				<h3 class="quote-form-title"><?php echo esc_html( captec_mod( 'captec_quote_form_title', 'Solicitar cotação' ) ); ?></h3>
				<?php if ( 'sent' === $quote_status ) : ?><div class="form-notice"><?php echo captec_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Solicitação recebida. Nossa equipe retornará pelos canais informados.', 'captec-asfaltos' ); ?></span></div>
				<?php elseif ( in_array( $quote_status, array( 'error', 'file-error', 'rate-limit' ), true ) ) : ?><div class="form-notice form-notice--error"><?php echo captec_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php esc_html_e( 'Não foi possível concluir a solicitação. Revise os campos e tente novamente.', 'captec-asfaltos' ); ?></span></div><?php endif; ?>
				<form class="quote-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data">
					<input type="hidden" name="action" value="captec_submit_quote">
					<?php wp_nonce_field( 'captec_submit_quote', 'captec_quote_nonce' ); ?>
					<p class="hp-field" aria-hidden="true"><label><?php esc_html_e( 'Não preencha este campo', 'captec-asfaltos' ); ?><input type="text" name="website" tabindex="-1" autocomplete="off"></label></p>
					<div class="form-grid">
						<div class="form-field"><label for="page-quote-name"><?php esc_html_e( 'Nome', 'captec-asfaltos' ); ?> <span class="required">*</span></label><input class="input" id="page-quote-name" name="name" type="text" autocomplete="name" required></div>
						<div class="form-field"><label for="page-quote-company"><?php esc_html_e( 'Empresa', 'captec-asfaltos' ); ?></label><input class="input" id="page-quote-company" name="company" type="text" autocomplete="organization"></div>
						<div class="form-field"><label for="page-quote-phone"><?php esc_html_e( 'Telefone', 'captec-asfaltos' ); ?></label><input class="input" id="page-quote-phone" name="phone" type="tel" autocomplete="tel"></div>
						<div class="form-field"><label for="page-quote-whatsapp"><?php esc_html_e( 'WhatsApp', 'captec-asfaltos' ); ?> <span class="required">*</span></label><input class="input" id="page-quote-whatsapp" name="whatsapp" type="tel" autocomplete="tel" required></div>
						<div class="form-field"><label for="page-quote-state"><?php esc_html_e( 'Estado', 'captec-asfaltos' ); ?></label><select id="page-quote-state" name="state" data-state-select><option value=""><?php esc_html_e( 'Selecione', 'captec-asfaltos' ); ?></option><?php foreach ( array( 'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO' ) as $uf ) : ?><option value="<?php echo esc_attr( $uf ); ?>"><?php echo esc_html( $uf ); ?></option><?php endforeach; ?></select></div>
						<div class="form-field"><label for="page-quote-city"><?php esc_html_e( 'Cidade', 'captec-asfaltos' ); ?></label><select id="page-quote-city" name="city" autocomplete="address-level2" data-city-select disabled><option value=""><?php esc_html_e( 'Selecione primeiro o estado', 'captec-asfaltos' ); ?></option></select></div>
						<div class="form-field"><label for="page-quote-product"><?php esc_html_e( 'Produto', 'captec-asfaltos' ); ?> <span class="required">*</span></label><select id="page-quote-product" name="product" required><option value=""><?php esc_html_e( 'Selecione', 'captec-asfaltos' ); ?></option><?php foreach ( $products as $product ) : ?><option value="<?php echo esc_attr( $product['title'] ); ?>" <?php selected( $selected_prod, $product['title'] ); ?>><?php echo esc_html( $product['title'] ); ?></option><?php endforeach; ?></select></div>
						<div class="form-field"><label for="page-quote-quantity"><?php esc_html_e( 'Quantidade', 'captec-asfaltos' ); ?></label><input class="input" id="page-quote-quantity" name="quantity" type="text" placeholder="Ex.: 30 t"></div>
						<div class="form-field form-field--full"><label for="page-quote-message"><?php esc_html_e( 'Mensagem', 'captec-asfaltos' ); ?></label><textarea id="page-quote-message" name="message" placeholder="Conte um pouco sobre a obra, local de entrega e especificação, se disponível."></textarea></div>
						<div class="form-field form-field--full"><label for="page-quote-file"><?php esc_html_e( 'Upload de arquivo', 'captec-asfaltos' ); ?></label><span class="form-file"><?php echo captec_icon( 'upload' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span class="form-file__name" data-file-name><?php esc_html_e( 'Anexar memorial, planilha ou especificação (PDF, DOC, XLS, JPG ou PNG; até 10 MB)', 'captec-asfaltos' ); ?></span><input id="page-quote-file" name="quote_file" type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"></span></div>
					</div>
					<label class="form-consent"><input name="lgpd_consent" type="checkbox" value="1" required><span><?php esc_html_e( 'Autorizo o uso dos dados informados para contato e análise desta solicitação, conforme a', 'captec-asfaltos' ); ?> <a href="<?php echo esc_url( captec_policy_url( 'privacy' ) ); ?>"><?php esc_html_e( 'Política de Privacidade', 'captec-asfaltos' ); ?></a>.</span></label>
					<?php if ( ! empty( $quote_submit['visible'] ) ) : ?><button class="button button--<?php echo esc_attr( $quote_submit_style ); ?>" type="submit"><?php echo esc_html( $quote_submit['label'] ); ?> <?php echo captec_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button><?php endif; ?>
				</form>
			</div>
		</div>
	</section>
	<?php
}

/** Seção institucional reutilizada na página Quem somos. */
function captec_render_quem_somos_section() {
	$about_image = captec_mod( 'captec_about_image', captec_asset( 'assets/images/about-highway.jpg' ) );
	$button      = captec_site_button_markup(
		'home_institutional',
		array( 'label' => 'Fale com a CAPTEC', 'action' => 'quote', 'style' => 'dark' ),
		array( 'icon' => 'arrow-right' )
	);
	?>
	<section class="section section--home-company" id="quem-somos-resumo">
		<div class="shell home-company-grid">
			<div class="home-company-copy" data-reveal="left">
				<p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_about_eyebrow', 'Quem somos' ) ); ?></p>
				<h2 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_about_title', 'Distribuição que conecta qualidade, planejamento e resultado.' ) ) ); ?></h2>
				<p><?php echo nl2br( esc_html( captec_mod( 'captec_about_text_1', 'A CAPTEC Asfaltos atua na distribuição de produtos asfálticos para obras públicas e privadas, com foco em qualidade, relacionamento e eficiência.' ) ) ); ?></p>
				<p><?php echo nl2br( esc_html( captec_mod( 'captec_about_text_2', 'Da demanda inicial à entrega, trabalhamos para tornar o processo comercial mais claro e alinhado às necessidades de cada projeto.' ) ) ); ?></p>
				<?php echo $button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<div class="home-company-media" data-reveal="right"><img src="<?php echo esc_url( $about_image ); ?>" alt="<?php esc_attr_e( 'Rodovia em área de paisagem brasileira', 'captec-asfaltos' ); ?>" loading="lazy" decoding="async"><span><?php echo esc_html( captec_mod( 'captec_about_badge_label', 'Infraestrutura' ) ); ?></span></div>
		</div>
	</section>
	<?php
}

/** Seção Aplicações integrada à página Quem somos. */
function captec_render_quem_somos_applications_section() {
	if ( ! captec_feature_enabled( 'applications', true ) ) {
		return;
	}
	$button = captec_site_button_markup(
		'applications_quote',
		array( 'label' => 'Solicitar cotação', 'action' => 'quote', 'style' => 'yellow' ),
		array( 'icon' => 'arrow-right' )
	);
	?>
	<section class="section section--soft merged-applications" id="aplicacoes">
		<div class="shell">
			<div class="merged-section-head">
				<div>
					<p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_applications_eyebrow', 'Onde a CAPTEC atua' ) ); ?></p>
					<h2 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_applications_title', 'Soluções que acompanham diferentes contextos de infraestrutura.' ) ) ); ?></h2>
				</div>
				<p class="section-intro"><?php echo nl2br( esc_html( captec_mod( 'captec_applications_intro', 'Cada aplicação pede planejamento e produtos alinhados à sua especificação técnica.' ) ) ); ?></p>
			</div>
			<?php captec_render_applications_grid(); ?>
			<?php if ( $button ) : ?><div class="merged-section-cta"><div><p class="eyebrow"><?php esc_html_e( 'Planejamento da obra', 'captec-asfaltos' ); ?></p><p><?php esc_html_e( 'Conte com uma conversa comercial orientada pela sua necessidade.', 'captec-asfaltos' ); ?></p></div><?php echo $button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
		</div>
	</section>
	<?php
}

/** Seções Diferenciais e processo comercial integradas à página Quem somos. */
function captec_render_quem_somos_differentials_section() {
	$differentials = array(
		array( 'message', captec_mod( 'captec_differential_1_title', 'Atendimento Consultivo' ), captec_mod( 'captec_differential_1_text', 'Entendimento da demanda antes da construção da proposta.' ) ),
		array( 'headset', captec_mod( 'captec_differential_2_title', 'Equipe Comercial Especializada' ), captec_mod( 'captec_differential_2_text', 'Comunicação objetiva para apoiar a rotina de compras e obras.' ) ),
		array( 'quality', captec_mod( 'captec_differential_3_title', 'Qualidade dos Produtos' ), captec_mod( 'captec_differential_3_text', 'Portfólio apresentado de acordo com a especificação solicitada.' ) ),
		array( 'clock', captec_mod( 'captec_differential_4_title', 'Agilidade nas Cotações' ), captec_mod( 'captec_differential_4_text', 'Fluxo comercial organizado para dar visibilidade à solicitação.' ) ),
		array( 'route', captec_mod( 'captec_differential_5_title', 'Planejamento Logístico' ), captec_mod( 'captec_differential_5_text', 'Programação alinhada à necessidade informada no pedido.' ) ),
		array( 'handshake', captec_mod( 'captec_differential_6_title', 'Relacionamento de Longo Prazo' ), captec_mod( 'captec_differential_6_text', 'Proximidade e acompanhamento que valorizam a parceria.' ) ),
	);
	$steps = array(
		array( captec_mod( 'captec_process_1_title', 'Contato' ), captec_mod( 'captec_process_1_text', 'Você compartilha os dados iniciais da sua necessidade.' ) ),
		array( captec_mod( 'captec_process_2_title', 'Cotação' ), captec_mod( 'captec_process_2_text', 'A demanda é analisada para construção da proposta comercial.' ) ),
		array( captec_mod( 'captec_process_3_title', 'Negociação' ), captec_mod( 'captec_process_3_text', 'Alinhamos as condições e os pontos relevantes do fornecimento.' ) ),
		array( captec_mod( 'captec_process_4_title', 'Programação' ), captec_mod( 'captec_process_4_text', 'A entrega é organizada conforme o pedido confirmado.' ) ),
		array( captec_mod( 'captec_process_5_title', 'Entrega' ), captec_mod( 'captec_process_5_text', 'Acompanhamos a etapa de fornecimento combinada.' ) ),
		array( captec_mod( 'captec_process_6_title', 'Pós-venda' ), captec_mod( 'captec_process_6_text', 'Mantemos o canal aberto para continuidade do relacionamento.' ) ),
	);
	?>
	<?php if ( captec_feature_enabled( 'differentials', true ) ) : ?>
	<section class="section merged-differentials" id="diferenciais">
		<div class="shell">
			<div class="merged-section-head merged-section-head--stacked"><div><p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_differentials_eyebrow', 'Por que escolher a CAPTEC' ) ); ?></p><h2 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_differentials_title', 'Uma experiência comercial orientada para a sua obra.' ) ) ); ?></h2></div><p class="section-intro"><?php echo nl2br( esc_html( captec_mod( 'captec_differentials_intro', 'Mais clareza em cada etapa, para que a sua equipe avance com segurança na tomada de decisão.' ) ) ); ?></p></div>
			<div class="differentials-grid"><?php foreach ( $differentials as $item ) : ?><article class="differential-card"><span class="differential-icon"><?php echo captec_icon( $item[0] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><h3><?php echo esc_html( $item[1] ); ?></h3><p><?php echo esc_html( $item[2] ); ?></p></article><?php endforeach; ?></div>
		</div>
	</section>
	<?php endif; ?>
	<?php if ( captec_feature_enabled( 'process', true ) ) : ?>
	<section class="section section--soft merged-process" id="processo">
		<div class="shell process-layout"><div class="process-sticky"><p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_process_eyebrow', 'Processo' ) ); ?></p><h2 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_process_title', 'Do primeiro contato ao pós-venda, com mais clareza.' ) ) ); ?></h2><p class="section-intro"><?php echo nl2br( esc_html( captec_mod( 'captec_process_intro', 'Um caminho comercial pensado para tornar a solicitação mais simples e o acompanhamento mais próximo.' ) ) ); ?></p></div><ol class="process-list"><?php foreach ( $steps as $step ) : ?><li class="process-step"><span class="process-step__number" aria-hidden="true"></span><div><h3><?php echo esc_html( $step[0] ); ?></h3><p><?php echo esc_html( $step[1] ); ?></p></div><span class="process-step__line" aria-hidden="true"></span></li><?php endforeach; ?></ol></div>
	</section>
	<?php endif; ?>
	<?php
}

/** Conteúdo padrão da página Quem somos, armazenado no editor do WordPress. */
function captec_quem_somos_shortcodes() {
	return "[captec_quem_somos]\n\n[captec_aplicacoes]\n\n[captec_diferenciais]";
}

function captec_shortcode_quem_somos() {
	ob_start();
	captec_render_quem_somos_section();
	return ob_get_clean();
}

function captec_shortcode_aplicacoes() {
	ob_start();
	captec_render_quem_somos_applications_section();
	return ob_get_clean();
}

function captec_shortcode_diferenciais() {
	ob_start();
	captec_render_quem_somos_differentials_section();
	return ob_get_clean();
}

add_shortcode( 'captec_quem_somos', 'captec_shortcode_quem_somos' );
add_shortcode( 'captec_aplicacoes', 'captec_shortcode_aplicacoes' );
add_shortcode( 'captec_diferenciais', 'captec_shortcode_diferenciais' );

<?php
/**
 * Controles reutilizáveis de apresentação: botões globais, itens de rodapé
 * e comportamento de páginas publicadas/rascunhos.
 */

defined( 'ABSPATH' ) || exit;

/** Retorna os slots de botão que foram removidos explicitamente no Portal CAPTEC. */
function captec_hidden_button_slots() {
	$slots = get_option( 'captec_hidden_buttons', array() );
	return array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) $slots ) ) ) );
}

/** Converte um post de botão em uma configuração segura para o tema. */
function captec_button_post_data( $post, $defaults = array() ) {
	$post = get_post( $post );
	$data = wp_parse_args( $defaults, array(
		'label'   => '',
		'action'  => 'url',
		'url'     => '',
		'style'    => 'yellow',
		'target'   => 'same',
		'position' => 'default',
		'visible'  => true,
	) );
	if ( ! $post ) {
		return $data;
	}
	$label  = sanitize_text_field( get_post_meta( $post->ID, '_captec_button_label', true ) );
	$action = sanitize_key( get_post_meta( $post->ID, '_captec_button_action', true ) );
	$style  = sanitize_key( get_post_meta( $post->ID, '_captec_button_style', true ) );
	$target = sanitize_key( get_post_meta( $post->ID, '_captec_button_target', true ) );
	$position = sanitize_key( get_post_meta( $post->ID, '_captec_button_position', true ) );
	$data['label']  = $label ? $label : get_the_title( $post );
	$data['action'] = in_array( $action, array( 'quote', 'whatsapp', 'career_email', 'url' ), true ) ? $action : 'url';
	$data['url']    = esc_url_raw( get_post_meta( $post->ID, '_captec_button_url', true ) );
	$data['style']  = in_array( $style, array( 'yellow', 'dark', 'ghost', 'line' ), true ) ? $style : 'yellow';
	$data['target'] = 'new' === $target ? 'new' : 'same';
	$data['position'] = in_array( $position, array( 'left', 'center', 'right', 'default' ), true ) ? $position : 'default';
	return $data;
}

/**
 * Localiza a configuração de um botão. Um botão em rascunho não é mostrado
 * ao público; na prévia administrativa ele substitui a versão publicada.
 */
function captec_site_button( $slot, $defaults = array() ) {
	$slot     = sanitize_key( $slot );
	$defaults = wp_parse_args( $defaults, array(
		'label'   => '',
		'action'  => 'url',
		'url'     => '',
		'style'    => 'yellow',
		'target'   => 'same',
		'position' => 'default',
		'visible'  => true,
	) );
	if ( ! $slot || ! post_type_exists( 'captec_button' ) ) {
		return $defaults;
	}
	$is_hidden = in_array( $slot, captec_hidden_button_slots(), true );
	if ( $is_hidden && ! captec_is_admin_preview() ) {
		return array_merge( $defaults, array( 'visible' => false ) );
	}

	$posts = get_posts( array(
		'post_type'      => 'captec_button',
		'post_status'    => array( 'publish', 'draft' ),
		'posts_per_page' => -1,
		'meta_key'       => '_captec_button_slot',
		'meta_value'     => $slot,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	) );
	if ( ! $posts ) {
		return $is_hidden ? array_merge( $defaults, array( 'visible' => false ) ) : $defaults;
	}

	$published = null;
	$draft     = null;
	foreach ( $posts as $post ) {
		if ( 'draft' === $post->post_status && ! $draft ) {
			$draft = $post;
		}
		if ( 'publish' === $post->post_status && ! $published ) {
			$published = $post;
		}
	}
	if ( captec_is_admin_preview() && $draft ) {
		return captec_button_post_data( $draft, $defaults );
	}
	if ( $published ) {
		return captec_button_post_data( $published, $defaults );
	}
	if ( $draft || $is_hidden ) {
		return array_merge( $defaults, array( 'visible' => false ) );
	}
	return $defaults;
}

/** Calcula o destino de um botão global sem armazenar contatos sensíveis no post. */
function captec_site_button_url( $button, $args = array() ) {
	$button = wp_parse_args( $button, array( 'action' => 'url', 'url' => '' ) );
	$action = sanitize_key( $button['action'] );
	if ( 'quote' === $action ) {
		return captec_quote_url( ! empty( $args['product'] ) ? sanitize_text_field( $args['product'] ) : '' );
	}
	if ( 'whatsapp' === $action ) {
		$message = ! empty( $args['message'] ) ? sanitize_text_field( $args['message'] ) : 'Olá, gostaria de falar com a CAPTEC Asfaltos.';
		return captec_whatsapp_url( $message );
	}
	if ( 'career_email' === $action ) {
		$email = sanitize_email( captec_mod( 'captec_careers_email', captec_mod( 'captec_email', '' ) ) );
		if ( ! $email ) {
			return '';
		}
		return 'mailto:' . antispambot( $email ) . '?subject=' . rawurlencode( 'Trabalhe conosco — CAPTEC Asfaltos' );
	}
	return esc_url_raw( $button['url'] );
}

/** Gera a marcação de um botão controlado pelo Portal CAPTEC. */
function captec_site_button_markup( $slot, $defaults = array(), $args = array() ) {
	$button = captec_site_button( $slot, $defaults );
	if ( empty( $button['visible'] ) || empty( $button['label'] ) ) {
		return '';
	}
	$url = captec_site_button_url( $button, $args );
	if ( ! $url ) {
		return '';
	}
	$classes = array();
	if ( empty( $args['bare'] ) ) {
		$classes[] = 'button';
		$classes[] = 'button--' . ( in_array( $button['style'], array( 'yellow', 'dark', 'ghost', 'line' ), true ) ? $button['style'] : 'yellow' );
	}
	$position = in_array( $button['position'], array( 'left', 'center', 'right' ), true ) ? $button['position'] : 'default';
	if ( 'default' !== $position ) {
		$classes[] = 'captec-button-position--' . $position;
	}
	if ( ! empty( $args['class'] ) ) {
		$classes[] = preg_replace( '/[^A-Za-z0-9_\-\s]/', '', (string) $args['class'] );
	}
	$target = 'new' === $button['target'] ? ' target="_blank" rel="noopener noreferrer"' : '';
	$icon   = ! empty( $args['icon'] ) ? captec_icon( sanitize_key( $args['icon'] ) ) : '';
	$label  = esc_html( $button['label'] );
	$content = ! empty( $args['icon_before'] ) ? $icon . $label : $label . $icon;
	return '<a class="' . esc_attr( trim( implode( ' ', $classes ) ) ) . '" href="' . esc_url( $url ) . '"' . $target . '>' . $content . '</a>';
}

/** Itens configurados de uma das colunas do rodapé. */
function captec_footer_items( $section, $fallback = array() ) {
	$section    = sanitize_key( $section );
	$configured = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_footer_configured_sections', array() ) ) ) ) );
	if ( ! $section || ! post_type_exists( 'captec_footer_item' ) ) {
		return $fallback;
	}
	$posts = get_posts( array(
		'post_type'      => 'captec_footer_item',
		'post_status'    => array( 'publish', 'draft' ),
		'posts_per_page' => -1,
		'meta_key'       => '_captec_footer_section',
		'meta_value'     => $section,
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	) );
	if ( ! $posts ) {
		return in_array( $section, $configured, true ) ? array() : $fallback;
	}
	$items = array();
	foreach ( $posts as $post ) {
		if ( 'draft' === $post->post_status && ! captec_is_admin_preview() ) {
			continue;
		}
		$action = sanitize_key( get_post_meta( $post->ID, '_captec_footer_action', true ) );
		$kind   = sanitize_key( get_post_meta( $post->ID, '_captec_footer_kind', true ) );
		$target = sanitize_key( get_post_meta( $post->ID, '_captec_footer_target', true ) );
		$label  = sanitize_text_field( get_post_meta( $post->ID, '_captec_footer_label', true ) );
		$items[] = array(
			'label'  => $label ? $label : get_the_title( $post ),
			'kind'   => 'text' === $kind ? 'text' : 'link',
			'action' => in_array( $action, array( 'home', 'quote', 'whatsapp', 'phone', 'email', 'privacy', 'cookies', 'maps', 'url' ), true ) ? $action : 'url',
			'url'    => esc_url_raw( get_post_meta( $post->ID, '_captec_footer_url', true ) ),
			'target' => 'new' === $target ? 'new' : 'same',
		);
	}
	return $items;
}

/** Destino dinâmico de um item de rodapé. */
function captec_footer_item_url( $item ) {
	$action = isset( $item['action'] ) ? sanitize_key( $item['action'] ) : 'url';
	if ( 'home' === $action ) {
		return home_url( '/' );
	}
	if ( 'quote' === $action || 'whatsapp' === $action ) {
		return captec_site_button_url( array( 'action' => $action ) );
	}
	if ( 'phone' === $action ) {
		$phone = captec_clean_phone( captec_mod( 'captec_phone', '' ) );
		return $phone ? 'tel:' . $phone : '';
	}
	if ( 'email' === $action ) {
		$email = sanitize_email( captec_mod( 'captec_email', '' ) );
		return $email ? 'mailto:' . antispambot( $email ) : '';
	}
	if ( 'privacy' === $action ) {
		return captec_policy_url( 'privacy' );
	}
	if ( 'cookies' === $action ) {
		return captec_policy_url( 'cookies' );
	}
	if ( 'maps' === $action ) {
		return esc_url_raw( captec_mod( 'captec_maps_url', '' ) );
	}
	return ! empty( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
}

/** Renderiza itens de rodapé como lista sem expor um item em rascunho ao público. */
function captec_footer_items_markup( $items ) {
	$markup = '';
	foreach ( (array) $items as $item ) {
		$label = isset( $item['label'] ) ? sanitize_text_field( $item['label'] ) : '';
		$action = isset( $item['action'] ) ? sanitize_key( $item['action'] ) : 'url';
		if ( 'phone' === $action && 'Telefone' === $label && captec_mod( 'captec_phone', '' ) ) {
			$label = captec_mod( 'captec_phone', '' );
		}
		if ( 'email' === $action && 'E-mail comercial' === $label && captec_mod( 'captec_email', '' ) ) {
			$label = sanitize_email( captec_mod( 'captec_email', '' ) );
		}
		if ( ! $label ) {
			continue;
		}
		if ( isset( $item['kind'] ) && 'text' === $item['kind'] ) {
			$markup .= '<li><span>' . esc_html( $label ) . '</span></li>';
			continue;
		}
		$url = captec_footer_item_url( $item );
		if ( ! $url ) {
			continue;
		}
		$target = isset( $item['target'] ) && 'new' === $item['target'] ? ' target="_blank" rel="noopener noreferrer"' : '';
		$markup .= '<li><a href="' . esc_url( $url ) . '"' . $target . '>' . esc_html( $label ) . '</a></li>';
	}
	return $markup;
}

/** Remove páginas em rascunho do menu público, preservando-as na prévia administrativa. */
function captec_hide_draft_pages_from_menu( $items, $args ) {
	if ( is_admin() || captec_is_admin_preview() ) {
		return $items;
	}
	$visible = array();
	foreach ( (array) $items as $item ) {
		if ( 'post_type' === $item->type && 'page' === $item->object && 'publish' !== get_post_status( $item->object_id ) ) {
			continue;
		}
		$visible[] = $item;
	}
	return $visible;
}
add_filter( 'wp_nav_menu_objects', 'captec_hide_draft_pages_from_menu', 10, 2 );

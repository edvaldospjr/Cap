<?php
/** SEO técnico leve, preload e cabeçalhos básicos. */

defined( 'ABSPATH' ) || exit;

function captec_has_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

function captec_meta_description() {
	if ( is_front_page() ) {
		return wp_strip_all_tags( captec_mod( 'captec_hero_text', 'Especialistas no fornecimento de produtos asfálticos para obras públicas e privadas com atendimento consultivo, eficiência logística e compromisso com resultados.' ) );
	}
	if ( is_singular() ) {
		$excerpt = get_the_excerpt();
		if ( $excerpt ) {
			return wp_strip_all_tags( $excerpt );
		}
	}
	return 'CAPTEC Asfaltos — soluções para pavimentação e infraestrutura.';
}

function captec_output_seo_meta() {
	if ( is_admin() || captec_has_seo_plugin() ) {
		return;
	}
	$description = wp_trim_words( captec_meta_description(), 30, '' );
	echo '<meta name="description" content="' . esc_attr( $description ) . '">' . "\n";

	if ( ! is_front_page() ) {
		return;
	}
	$schema = array(
		'@context' => 'https://schema.org',
		'@type'    => 'Organization',
		'name'     => 'CAPTEC Asfaltos',
		'url'      => home_url( '/' ),
		'description' => $description,
		'address'  => array(
			'@type'           => 'PostalAddress',
			'addressLocality' => 'Salvador',
			'addressRegion'   => 'BA',
			'addressCountry'  => 'BR',
		),
	);
	if ( has_custom_logo() ) {
		$logo_id = get_theme_mod( 'custom_logo' );
		$logo    = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $logo ) {
			$schema['logo'] = $logo;
		}
	}
	$email = sanitize_email( captec_mod( 'captec_email', '' ) );
	$phone = captec_clean_phone( captec_mod( 'captec_phone', '' ) );
	if ( $email ) {
		$schema['email'] = $email;
	}
	if ( $phone ) {
		$schema['telephone'] = $phone;
	}
	$links = array_filter( array( esc_url_raw( captec_mod( 'captec_instagram', '' ) ), esc_url_raw( captec_mod( 'captec_linkedin', '' ) ) ) );
	if ( $links ) {
		$schema['sameAs'] = array_values( $links );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}
add_action( 'wp_head', 'captec_output_seo_meta', 2 );

function captec_preload_hero_asset() {
	if ( ! is_front_page() ) {
		return;
	}
	$poster = esc_url( captec_mod( 'captec_hero_poster', captec_asset( 'assets/images/hero-paving.jpg' ) ) );
	if ( $poster ) {
		echo '<link rel="preload" as="image" href="' . $poster . '" fetchpriority="high">' . "\n";
	}
}
add_action( 'wp_head', 'captec_preload_hero_asset', 1 );

function captec_security_headers() {
	if ( ! headers_sent() ) {
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	}
}
add_action( 'send_headers', 'captec_security_headers' );

/** Evita assets de emoji do WordPress em um tema corporativo sem emojis. */
function captec_disable_wp_emojis() {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'captec_disable_wp_emojis' );

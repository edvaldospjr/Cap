<?php
/** Fallback do tema. */
require get_template_directory() . '/archive.php';

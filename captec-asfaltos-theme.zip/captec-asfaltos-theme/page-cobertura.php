<?php
defined( 'ABSPATH' ) || exit;
get_header();

$stats         = captec_stats();
$active_states = captec_mod( 'captec_active_states', '' );
$coverage_whatsapp_button = captec_site_button_markup(
	'coverage_whatsapp',
	array(
		'label'  => 'Falar pelo WhatsApp',
		'action' => 'whatsapp',
		'style'  => 'yellow',
		'target' => 'new',
	),
	array(
		'icon'        => 'whatsapp',
		'icon_before' => true,
		'message'     => 'Olá, gostaria de verificar a disponibilidade de atendimento para minha localidade.',
	)
);
$coverage_quote_button = captec_site_button_markup(
	'coverage_quote',
	array(
		'label'  => 'Solicitar cotação',
		'action' => 'quote',
		'style'  => 'line',
	),
	array( 'icon' => 'arrow-right' )
);
?>
<main id="conteudo-principal">
	<header class="page-hero">
		<div class="shell">
			<p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_map_eyebrow', 'Cobertura' ) ); ?></p>
			<h1 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_map_title', 'Uma conversa começa onde a sua obra está.' ) ) ); ?></h1>
			<p class="page-hero__intro"><?php echo nl2br( esc_html( captec_mod( 'captec_map_intro', 'Use o mapa como referência visual e entre em contato para verificar a disponibilidade de atendimento para sua localidade e demanda.' ) ) ); ?></p>
		</div>
	</header>

	<?php if ( captec_feature_enabled( 'stats', true ) && $stats ) : ?>
		<section class="section section--tight">
			<div class="shell">
				<div class="stats-shell">
					<div class="stats-heading">
						<div>
							<p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_stats_eyebrow', 'Indicadores' ) ); ?></p>
							<h2 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_stats_title', 'Indicadores que refletem nossa atuação' ) ) ); ?></h2>
						</div>
						<p><?php echo nl2br( esc_html( captec_mod( 'captec_stats_intro', 'A transparência faz parte do nosso compromisso com clientes, parceiros e colaboradores. Nesta seção, apresentamos os principais indicadores da empresa, reunindo números que demonstram nossa capacidade de atendimento, presença nacional, portfólio de produtos e volume de fornecimento.' ) ) ); ?></p>
					</div>
					<div class="stats-grid" role="list">
						<?php foreach ( $stats as $stat ) : $counter = captec_counter_parts( $stat['value'] ); $is_empty = '' === $counter['number']; ?>
							<div class="stat-card" role="listitem" data-empty="<?php echo $is_empty ? 'true' : 'false'; ?>">
								<span class="stat-value"<?php if ( ! $is_empty ) : ?> data-counter="<?php echo esc_attr( $counter['number'] ); ?>" data-suffix="<?php echo esc_attr( $counter['suffix'] ); ?>"<?php endif; ?>><?php echo $is_empty ? '—' : esc_html( $stat['value'] ); ?></span>
								<span class="stat-label"><?php echo esc_html( $stat['label'] ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( captec_feature_enabled( 'map', true ) ) : ?>
		<section class="section section--soft">
			<div class="shell map-panel">
				<div class="map-copy">
					<p class="eyebrow"><?php esc_html_e( 'Mapa interativo', 'captec-asfaltos' ); ?></p>
					<h2 class="section-title"><?php esc_html_e( 'Consulte a disponibilidade para sua localidade.', 'captec-asfaltos' ); ?></h2>
					<p class="section-intro"><?php esc_html_e( 'Clique em um estado para conferir a disponibilidade de atendimento e escolha o canal mais adequado para sua demanda.', 'captec-asfaltos' ); ?></p>
					<?php if ( $coverage_whatsapp_button || $coverage_quote_button ) : ?>
						<div class="map-actions" aria-label="<?php esc_attr_e( 'Canais de atendimento', 'captec-asfaltos' ); ?>">
							<?php echo $coverage_whatsapp_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php echo $coverage_quote_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
					<?php endif; ?>
					<ul class="map-features">
						<li><?php echo captec_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( captec_mod( 'captec_map_feature_1', 'Mapa interativo preparado para destaque de estados.' ) ); ?></li>
						<li><?php echo captec_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( captec_mod( 'captec_map_feature_2', 'Estados configuráveis diretamente no Personalizar.' ) ); ?></li>
						<li><?php echo captec_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( captec_mod( 'captec_map_feature_3', 'Consulta comercial sem compromisso.' ) ); ?></li>
					</ul>
				</div>
				<div class="map-wrap">
					<brazil-component class="brazil-map" hidden-states data-active-states="<?php echo esc_attr( $active_states ); ?>" aria-label="<?php esc_attr_e( 'Mapa interativo do Brasil', 'captec-asfaltos' ); ?>"></brazil-component>
					<div class="map-status">
						<span><i class="map-status__dot"></i><span data-map-status><?php esc_html_e( 'Selecione um estado no mapa', 'captec-asfaltos' ); ?></span></span>
						<strong><?php esc_html_e( 'Brasil', 'captec-asfaltos' ); ?></strong>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>
</main>
<?php get_footer();

<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php esc_html_e( 'Atendimento comercial', 'captec-asfaltos' ); ?></p><h1 class="section-title"><?php esc_html_e( 'Solicite uma cotação.', 'captec-asfaltos' ); ?></h1><p class="page-hero__intro"><?php esc_html_e( 'Compartilhe os dados da sua obra para que a equipe comercial possa analisar sua solicitação.', 'captec-asfaltos' ); ?></p></div></header>
	<?php if ( captec_feature_enabled( 'quote', true ) ) : ?>
	<?php captec_render_quote_form_section(); ?>
	<?php else : ?><section class="section"><div class="shell"><div class="entry-content"><h2><?php esc_html_e( 'Solicitação de cotação temporariamente indisponível', 'captec-asfaltos' ); ?></h2><p><?php esc_html_e( 'Entre em contato pelos canais institucionais para obter orientação.', 'captec-asfaltos' ); ?></p></div></div></section><?php endif; ?>
</main>
<?php get_footer();

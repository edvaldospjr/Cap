<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_products_eyebrow', 'Portfólio' ) ); ?></p><h1 class="section-title"><?php echo nl2br( esc_html( captec_mod( 'captec_products_title', 'Produtos para especificações que pedem precisão.' ) ) ); ?></h1><p class="page-hero__intro"><?php echo nl2br( esc_html( captec_mod( 'captec_products_intro', 'Conheça as soluções disponíveis e solicite uma cotação de acordo com as necessidades técnicas da sua obra.' ) ) ); ?></p></div></header>
	<?php if ( captec_feature_enabled( 'products', true ) ) : ?>
	<section class="section section--products-white"><div class="shell"><?php captec_render_products_grid(); ?><p class="product-note"><?php echo captec_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( captec_mod( 'captec_products_note', 'A disponibilidade e a aplicação devem ser confirmadas na cotação, de acordo com a especificação da obra.' ) ); ?></span></p></div></section>
	<section class="section section--soft"><div class="shell"><div class="section-head"><div><p class="eyebrow"><?php esc_html_e( 'Referências técnicas', 'captec-asfaltos' ); ?></p><h2 class="section-title"><?php esc_html_e( 'Informação atualizada para apoiar decisões técnicas.', 'captec-asfaltos' ); ?></h2></div><p class="section-intro"><?php esc_html_e( 'Consulte fontes oficiais sobre especificações, qualidade e pavimentação. A aplicação deve sempre observar o projeto e a especificação vigente.', 'captec-asfaltos' ); ?></p></div><?php captec_render_industry_resources(); ?></div></section>
	<?php else : ?><section class="section"><div class="shell"><div class="entry-content"><h2><?php esc_html_e( 'Produtos temporariamente indisponíveis', 'captec-asfaltos' ); ?></h2><p><?php esc_html_e( 'Esta funcionalidade está inativa no momento. Entre em contato para solicitar orientação comercial.', 'captec-asfaltos' ); ?></p></div></div></section><?php endif; ?>
</main>
<?php get_footer();

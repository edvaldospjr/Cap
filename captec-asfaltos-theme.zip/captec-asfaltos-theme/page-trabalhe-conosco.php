<?php
/** Página Trabalhe conosco. */
defined( 'ABSPATH' ) || exit;
get_header();

$careers_email = sanitize_email( captec_mod( 'captec_careers_email', captec_mod( 'captec_email', '' ) ) );
$careers_title = captec_mod( 'captec_careers_title', 'Construa caminhos com a CAPTEC.' );
$careers_text  = captec_mod( 'captec_careers_text', 'Se você deseja fazer parte do nosso time, envie seu currículo para análise.' );
$instruction    = captec_mod( 'captec_careers_instruction', 'No e-mail, informe sua cidade/UF, área de interesse e envie o currículo em PDF.' );
$note           = captec_mod( 'captec_careers_note', 'As candidaturas são avaliadas conforme as necessidades da empresa.' );
$button_label   = captec_mod( 'captec_careers_button_label', 'Enviar currículo' );
$mailto         = $careers_email ? 'mailto:' . antispambot( $careers_email ) . '?subject=' . rawurlencode( 'Trabalhe conosco — CAPTEC Asfaltos' ) : '';
$careers_button = captec_site_button_markup( 'careers_email', array( 'label' => $button_label, 'action' => 'career_email', 'style' => 'yellow' ), array( 'icon' => 'arrow-right' ) );
?>
<main id="conteudo-principal">
	<header class="page-hero page-hero--careers">
		<div class="shell">
			<p class="eyebrow"><?php echo esc_html( captec_mod( 'captec_careers_eyebrow', 'Trabalhe conosco' ) ); ?></p>
			<h1 class="section-title"><?php echo nl2br( esc_html( $careers_title ) ); ?></h1>
			<p class="page-hero__intro"><?php esc_html_e( 'Envie sua candidatura para futuras oportunidades na CAPTEC Asfaltos.', 'captec-asfaltos' ); ?></p>
		</div>
	</header>
	<section class="section section--soft careers-section">
		<div class="shell careers-grid">
			<div class="careers-copy" data-reveal="left">
				<p class="eyebrow"><?php esc_html_e( 'Seu próximo caminho pode começar aqui', 'captec-asfaltos' ); ?></p>
				<h2 class="section-title"><?php echo nl2br( esc_html( $careers_title ) ); ?></h2>
				<p><?php echo nl2br( esc_html( $careers_text ) ); ?></p>
				<p><?php echo nl2br( esc_html( $instruction ) ); ?></p>
				<?php echo $careers_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
			<aside class="careers-card" data-reveal="right">
				<span class="careers-card__badge"><?php esc_html_e( 'Candidatura espontânea', 'captec-asfaltos' ); ?></span>
				<h2><?php esc_html_e( 'Como enviar seu currículo', 'captec-asfaltos' ); ?></h2>
				<ol class="careers-steps">
					<li><span>01</span><p><?php esc_html_e( 'Prepare seu currículo atualizado em PDF.', 'captec-asfaltos' ); ?></p></li>
					<li><span>02</span><p><?php esc_html_e( 'Informe a área de interesse e sua cidade/UF.', 'captec-asfaltos' ); ?></p></li>
					<li><span>03</span><p><?php esc_html_e( 'Envie pelo canal indicado para análise.', 'captec-asfaltos' ); ?></p></li>
				</ol>
				<?php if ( $careers_email ) : ?>
					<div class="careers-contact"><?php echo captec_icon( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><div><span><?php esc_html_e( 'Canal para currículos', 'captec-asfaltos' ); ?></span><a href="<?php echo esc_url( $mailto ); ?>"><?php echo antispambot( $careers_email ); ?></a></div></div>
				<?php else : ?>
					<div class="careers-contact careers-contact--notice"><?php echo captec_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><div><span><?php esc_html_e( 'Canal em configuração', 'captec-asfaltos' ); ?></span><p><?php esc_html_e( 'O e-mail para currículos será disponibilizado em breve.', 'captec-asfaltos' ); ?></p></div></div>
				<?php endif; ?>
			</aside>
		</div>
		<?php if ( $note ) : ?><p class="careers-note shell"><?php echo captec_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo nl2br( esc_html( $note ) ); ?></span></p><?php endif; ?>
	</section>
</main>
<?php get_footer();

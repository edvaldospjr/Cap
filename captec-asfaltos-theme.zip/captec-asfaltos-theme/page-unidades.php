<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php esc_html_e( 'Presença institucional', 'captec-asfaltos' ); ?></p><h1 class="section-title"><?php esc_html_e( 'Matriz e filiais CAPTEC.', 'captec-asfaltos' ); ?></h1><p class="page-hero__intro"><?php esc_html_e( 'Dados cadastrais e canais de contato das unidades institucionais.', 'captec-asfaltos' ); ?></p></div></header>
	<?php if ( captec_feature_enabled( 'locations', true ) ) : ?>
	<section class="section section--soft"><div class="shell"><div class="section-head"><div><p class="eyebrow"><?php esc_html_e( 'Unidades', 'captec-asfaltos' ); ?></p><h2 class="section-title"><?php esc_html_e( 'Estrutura cadastrada para atender diferentes regiões.', 'captec-asfaltos' ); ?></h2></div><p class="section-intro"><?php esc_html_e( 'Endereços, CNPJs e contatos são administrados pelo Portal CAPTEC.', 'captec-asfaltos' ); ?></p></div><?php captec_render_locations_grid(); ?></div></section>
	<?php else : ?><section class="section"><div class="shell"><div class="entry-content"><h2><?php esc_html_e( 'Unidades temporariamente indisponíveis', 'captec-asfaltos' ); ?></h2><p><?php esc_html_e( 'Esta funcionalidade está inativa no momento.', 'captec-asfaltos' ); ?></p></div></div></section><?php endif; ?>
</main>
<?php get_footer();

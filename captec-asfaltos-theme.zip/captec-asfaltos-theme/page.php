<?php
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) : the_post(); ?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php esc_html_e( 'CAPTEC Asfaltos', 'captec-asfaltos' ); ?></p><h1 class="section-title"><?php the_title(); ?></h1></div></header>
	<section class="section"><div class="shell"><article <?php post_class( 'entry-content' ); ?>><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'large', array( 'loading' => 'eager', 'decoding' => 'async' ) ); } the_content(); ?></article></div></section>
</main>
<?php endwhile; get_footer();

<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php esc_html_e( 'Busca', 'captec-asfaltos' ); ?></p><h1 class="section-title"><?php printf( esc_html__( 'Resultados para “%s”', 'captec-asfaltos' ), esc_html( get_search_query() ) ); ?></h1></div></header>
	<section class="section"><div class="shell">
		<?php if ( have_posts() ) : ?><div class="blog-grid"><?php while ( have_posts() ) : the_post(); ?><article class="article-card"><span class="article-card__category"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></span><h2><?php the_title(); ?></h2><a class="text-link" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Abrir conteúdo', 'captec-asfaltos' ); ?><span class="arrow">→</span></a></article><?php endwhile; ?></div><?php the_posts_pagination(); ?><?php else : ?><div class="entry-content"><h2><?php esc_html_e( 'Nenhum resultado encontrado', 'captec-asfaltos' ); ?></h2><p><?php esc_html_e( 'Tente usar outro termo ou volte à página inicial.', 'captec-asfaltos' ); ?></p></div><?php endif; ?>
	</div></section>
</main>
<?php get_footer();

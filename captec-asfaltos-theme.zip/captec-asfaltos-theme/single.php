<?php
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) : the_post(); ?>
<main id="conteudo-principal">
	<header class="page-hero"><div class="shell"><p class="eyebrow"><?php echo esc_html( get_post_type() === 'post' ? __( 'Conteúdos CAPTEC', 'captec-asfaltos' ) : __( 'Portfólio CAPTEC', 'captec-asfaltos' ) ); ?></p><h1 class="section-title"><?php the_title(); ?></h1><?php if ( get_post_type() === 'post' ) : ?><p class="post-meta"><?php echo esc_html( get_the_date( 'd \d\e F \d\e Y' ) ); ?></p><?php endif; ?></div></header>
	<section class="section"><div class="shell"><article <?php post_class( 'entry-content' ); ?>><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'large', array( 'loading' => 'eager', 'decoding' => 'async' ) ); } the_content(); ?></article></div></section>
</main>
<?php endwhile; get_footer();

# Portal Administrativo CAPTEC

Plugin WordPress que cria uma central administrativa visual para o portal CAPTEC Asfaltos. Ele se conecta diretamente aos conteúdos, configurações e tipos de post utilizados pelo tema `CAPTEC Asfaltos`.

## Instalação

1. Instale e ative primeiro o tema **CAPTEC Asfaltos**.
2. Envie o arquivo `captec-portal-admin.zip` em **Plugins > Adicionar novo > Enviar plugin**.
3. Ative o plugin.
4. Acesse **Portal CAPTEC** no menu administrativo do WordPress.

> Na primeira ativação, se o catálogo estiver vazio e o tema CAPTEC estiver ativo, o plugin cria os sete produtos e as oito aplicações previstos no briefing. Não cria clientes, números, contatos, certificações ou dados institucionais não fornecidos.

## Áreas do painel

- **Visão geral:** prontidão de publicação, atalhos e indicadores de conteúdo.
- **Quem somos:** hero, botões, cards de apoio e informações institucionais da página inicial.
- **Produtos:** criação, edição, ordem, imagem destacada, aplicações e ficha técnica.
- **Aplicações:** cards visuais de atuação, imagens e ordem de exibição, apresentados na seção Aplicações da página Quem somos.
- **Matriz e filiais:** razão social, CNPJ, endereço, contatos, mapa, publicação e inativação das unidades.
- **Páginas e menu:** criação guiada de páginas WordPress para Quem somos, Produtos, Unidades, Cobertura, Conteúdos, Trabalhe conosco e Cotação. Quem somos reúne também Aplicações, Diferenciais e Processo.
- **Conteúdos:** artigos do blog, rascunhos, publicação, imagem, categoria editável e pautas atuais com imagem relacionada.
- **Cotações:** leitura segura de solicitações, status de atendimento e anotações internas.
- **Marca e contatos:** logo oficial, telefone, WhatsApp, e-mail, redes sociais, localização e texto institucional do rodapé.
- **Botões do site:** gestão centralizada de texto, destino, estilo, publicação, rascunho e exclusão dos botões públicos.
- **Rodapé:** criação, edição, publicação, rascunho e exclusão dos links e informações de cada coluna.
- **Dados e cobertura:** criação, edição, publicação, rascunho e exclusão de indicadores institucionais; estados destacados, mensagem de disponibilidade e mapa ampliado.
- **Trabalhe conosco:** texto, orientação e e-mail de recebimento de currículos, com fallback para o e-mail comercial.
- **Dados e cobertura:** indicadores editáveis e estados destacados no mapa.
- **Integrações e LGPD:** Google Analytics 4, Meta Pixel e links para políticas legais.
- **Funcionalidades e manutenção:** ativação/inativação de seções e modo de manutenção com resposta HTTP 503 para visitantes, além do botão Visualizar que abre a página relacionada em pop-up.
- **Agente IA CAPTEC:** configuração apenas de nome e imagem, comando por voz via Web Speech API, orientação baseada no Manual do Portal, prévia obrigatória e autorização explícita antes de executar ações suportadas. Perguntas não compreendidas orientam contato com o Administrador do site.

## Permissões

O plugin adiciona a capacidade `captec_manage_portal` aos administradores e cria a função **Gestor CAPTEC**. Essa função foi pensada para pessoas responsáveis pela atualização do portal sem acesso à administração técnica completa.

Todas as ações do painel verificam nonce e permissão no servidor. As cotações continuam como registros privados no WordPress.

## Mídia

Botões de seleção de imagem, vídeo, logo e ficha técnica abrem a Biblioteca de Mídia nativa do WordPress. O painel não depende de serviços externos para armazenar arquivos.

## Observações de publicação

- Configure SMTP para a entrega confiável das cotações.
- Insira somente indicadores validados pela empresa.
- Informe os canais oficiais antes de divulgar o site.
- Revise Política de Privacidade e Política de Cookies com a área jurídica antes da publicação.
- Mantenha o tema CAPTEC Asfaltos ativo: ele contém a camada visual pública que consome as configurações do painel.

## Requisitos

- WordPress 6.2 ou superior;
- PHP 7.4 ou superior;
- Tema CAPTEC Asfaltos ativo.

## Assistente sempre disponível

Além da tela **Agente IA**, usada somente para configurar nome e imagem, o assistente fica no canto inferior direito em todas as áreas do Portal CAPTEC. A janela rápida permite escolher entre orientação ou execução de ação, exibe uma prévia e só executa após autorização explícita.

## Aparências e análise do portal

Em **Aparências**, pessoas sem experiência podem definir fundo das páginas, áreas suaves, barras, largura, margens, espaços, cabeçalho, menu e rodapé. A área mantém controles de cor de menu, fonte, tamanho, distância entre itens, intensidade, comportamento visual ao rolar e tamanhos de logo.

Em **Análise do portal**, o painel consulta dados reais de uma propriedade Google Analytics 4 após a configuração do ID numérico da propriedade e de uma conta de serviço com permissão de leitura. A área apresenta acessos no ano, mês e dia, horário de maior acesso, páginas mais acessadas, permanência média por página e distribuição por região, estado e cidade. Sem credenciais, nenhum número é inventado.

## Atualização 2.6

- A marca oficial é refletida no menu do Portal CAPTEC; o tema a aplica também no login WordPress e na tela de manutenção.
- O módulo Aparências inclui tamanho individual da logo no cabeçalho e no rodapé, além de cores, largura e espaçamentos gerais.
- O Log de atividades usa tabela própria, identifica usuário, registra atividades do portal e do agente e remove registros após seis meses.
- A janela do agente possui saudação personalizável, modos de orientação e execução, link direto para o manual PDF e não expõe configurações de endpoint, modelo ou chave de API.
- O módulo Conteúdos mostra pautas atuais e cria rascunhos prontos para revisão.


## Atualização 3.3

- A tela **Aparências** centraliza cores de fundo e barras, largura de página, espaços, cabeçalho, menu e rodapé.
- **Dados e cobertura** inicia com os cinco indicadores institucionais solicitados publicados e sem valores inventados.
- A página Produtos usa fundo branco; o mapa foi ampliado internamente em quadro compacto.
- **Botões do site** inclui posição padrão, esquerda, centro ou direita.
- A base de conhecimento e os manuais foram revisados para a versão 3.3.0.


## Atualização 3.4

- Quem somos passou a concentrar as seções Institucional, Aplicações, Diferenciais e Processo.
- Aplicações e Diferenciais deixaram de ser páginas independentes e são redirecionadas para Quem somos.
- A listagem **Páginas e menu** mostra o conteúdo salvo no WordPress e o editor passou a identificá-lo como conteúdo nativo da página.

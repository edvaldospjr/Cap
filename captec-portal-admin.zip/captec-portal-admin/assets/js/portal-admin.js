/* Portal Administrativo CAPTEC — JavaScript sem dependências de build */
(function () {
  'use strict';

  var config = window.CaptecPortalAdmin || {};
  var app = document.getElementById('captec-portal-app');
  if (!app) return;

  var state = {
    data: null,
    view: 'overview',
    catalogSearch: '',
    selectedQuote: null,
    modal: null,
    aiProposal: null,
    aiResponse: '',
    aiMode: 'guidance',
    assistantOpen: false,
    analyticsReport: null,
    analyticsLoading: false,
    analyticsError: '',
    analyticsFilters: { period: 'year', start: '', end: '' },
    trafficReport: null,
    trafficHealth: null,
    trafficLoading: false,
    trafficError: '',
    trafficFilters: { period: '30days', start: '', end: '' },
    activityLogs: [],
    activityDays: 30,
    activityLoading: false,
    activityError: '',
    previewDevice: 'desktop',
    previewPage: 'inicio',
    toastTimer: null
  };

  var icons = {
    grid: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/></svg>',
    home: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m4 10 8-6 8 6v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19v-9Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M9.5 20.5v-5h5v5" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
    layers: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m12 3 8 4.3-8 4.3-8-4.3L12 3Zm-8 9 8 4.3 8-4.3M4 16.7l8 4.3 8-4.3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    map: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m4 6 5-2 6 2 5-2v14l-5 2-6-2-5 2V6Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M9 4v14M15 6v14" stroke="currentColor" stroke-width="1.7"/></svg>',
    document: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M14 3H6.8A1.8 1.8 0 0 0 5 4.8v14.4A1.8 1.8 0 0 0 6.8 21h10.4a1.8 1.8 0 0 0 1.8-1.8V7L14 3Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M13.5 3v4.5H18M8.6 12h6.8M8.6 15.5h5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    inbox: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 5.5h15v13h-15z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M4.5 13h4l1.3 2h4.4l1.3-2h4" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
    brand: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3.5 19 7v5.2c0 3.9-2.6 6.9-7 8.3-4.4-1.4-7-4.4-7-8.3V7l7-3.5Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="m8.8 12 2.1 2.1 4.4-4.4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    chart: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 20V4M4 20h16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><path d="m7 16 3.2-4 3 2 4.8-6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    settings: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.7"/><path d="m19.2 13.5.1-1.5-.1-1.5 2-1.5-2-3.4-2.3.9a8.3 8.3 0 0 0-2.6-1.5L14 2.5h-4L9.7 5a8.3 8.3 0 0 0-2.6 1.5l-2.3-.9-2 3.4 2 1.5-.1 1.5.1 1.5-2 1.5 2 3.4 2.3-.9a8.3 8.3 0 0 0 2.6 1.5l.3 2.5h4l.3-2.5a8.3 8.3 0 0 0 2.6-1.5l2.3.9 2-3.4-2-1.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
    external: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M18 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
    edit: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m4.5 16.5-.7 3.7 3.7-.7L18.2 8.8l-3-3L4.5 16.5Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="m13.8 7.2 3 3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 7h14M10 10.5v5M14 10.5v5M8 7l.6-2h6.8l.6 2m-9.5 0 .8 12h9.4l.8-12" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    upload: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 15V4m0 0L8 8m4-4 4 4M5 15.5v3A1.5 1.5 0 0 0 6.5 20h11a1.5 1.5 0 0 0 1.5-1.5v-3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12 4.2 4.2L19 6.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="10.8" cy="10.8" r="5.8" stroke="currentColor" stroke-width="1.7"/><path d="m15.2 15.2 4.3 4.3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    image: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="4.5" width="17" height="15" rx="2" stroke="currentColor" stroke-width="1.7"/><circle cx="8.5" cy="9" r="1.5" stroke="currentColor" stroke-width="1.7"/><path d="m5.5 17 4.5-4 3.2 2.6 2.1-1.8 3.3 3.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.7"/><path d="M12 11v5M12 8v.1" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7.4 4.4 5.2 5.5c-.8.4-1.2 1.3-.9 2.2 1.7 5.6 6.1 10 11.7 11.7.9.3 1.8-.1 2.2-.9l1.1-2.2a1.5 1.5 0 0 0-.7-2l-3-1.3a1.5 1.5 0 0 0-1.7.4l-1.1 1.3a11 11 0 0 1-3.8-3.8l1.3-1.1a1.5 1.5 0 0 0 .4-1.7l-1.3-3a1.5 1.5 0 0 0-2-.7Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
    whatsapp: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20 11.4a7.7 7.7 0 0 1-11.4 6.8L4 19.5l1.3-4.3A7.7 7.7 0 1 1 20 11.4Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.1 8.2c.2-.4.4-.4.7-.4h.5c.2 0 .4.1.5.4l.6 1.5c.1.3.1.5-.1.7l-.5.6c.5 1 1.2 1.7 2.2 2.2l.6-.5c.2-.2.4-.2.7-.1l1.5.6c.3.1.4.3.4.5v.5c0 .3-.1.5-.4.7-.4.2-.9.3-1.3.2-3.1-.9-5.5-3.3-6.4-6.4-.1-.4 0-.9.2-1.3Z" fill="currentColor" stroke="none"/></svg>',
    mail: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="3.5" y="5.5" width="17" height="13" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="m4.5 7 7.5 5.6L19.5 7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    pin: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 10.2c0 5-7 10.3-7 10.3s-7-5.3-7-10.3a7 7 0 1 1 14 0Z" stroke="currentColor" stroke-width="1.7"/><circle cx="12" cy="10" r="2.2" stroke="currentColor" stroke-width="1.7"/></svg>',
    calendar: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="4" y="5.5" width="16" height="14" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3.5v4M16 3.5v4M4 10h16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.7"/><path d="M12 7v5.2l3.4 2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M14 3H6.8A1.8 1.8 0 0 0 5 4.8v14.4A1.8 1.8 0 0 0 6.8 21h10.4a1.8 1.8 0 0 0 1.8-1.8V7L14 3Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M13.5 3v4.5H18M8.6 12h6.8M8.6 15.5h6.8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    refresh: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M19 8.5V4.8l-1.4 1.4A7.7 7.7 0 1 0 19.5 13" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    quote: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7.7 10.4H5.2a1.7 1.7 0 0 0-1.7 1.7v3.1A1.7 1.7 0 0 0 5.2 17h2.5a1.7 1.7 0 0 0 1.7-1.7v-3.1a1.7 1.7 0 0 0-1.7-1.8ZM18.8 10.4h-2.5a1.7 1.7 0 0 0-1.7 1.7v3.1a1.7 1.7 0 0 0 1.7 1.7h2.5a1.7 1.7 0 0 0 1.7-1.7v-3.1a1.7 1.7 0 0 0-1.7-1.8Z" stroke="currentColor" stroke-width="1.7"/><path d="M9.4 10.5V8.8A3.8 3.8 0 0 1 13.2 5M20.5 10.5V8.8A3.8 3.8 0 0 1 24.3 5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    assistant: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3.5a7.5 7.5 0 0 0-4.7 13.3V20l3-1.5h1.7A7.5 7.5 0 1 0 12 3.5Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M8.7 11.5h.01M12 11.5h.01M15.3 11.5h.01" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>',
    microphone: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" stroke-width="1.7"/><path d="M6 11.5a6 6 0 0 0 12 0M12 17.5V21M8.5 21h7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
    power: '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3v8M18.4 6.6a8 8 0 1 1-12.8 0" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
  };

  var viewMeta = {
    overview: { kicker: 'Visão geral', title: 'Central de controle do portal', description: 'Acompanhe a estrutura do site e acesse rapidamente os conteúdos que exigem atenção.' },
    home: { kicker: 'Edição do site', title: 'Quem somos', description: 'Edite o Hero e as informações institucionais exibidas na página Quem somos.' },
    pagecontent: { kicker: 'Edição do site', title: 'Textos das páginas', description: 'Edite os textos das páginas. Aplicações, Diferenciais e Processo agora compõem a página Quem somos.' },
    preview: { kicker: 'Prévia', title: 'Pré-visualizar portal', description: 'Confira as atualizações em computador, tablet ou celular antes de concluir a publicação.' },
    products: { kicker: 'Catálogo', title: 'Produtos asfálticos', description: 'Gerencie cards, descrições, aplicações, imagens e fichas técnicas.' },
    applications: { kicker: 'Catálogo', title: 'Aplicações', description: 'Organize os contextos de infraestrutura exibidos na vitrine visual.' },
    locations: { kicker: 'Institucional', title: 'Matriz e filiais', description: 'Cadastre, publique, inative ou atualize os dados das unidades CAPTEC.' },
    pages: { kicker: 'Estrutura', title: 'Páginas e menu', description: 'Cada item do menu aponta para uma página WordPress própria, administrável por aqui.' },
    content: { kicker: 'Conteúdo', title: 'Blog e artigos', description: 'Crie, edite e publique conteúdos para fortalecer a presença técnica da CAPTEC.' },
    quotes: { kicker: 'Relacionamento', title: 'Central de cotações', description: 'Consulte solicitações recebidas pelo site e acompanhe cada atendimento.' },
    brand: { kicker: 'Identidade', title: 'Marca e contatos', description: 'Centralize logo, informações institucionais, canais comerciais e presença digital.' },
    buttons: { kicker: 'Configuração', title: 'Botões do site', description: 'Crie, edite, publique, deixe em rascunho ou exclua os botões usados nas áreas públicas.' },
    footer: { kicker: 'Configuração', title: 'Rodapé', description: 'Crie, edite, publique, deixe em rascunho ou exclua informações e links do rodapé.' },
    coverage: { kicker: 'Indicadores', title: 'Dados e cobertura', description: 'Publique apenas indicadores validados e mantenha os estados em destaque atualizados.' },
    appearance: { kicker: 'Configuração', title: 'Aparências', description: 'Personalize cores, largura, espaços, cabeçalho, menu e rodapé sem editar código.' },
    integrations: { kicker: 'Configuração', title: 'Integrações e LGPD', description: 'Configure medições e os links legais que orientam o consentimento de cookies.' },
    analytics: { kicker: 'Inteligência', title: 'Análise do portal', description: 'Acompanhe sessões, páginas, permanência e distribuição geográfica por meio do Google Analytics 4.' },
    activity: { kicker: 'Governança', title: 'Log de atividades', description: 'Acompanhe alterações realizadas no Portal CAPTEC e mantenha o histórico operacional dos últimos seis meses.' },
    features: { kicker: 'Controle', title: 'Funcionalidades e manutenção', description: 'Ative, inative e controle as funcionalidades públicas do portal com segurança.' },
    assistant: { kicker: 'Assistente', title: 'Agente IA CAPTEC', description: 'Receba orientação, use voz e aprove previamente qualquer ação proposta pelo agente.' }
  };

  function icon(name) { return icons[name] || ''; }
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>'"]/g, function (char) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char];
    });
  }
  function escapeAttr(value) { return escapeHtml(value); }
  function valueOf(key, fallback) {
    var value = state.data && state.data.settings ? state.data.settings[key] : undefined;
    return value == null || value === '' ? (fallback || '') : value;
  }
  function agentGreeting(ai, name) {
    var fallback = 'Oi! Meu nome é {nome}, seu assistente virtual!\n\nComo posso te ajudar?';
    return String((ai && ai.greeting) || fallback).replace(/\{nome\}|XXXXXX/gi, name || 'Assistente CAPTEC');
  }
  function textWithBreaks(value) { return escapeHtml(value || '').replace(/\n/g, '<br>'); }
  function formatDate(value) {
    if (!value) return '—';
    try { return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium' }).format(new Date(value)); }
    catch (e) { return value; }
  }
  function initials(value) {
    var text = String(value || 'C').trim();
    return text ? text.split(/\s+/).slice(0, 2).map(function (piece) { return piece.charAt(0); }).join('').toUpperCase() : 'C';
  }
  function statusLabel(status) {
    return { publish: 'Publicado', draft: 'Rascunho', new: 'Novo', in_progress: 'Em atendimento', won: 'Concluída', archived: 'Arquivada' }[status] || status;
  }
  function statusClass(status) {
    if (status === 'in_progress') return 'progress';
    return status || 'draft';
  }
  function textField(key, label, options) {
    options = options || {};
    var type = options.type || 'text';
    var full = options.full ? ' captec-field--full' : '';
    var hint = options.hint ? '<p class="captec-field__hint">' + escapeHtml(options.hint) + '</p>' : '';
    var placeholder = options.placeholder ? ' placeholder="' + escapeAttr(options.placeholder) + '"' : '';
    var required = options.required ? ' required' : '';
    var val = options.value != null ? options.value : valueOf(key, options.defaultValue || '');
    if (type === 'textarea') {
      return '<div class="captec-field' + full + '"><label for="field-' + escapeAttr(key) + '">' + escapeHtml(label) + (options.optional ? ' <small>opcional</small>' : '') + '</label><textarea class="captec-textarea' + (options.editor ? ' captec-textarea--editor' : '') + '" id="field-' + escapeAttr(key) + '" name="' + escapeAttr(key) + '"' + placeholder + required + '>' + escapeHtml(val) + '</textarea>' + hint + '</div>';
    }
    if (type === 'select') {
      var items = (options.options || []).map(function (option) {
        var opt = typeof option === 'object' ? option : { value: option, label: option };
        return '<option value="' + escapeAttr(opt.value) + '"' + (String(opt.value) === String(val) ? ' selected' : '') + '>' + escapeHtml(opt.label) + '</option>';
      }).join('');
      return '<div class="captec-field' + full + '"><label for="field-' + escapeAttr(key) + '">' + escapeHtml(label) + '</label><select class="captec-select" id="field-' + escapeAttr(key) + '" name="' + escapeAttr(key) + '">' + items + '</select>' + hint + '</div>';
    }
    return '<div class="captec-field' + full + '"><label for="field-' + escapeAttr(key) + '">' + escapeHtml(label) + (options.optional ? ' <small>opcional</small>' : '') + '</label><input class="captec-input" id="field-' + escapeAttr(key) + '" name="' + escapeAttr(key) + '" type="' + escapeAttr(type) + '" value="' + escapeAttr(val) + '"' + placeholder + required + '>' + hint + '</div>';
  }
  function mediaUrlField(key, label, options) {
    options = options || {};
    var value = options.value != null ? options.value : valueOf(key, '');
    return '<div class="captec-field' + (options.full ? ' captec-field--full' : '') + '"><label for="field-' + escapeAttr(key) + '">' + escapeHtml(label) + (options.optional ? ' <small>opcional</small>' : '') + '</label><div class="captec-input-group"><input class="captec-input" id="field-' + escapeAttr(key) + '" name="' + escapeAttr(key) + '" type="url" value="' + escapeAttr(value) + '" placeholder="https://…"><button class="captec-button captec-button--line" type="button" data-action="pick-setting-media" data-target="field-' + escapeAttr(key) + '" data-media-type="' + escapeAttr(options.mediaType || 'image') + '">' + icon('upload') + ' Selecionar</button></div>' + (options.hint ? '<p class="captec-field__hint">' + escapeHtml(options.hint) + '</p>' : '') + '</div>';
  }
  function sectionTitle(iconName, title, text) {
    return '<div class="captec-form-section__title">' + icon(iconName) + '<div><h2>' + escapeHtml(title) + '</h2>' + (text ? '<p>' + escapeHtml(text) + '</p>' : '') + '</div></div>';
  }
  function button(label, options) {
    options = options || {};
    var classes = 'captec-button ' + (options.className || 'captec-button--dark');
    var action = options.action ? ' data-action="' + escapeAttr(options.action) + '"' : '';
    var attrs = options.attrs || '';
    return '<button type="' + (options.type || 'button') + '" class="' + classes + '"' + action + attrs + '>' + (options.icon ? icon(options.icon) : '') + escapeHtml(label) + '</button>';
  }

  function settingsActionButtons(draftLabel) {
    var count = Number((state.data || {}).draft_settings_count || 0);
    var status = count ? 'Rascunho: ' + count + ' atualização' + (count > 1 ? 'ões pendentes' : ' pendente') : 'Publicado: sem atualizações pendentes';
    return '<div class="captec-settings-actions"><span class="captec-publish-status ' + (count ? 'is-draft' : 'is-published') + '">' + icon(count ? 'edit' : 'check') + escapeHtml(status) + '</span>'
      + button(draftLabel, { className: 'captec-button--yellow', type: 'submit', icon: 'check' })
      + button('Publicar atualizações', { className: 'captec-button--line', action: 'publish-draft-settings', icon: 'check', attrs: count ? '' : ' disabled aria-disabled="true"' })
      + '</div>';
  }

  function request(action, data) {
    data = data || {};
    if (config.demo) return demoRequest(action, data);
    var body = new URLSearchParams();
    body.append('action', action);
    body.append('nonce', config.nonce || '');
    Object.keys(data).forEach(function (key) { body.append(key, typeof data[key] === 'object' ? JSON.stringify(data[key]) : data[key]); });
    return fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() })
      .then(function (response) { return response.json(); })
      .then(function (response) {
        if (!response || !response.success) throw new Error((response && response.data && response.data.message) || (config.labels && config.labels.error) || 'Não foi possível concluir a ação.');
        return response.data;
      });
  }

  function demoRequest(action, payload) {
    return new Promise(function (resolve, reject) {
      window.setTimeout(function () {
        var data = window.CaptecPortalDemoData || state.data;
        if (action === 'captec_portal_bootstrap') return resolve(data);
        if (action === 'captec_portal_save_settings') {
          Object.keys(payload.payload || {}).forEach(function (key) { data.settings[key] = payload.payload[key]; });
          data.draft_settings_count = Object.keys(payload.payload || {}).length;
          return resolve({ message: 'Demonstração: rascunho salvo para prévia.', settings: data.settings, dashboard: data.dashboard, draft_settings_count: data.draft_settings_count });
        }
        if (action === 'captec_portal_publish_settings') { data.draft_settings_count = 0; return resolve({ message: 'Demonstração: configurações publicadas.', settings: data.settings, dashboard: data.dashboard, draft_settings_count: 0 }); }
        if (action === 'captec_portal_seed_catalog') return resolve({ message: 'Demonstração: catálogo já está pronto para edição.', products: data.products, applications: data.applications, locations: data.locations || [], dashboard: data.dashboard });
        if (action === 'captec_portal_generate_article') { var topicIndex=(data.suggested_topics||[]).findIndex(function(topic){return topic.id===payload.topic_id;}); if(topicIndex<0)return reject(new Error('Pauta não encontrada.')); var topic=data.suggested_topics.splice(topicIndex,1)[0]; var article={id:Date.now(),type:'article',title:topic.title,excerpt:topic.summary,content:'',status:'draft',date:new Date().toISOString(),modified:new Date().toISOString(),image_id:0,image_url:topic.image_url||'',category_id:1,category_names:[topic.category||'Atualização']}; data.articles.unshift(article); return resolve({message:'Demonstração: artigo criado como rascunho.',item:article,topics:data.suggested_topics}); }
        if (action === 'captec_portal_setup_pages') return resolve({ message: 'Demonstração: páginas e menu foram preparados.', pages: data.pages || [], dashboard: data.dashboard });
        if (action === 'captec_portal_save_features') { data.features = Object.assign({}, data.features || {}, { maintenance: !!payload.payload.maintenance, message: payload.payload.message || '', items: (data.features || {}).items || [] }); return resolve({ message: 'Demonstração: funcionalidades atualizadas.', features: data.features }); }
        if (action === 'captec_portal_ai_settings') { data.ai = Object.assign({}, data.ai || {}, payload.payload || {}); return resolve({ message: 'Demonstração: perfil do agente salvo.', ai: data.ai }); }
        if (action === 'captec_portal_ai_propose') { var cmd = String(payload.command || ''); var normalized = cmd.toLowerCase(); var maintenance = normalized.indexOf('manuten') > -1; return resolve({ proposal: { id: 'demo-' + Date.now(), command: cmd, type: maintenance ? 'maintenance' : 'guidance', title: maintenance ? (normalized.indexOf('desativ') > -1 ? 'Desativar modo de manutenção' : 'Ativar modo de manutenção') : 'Orientação indisponível', summary: maintenance ? 'Esta é uma prévia. A alteração só será feita após sua autorização.' : 'Não compreendi esta solicitação.\nEntre em contato com o Administrador do site para receber orientação.', requires_confirmation: maintenance } }); }
        if (action === 'captec_portal_ai_orient') return resolve({ message: 'Para esta demonstração, consulte o Manual do Portal CAPTEC ou entre em contato com o Administrador do site.' });
        if (action === 'captec_portal_ai_execute') return resolve({ message: 'Demonstração: ação autorizada e executada.', dashboard: data.dashboard, features: data.features });
        if (action === 'captec_portal_activity_logs') return resolve({ logs: data.activity_logs || [] });
        if (action === 'captec_portal_traffic_report') return resolve({ report: data.traffic_report || { range:{label:'Últimos 30 dias'}, summary:{pageviews:0,sessions:0,clicks:0,average_seconds:0}, pages:[], clicks:[], days:[], referrers:[] }, health: data.traffic_health || { table_ready:true, events:0, last_event:'', consent_note:'A coleta começa após consentimento analítico.' } });
        if (action === 'captec_portal_log_navigation') return resolve({});
        if (action === 'captec_portal_save_quote') {
          var quote = data.quotes.filter(function (item) { return Number(item.id) === Number(payload.payload.id); })[0];
          if (quote) { quote.workflow_status = payload.payload.workflow_status; quote.internal_note = payload.payload.internal_note; }
          return resolve({ message: 'Demonstração: cotação atualizada.', item: quote });
        }
        if (action === 'captec_portal_toggle_item_status') { var collectionToggle=data[itemCollectionKey(payload.content_type)]||[]; var changed=collectionToggle.filter(function(item){return Number(item.id)===Number(payload.id);})[0]; if(changed) changed.status=payload.status; return resolve({message:'Demonstração: status atualizado.',item:changed,dashboard:data.dashboard}); }
        if (action === 'captec_portal_delete_item') {
          var collection = data[itemCollectionKey(payload.content_type)] || [];
          var index = collection.findIndex(function (item) { return Number(item.id) === Number(payload.id); });
          if (index > -1) collection.splice(index, 1);
          return resolve({ message: 'Demonstração: item movido para a lixeira.', id: Number(payload.id), dashboard: data.dashboard });
        }
        if (action === 'captec_portal_save_item') {
          var item = payload.payload;
          var collectionKey = itemCollectionKey(item.type);
          var collection = data[collectionKey];
          var existing = collection.findIndex(function (entry) { return Number(entry.id) === Number(item.id); });
          if (!item.id) item.id = Date.now();
          item.modified = new Date().toISOString();
          item.date = item.date || new Date().toISOString();
          item.image_url = item.image_url || '';
          if (existing > -1) collection[existing] = Object.assign({}, collection[existing], item);
          else collection.unshift(item);
          return resolve({ message: 'Demonstração: item salvo.', item: item, dashboard: data.dashboard });
        }
        reject(new Error('Ação indisponível na demonstração.'));
      }, 320);
    });
  }

  function boot() {
    if (config.demo && window.CaptecPortalDemoData) {
      state.data = window.CaptecPortalDemoData;
      renderApp();
      return;
    }
    request('captec_portal_bootstrap').then(function (data) {
      state.data = data;
      renderApp();
    }).catch(function (error) {
      app.innerHTML = '<div class="captec-portal-loading"><div class="captec-loader-mark"><i></i><strong>CAPTEC</strong></div><p>' + escapeHtml(error.message || 'Não foi possível carregar o painel.') + '</p><button class="captec-button captec-button--yellow" type="button" data-action="reload">Tentar novamente</button></div>';
      app.addEventListener('click', handleClick, { once: true });
    });
  }

  function navItem(view, label, iconName, badge) {
    return '<li><button class="captec-nav__button' + (state.view === view ? ' is-active' : '') + '" type="button" data-view="' + view + '">' + icon(iconName) + '<span>' + escapeHtml(label) + '</span>' + (badge != null ? '<span class="captec-nav__badge">' + escapeHtml(badge) + '</span>' : '') + '</button></li>';
  }

  function renderApp() {
    var user = state.data.current_user || { name: 'Gestor CAPTEC', initial: 'C' };
    var quoteCount = (state.data.quotes || []).filter(function (quote) { return quote.workflow_status === 'new'; }).length;
    var draftCount = Number(state.data.draft_settings_count || 0);
    var draftButton = draftCount ? '<button class="captec-button captec-button--line" type="button" data-action="open-preview">' + icon('external') + ' Prévia (' + draftCount + ')</button>' : '';
    var publishButton = button('Publicar atualizações', { className: draftCount ? 'captec-button--yellow' : 'captec-button--line', action: 'publish-draft-settings', icon: 'check', attrs: draftCount ? '' : ' disabled aria-disabled="true"' });
    var adminLogo = state.data.settings && state.data.settings.custom_logo_url ? '<img class="captec-brand__logo" src="' + escapeAttr(state.data.settings.custom_logo_url) + '" alt="CAPTEC Asfaltos">' : '<i class="captec-brand__mark"></i><span><span class="captec-brand__name">CAPTEC</span><span class="captec-brand__sub">PORTAL ADMIN</span></span>';
    app.innerHTML = '<div class="captec-shell">'
      + '<aside class="captec-sidebar" data-sidebar>'
      + '<div class="captec-brand">' + adminLogo + '</div>'
      + '<span class="captec-sidebar__label">Gestão do portal</span>'
      + '<ul class="captec-nav">'
      + navItem('overview', 'Visão geral', 'grid')
      + navItem('home', 'Quem somos', 'home')
      + navItem('pagecontent', 'Textos das páginas', 'document')
      + navItem('preview', 'Pré-visualizar portal', 'external')
      + navItem('products', 'Produtos', 'layers')
      + navItem('applications', 'Aplicações', 'map')
      + navItem('locations', 'Matriz e filiais', 'pin')
      + navItem('pages', 'Páginas e menu', 'document')
      + navItem('content', 'Conteúdos', 'document')
      + navItem('quotes', 'Cotações', 'inbox', quoteCount || null)
      + '</ul>'
      + '<span class="captec-sidebar__label">Configuração</span>'
      + '<ul class="captec-nav">'
      + navItem('brand', 'Marca e contatos', 'brand')
      + navItem('buttons', 'Botões do site', 'settings')
      + navItem('footer', 'Rodapé', 'document')
      + navItem('appearance', 'Aparências', 'brand')
      + navItem('coverage', 'Dados e cobertura', 'chart')
      + navItem('analytics', 'Análise do portal', 'chart')
      + navItem('activity', 'Log de atividades', 'document')
      + navItem('features', 'Funcionalidades', 'power')
      + navItem('integrations', 'Integrações e LGPD', 'settings')
      + navItem('assistant', 'Agente IA', 'assistant')
      + '</ul>'
      + '<div class="captec-sidebar__bottom"><a class="captec-preview-link" href="' + escapeAttr(state.data.site_url || config.siteUrl || '#') + '" target="_blank" rel="noopener noreferrer">' + icon('external') + ' Abrir site publicado</a>'
      + '<div class="captec-sidebar__user"><span class="captec-avatar">' + escapeHtml(user.initial || initials(user.name)) + '</span><div><strong>' + escapeHtml(user.name || 'Gestor CAPTEC') + '</strong><span>Área administrativa</span></div></div></div>'
      + '</aside>'
      + '<main class="captec-main"><header class="captec-topbar"><div class="captec-topbar__left"><button class="captec-menu-toggle" type="button" data-action="toggle-sidebar" aria-label="Abrir menu">' + icon('menu') + '</button><div class="captec-topbar__meta"><p class="captec-breadcrumb">Portal CAPTEC / ' + escapeHtml((viewMeta[state.view] || viewMeta.overview).kicker) + '</p><h1 class="captec-page-title">' + escapeHtml((viewMeta[state.view] || viewMeta.overview).title) + '</h1></div></div><div class="captec-topbar__actions"><span class="captec-sync"><i class="captec-sync__dot"></i>Sincronizado com WordPress</span><a class="captec-button captec-button--line" href="' + escapeAttr(state.data.site_url || config.siteUrl || '#') + '" target="_blank" rel="noopener noreferrer">' + icon('external') + ' Ver site</a>' + button('Pré-visualizar', { className: 'captec-button--line', action: 'open-preview', icon: 'external' }) + draftButton + publishButton + button('Atualizar dados', { className: 'captec-button--dark', action: 'refresh', icon: 'refresh' }) + '</div></header><section class="captec-content" data-content></section></main></div><div data-ai-widget-root></div><div data-modal-root></div><div class="captec-toast" data-toast role="status" aria-live="polite"></div>';
    app.addEventListener('click', handleClick);
    app.addEventListener('submit', handleSubmit);
    app.addEventListener('input', handleInput);
    app.addEventListener('change', handleInput);
    renderView();
    renderAssistantWidget();
  }

  function refreshAdminLogo() {
    var holder = app.querySelector('.captec-brand');
    if (!holder) return;
    var logo = state.data && state.data.settings ? state.data.settings.custom_logo_url : '';
    holder.innerHTML = logo ? '<img class="captec-brand__logo" src="' + escapeAttr(logo) + '" alt="CAPTEC Asfaltos">' : '<i class="captec-brand__mark"></i><span><span class="captec-brand__name">CAPTEC</span><span class="captec-brand__sub">PORTAL ADMIN</span></span>';
  }

  function renderAssistantWidget() {
    var root = app.querySelector('[data-ai-widget-root]');
    if (!root) return;
    var ai = state.data && state.data.ai ? state.data.ai : { name: 'Nina CAPTEC', avatar_url: '', greeting: '' };
    var name = ai.name || 'Nina CAPTEC';
    var greeting = agentGreeting(ai, name);
    var avatar = ai.avatar_url ? '<img src="' + escapeAttr(ai.avatar_url) + '" alt="' + escapeAttr(name) + '">' : icon('assistant');
    var isGuidance = state.aiMode !== 'action';
    var panel = '';
    if (isGuidance) {
      panel = '<form data-form="ai-guidance"><label for="ai-widget-question">Como posso te ajudar?</label><div class="captec-ai-command"><textarea id="ai-widget-question" name="question" class="captec-textarea" placeholder="Digite ou fale sua dúvida sobre o portal…"></textarea><button class="captec-button captec-button--line captec-button--icon" type="button" data-action="voice-command" data-voice-target="question" aria-label="Falar orientação">' + icon('microphone') + '</button></div><p class="captec-field__hint" data-voice-status>Use texto ou voz. A resposta segue o Manual do Portal CAPTEC.</p>' + button('GERAR RESPOSTA', { className: 'captec-button--dark', type: 'submit', icon: 'assistant' }) + '</form>' + (state.aiResponse ? '<div class="captec-ai-widget__response"><span>Orientação</span><p>' + escapeHtml(state.aiResponse) + '</p><button type="button" data-action="clear-ai-response">Nova orientação</button></div>' : '');
    } else {
      var proposal = state.aiProposal;
      var preview = proposal ? '<div class="captec-ai-widget__preview"><span>Prévia do que será realizado</span><strong>' + escapeHtml(proposal.title) + '</strong><p>' + escapeHtml(proposal.summary) + '</p>' + (proposal.requires_confirmation ? '<div class="captec-ai-widget__actions">' + button('EXECUTAR', { className: 'captec-button--yellow', action: 'execute-ai-proposal', icon: 'check' }) + button('CANCELAR', { className: 'captec-button--line', action: 'clear-ai-proposal' }) + '</div>' : '<div class="captec-ai-widget__actions">' + button('Entendi', { className: 'captec-button--line', action: 'clear-ai-proposal' }) + '</div>') + '</div>' : '';
      panel = '<form data-form="ai-command"><label for="ai-widget-command">Qual ação deseja executar no portal?</label><div class="captec-ai-command"><textarea id="ai-widget-command" name="command" class="captec-textarea" placeholder="Ex.: ativar manutenção, criar produto CAP 60/85 ou inativar mapa."></textarea><button class="captec-button captec-button--line captec-button--icon" type="button" data-action="voice-command" data-voice-target="command" aria-label="Falar ação">' + icon('microphone') + '</button></div><p class="captec-field__hint" data-voice-status>O agente só executa funcionalidades do portal depois de apresentar a prévia e receber sua autorização.</p>' + button('GERAR PRÉVIA', { className: 'captec-button--dark', type: 'submit', icon: 'assistant' }) + '</form>' + preview;
    }
    var manualOffer = config.manualUrl ? '<div class="captec-ai-manual-offer"><p>Deseja o manual de orientações do portal de administração?</p><a class="captec-button captec-button--line" href="' + escapeAttr(config.manualUrl) + '" target="_blank" rel="noopener noreferrer">' + icon('file') + ' Sim, abrir manual em PDF</a></div>' : '';
    root.innerHTML = '<button class="captec-ai-fab" type="button" data-action="toggle-ai-widget" aria-label="Abrir assistente IA" aria-expanded="' + (state.assistantOpen ? 'true' : 'false') + '"><span class="captec-ai-fab__avatar">' + avatar + '</span><span class="captec-ai-fab__text"><strong>' + escapeHtml(name) + '</strong><small>Assistente IA</small></span><span class="captec-ai-fab__pulse"></span></button>'
      + '<aside class="captec-ai-widget' + (state.assistantOpen ? ' is-open' : '') + '" data-ai-widget role="dialog" aria-label="Assistente IA CAPTEC" aria-hidden="' + (state.assistantOpen ? 'false' : 'true') + '"><header class="captec-ai-widget__head"><div class="captec-ai-widget__identity"><div class="captec-ai-widget__avatar">' + avatar + '</div><div><div class="captec-ai-widget__greeting">' + textWithBreaks(greeting) + '</div></div></div><button class="captec-modal__close" type="button" data-action="close-ai-widget" aria-label="Fechar assistente">' + icon('close') + '</button></header><div class="captec-ai-widget__body"><div class="captec-ai-mode"><button type="button" class="' + (isGuidance ? 'is-active' : '') + '" data-action="set-ai-mode" data-ai-mode="guidance">Quero orientação</button><button type="button" class="' + (!isGuidance ? 'is-active' : '') + '" data-action="set-ai-mode" data-ai-mode="action">Executar ação</button></div>' + panel + manualOffer + '</div></aside>';
  }

  function renderView() {
    var target = app.querySelector('[data-content]');
    if (!target || !state.data) return;
    var meta = viewMeta[state.view] || viewMeta.overview;
    target.innerHTML = '<div class="captec-view-head"><div class="captec-view-head__content"><p class="captec-kicker">' + escapeHtml(meta.kicker) + '</p><h1>' + escapeHtml(meta.title) + '</h1><p>' + escapeHtml(meta.description) + '</p></div>' + viewActions() + '</div>' + renderCurrentView();
    updateNav();
  }

  function viewActions() {
    if (state.view === 'products') return '<div class="captec-view-head__actions">' + button('Novo produto', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="product"' }) + '</div>';
    if (state.view === 'applications') return '<div class="captec-view-head__actions">' + button('Nova aplicação', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="application"' }) + '</div>';
    if (state.view === 'locations') return '<div class="captec-view-head__actions">' + button('Nova unidade', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="location"' }) + '</div>';
    if (state.view === 'pages') return '<div class="captec-view-head__actions">' + button('Criar estrutura', { className: 'captec-button--yellow', action: 'setup-pages', icon: 'plus' }) + button('Nova página', { className: 'captec-button--line', action: 'new-item', icon: 'plus', attrs: ' data-content-type="page"' }) + '</div>';
    if (state.view === 'content') return '<div class="captec-view-head__actions">' + button('Novo artigo', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="article"' }) + '</div>';
    if (state.view === 'buttons') return '<div class="captec-view-head__actions">' + button('Novo botão', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="button"' }) + '</div>';
    if (state.view === 'footer') return '<div class="captec-view-head__actions">' + button('Novo item do rodapé', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="footer_item"' }) + '</div>';
    if (state.view === 'coverage') return '<div class="captec-view-head__actions">' + button('Novo indicador', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="stat"' }) + '</div>';
    return '';
  }

  function renderCurrentView() {
    if (state.view === 'home') return renderHome();
    if (state.view === 'pagecontent') return renderPageContent();
    if (state.view === 'preview') return renderPortalPreview();
    if (state.view === 'products') return renderCatalog('product');
    if (state.view === 'applications') return renderCatalog('application');
    if (state.view === 'locations') return renderCatalog('location');
    if (state.view === 'pages') return renderPages();
    if (state.view === 'content') return renderContent();
    if (state.view === 'quotes') return renderQuotes();
    if (state.view === 'brand') return renderBrand();
    if (state.view === 'buttons') return renderButtons();
    if (state.view === 'footer') return renderFooterManager();
    if (state.view === 'coverage') return renderCoverage();
    if (state.view === 'appearance') return renderAppearance();
    if (state.view === 'analytics') return renderAnalytics();
    if (state.view === 'activity') return renderActivity();
    if (state.view === 'features') return renderFeatures();
    if (state.view === 'integrations') return renderIntegrations();
    if (state.view === 'assistant') return renderAssistant();
    return renderOverview();
  }

  function updateNav() {
    app.querySelectorAll('[data-view]').forEach(function (buttonElement) {
      buttonElement.classList.toggle('is-active', buttonElement.getAttribute('data-view') === state.view);
    });
    var pageMeta = viewMeta[state.view] || viewMeta.overview;
    var title = app.querySelector('.captec-page-title');
    var breadcrumb = app.querySelector('.captec-breadcrumb');
    if (title) title.textContent = pageMeta.title;
    if (breadcrumb) breadcrumb.textContent = 'Portal CAPTEC / ' + pageMeta.kicker;
  }

  function renderOverview() {
    var dash = state.data.dashboard || { cards: [], checks: [], completion: 0 };
    var warning = dash.theme_ready === false ? '<div class="captec-theme-warning">' + icon('info') + '<div><strong>Tema CAPTEC não identificado</strong>Ative o tema CAPTEC Asfaltos para que os conteúdos deste painel sejam refletidos na estrutura visual do portal.</div></div>' : '';
    var cards = (dash.cards || []).map(function (card) {
      return '<button class="captec-metric" type="button" data-view="' + escapeAttr(card.view) + '"><span class="captec-metric__icon">' + icon(card.icon) + '</span><strong class="captec-metric__value">' + escapeHtml(card.value) + '</strong><span class="captec-metric__label">' + escapeHtml(card.label) + '</span></button>';
    }).join('');
    var checks = (dash.checks || []).map(function (check) {
      return '<li><button type="button" data-view="' + escapeAttr(check.view) + '"><span class="captec-check' + (check.complete ? ' is-complete' : '') + '">' + icon('check') + '</span><span>' + escapeHtml(check.label) + '</span></button></li>';
    }).join('');
    return warning + '<div class="captec-dashboard-grid">' + cards + '</div><div class="captec-overview-grid"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Prontidão para publicação</h2><p>Itens essenciais que merecem validação antes de divulgar o portal.</p></div></div><div class="captec-panel__body"><div class="captec-progress-row"><div class="captec-progress" style="--progress:' + Number(dash.completion || 0) + '"><strong>' + Number(dash.completion || 0) + '%</strong></div><div class="captec-progress-copy"><strong>Configuração institucional</strong><p>Complete os dados aprovados pela empresa. Campos sem validação não são preenchidos automaticamente.</p></div></div><ul class="captec-check-list">' + checks + '</ul></div></section><aside class="captec-panel"><div class="captec-panel__head"><div><h2>Ações rápidas</h2><p>Atalhos para a rotina do portal.</p></div></div><div class="captec-panel__body"><div class="captec-status-stack"><div class="captec-status-card"><span class="captec-status-card__icon">' + icon('quote') + '</span><div><strong>Cotações em um só lugar</strong><span>Registros privados e protegidos no WordPress.</span></div></div><div class="captec-status-card"><span class="captec-status-card__icon">' + icon('upload') + '</span><div><strong>Biblioteca de mídia</strong><span>Imagens e arquivos selecionados da mídia do WordPress.</span></div></div></div><div class="captec-quick-actions">' + button('Editar Quem somos', { className: 'captec-button--line', action: 'go-home', icon: 'home' }) + button('Criar artigo', { className: 'captec-button--line', action: 'new-item', icon: 'plus', attrs: ' data-content-type="article"' }) + '</div></div></aside></div>';
  }

  function previewPages() {
    var defaults = [
      { slug: 'inicio', title: 'Quem somos', path: '' }, { slug: 'produtos', title: 'Produtos' }, { slug: 'unidades', title: 'Unidades' }, { slug: 'cobertura', title: 'Cobertura' }, { slug: 'blog', title: 'Conteúdos' }, { slug: 'trabalhe-conosco', title: 'Trabalhe conosco' }, { slug: 'cotacao', title: 'Solicitar Cotação' }
    ];
    var pages = state.data.pages || [];
    return defaults.map(function (item) {
      var stored = pages.filter(function (page) { return page.slug === item.slug; })[0];
      return { slug: item.slug, title: stored ? stored.title : item.title, path: item.path === '' ? '' : item.slug };
    });
  }

  function portalPreviewUrl(page) {
    var base = (state.data.site_url || config.siteUrl || '/').replace(/\/?$/, '/');
    if (config.demo) {
      var previewFile = page && page.path ? page.path.replace(/^\//, '') + '.html' : 'index.html';
      return base + previewFile + '?captec_admin_preview=1&captec_preview_ts=' + Date.now();
    }
    var path = page && page.path ? page.path.replace(/^\//, '') + '/' : '';
    return base + path + '?captec_admin_preview=1&captec_preview_ts=' + Date.now();
  }

  function renderPortalPreview() {
    var pages = previewPages();
    var selected = pages.filter(function (page) { return page.slug === state.previewPage; })[0] || pages[0];
    var device = state.previewDevice || 'desktop';
    var deviceLabel = { desktop: 'Computador', tablet: 'Tablet', mobile: 'Celular' }[device] || 'Computador';
    var controls = ['desktop', 'tablet', 'mobile'].map(function (name) {
      return '<button type="button" class="captec-preview-device' + (device === name ? ' is-active' : '') + '" data-action="set-preview-device" data-preview-device="' + name + '">' + icon(name === 'desktop' ? 'grid' : name === 'tablet' ? 'document' : 'phone') + '<span>' + ({desktop:'Computador',tablet:'Tablet',mobile:'Celular'}[name]) + '</span></button>';
    }).join('');
    var pageButtons = pages.map(function (page) { return '<button type="button" class="captec-preview-page' + (page.slug === selected.slug ? ' is-active' : '') + '" data-action="set-preview-page" data-preview-page="' + escapeAttr(page.slug) + '">' + escapeHtml(page.title) + '</button>'; }).join('');
    var url = portalPreviewUrl(selected);
    var draftCount = Number(state.data.draft_settings_count || 0);
    var publish = draftCount ? button('Publicar ' + draftCount + ' alteração' + (draftCount > 1 ? 'ões' : ''), { className: 'captec-button--yellow', action: 'publish-draft-settings', icon: 'check' }) : '<span class="captec-preview-published">Nenhuma configuração pendente</span>';
    return '<section class="captec-preview-panel"><header class="captec-preview-panel__head"><div><span>Prévia administrativa</span><h2>' + escapeHtml(selected.title) + ' — ' + escapeHtml(deviceLabel) + '</h2><p>' + (draftCount ? 'Você está vendo ' + draftCount + ' alteração' + (draftCount > 1 ? 'ões' : '') + ' ainda não publicada' + (draftCount > 1 ? 's' : '') + '.' : 'Visualização do estado publicado do portal. Salve alterações em rascunho para pré-visualizá-las aqui.') + '</p></div><div class="captec-preview-panel__actions">' + publish + controls + '</div></header><div class="captec-preview-pages"><span>Página:</span>' + pageButtons + '</div><div class="captec-preview-stage captec-preview-stage--' + device + '"><div class="captec-preview-browser"><div class="captec-preview-browser__bar"><i></i><i></i><i></i><span>' + escapeHtml(url.replace(/\?.*/, '')) + '</span>' + button('Atualizar', { className: 'captec-button--line', action: 'refresh-preview', icon: 'refresh' }) + '</div><iframe class="captec-preview-iframe" title="Prévia ' + escapeAttr(selected.title) + ' em ' + escapeAttr(deviceLabel) + '" src="' + escapeAttr(url) + '"></iframe></div></div></section><div class="captec-preview-note">' + icon('info') + '<span>Use os controles de dispositivo para conferir responsividade. A prévia é exibida com sua sessão administrativa e sem a barra do WordPress.</span></div>';
  }

  function renderHome() {
    return '<form data-form="settings" data-settings-scope="home"><div class="captec-editor-layout"><div class="captec-editor-stack"><section class="captec-panel captec-form-section">'
      + sectionTitle('home', 'Hero de abertura', 'Conteúdo, chamadas e mídia da primeira área vista por quem acessa o site.')
      + '<div class="captec-form-grid">'
      + textField('captec_hero_kicker', 'Etiqueta acima do título', { defaultValue: 'Produtos asfálticos para infraestrutura', full: true })
      + textField('captec_hero_title', 'Título principal')
      + textField('captec_hero_subtitle', 'Subtítulo')
      + textField('captec_hero_text', 'Texto de apoio', { type: 'textarea', full: true })
      + '<div class="captec-field captec-field--full"><div class="captec-inline-note"><span>' + icon('info') + '</span><p>Os botões desta página são controlados em Botões do site para que texto, destino, estilo e status sejam alterados em um só lugar.</p>' + button('Gerenciar botões', { className:'captec-button--line', attrs:' data-view="buttons"', icon:'settings' }) + '</div></div>'
      + textField('captec_hero_scroll_label', 'Chamada de rolagem', { defaultValue: 'Conheça a CAPTEC', full: true })
      + mediaUrlField('captec_hero_poster', 'Imagem de fallback', { mediaType: 'image', hint: 'Exibida durante o carregamento do vídeo e em dispositivos que bloqueiam autoplay.' })
      + mediaUrlField('captec_hero_video_url', 'Vídeo de fundo', { mediaType: 'video', hint: 'Use MP4 otimizado, preferencialmente hospedado na Biblioteca de Mídia.' })
      + '</div><div class="captec-form-grid" style="margin-top:17px">' + renderHeroCardFields() + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('brand', 'Quem somos', 'Texto institucional, selo visual e pilares exibidos na página Quem somos.')
      + '<div class="captec-form-grid">'
      + textField('captec_about_eyebrow', 'Etiqueta da seção')
      + textField('captec_about_title', 'Título da seção', { type: 'textarea' })
      + textField('captec_about_text_1', 'Primeiro parágrafo', { type: 'textarea', full: true })
      + textField('captec_about_text_2', 'Segundo parágrafo', { type: 'textarea', full: true })
      + textField('captec_about_badge_label', 'Etiqueta do selo', { defaultValue: 'Infraestrutura' })
      + textField('captec_about_badge_text', 'Texto do selo', { defaultValue: 'com visão de parceria' })
      + mediaUrlField('captec_about_image', 'Imagem institucional', { mediaType: 'image', full: true })
      + '</div><div class="captec-form-grid" style="margin-top:17px">'
      + textField('captec_about_pillar_1', 'Pilar 1', { defaultValue: 'Foco na qualidade' })
      + textField('captec_about_pillar_2', 'Pilar 2', { defaultValue: 'Relações de confiança' })
      + textField('captec_about_pillar_3', 'Pilar 3', { defaultValue: 'Eficiência comercial' })
      + textField('captec_about_pillar_4', 'Pilar 4', { defaultValue: 'Visão de longo prazo' })
      + '</div></section>'
      + '</div><aside class="captec-panel"><div class="captec-side-card"><h3>Prévia de estrutura</h3><p>Salve como rascunho e use Pré-visualizar portal antes de publicar.</p><div class="captec-site-preview"><p class="captec-site-preview__top"><i></i>PRODUTOS ASFÁLTICOS</p><h4>' + escapeHtml(valueOf('captec_hero_title', 'CAPTEC ASFALTOS').replace(' ASFALTOS', '')) + '<span>ASFALTOS</span></h4><div class="captec-site-preview__line"></div></div></div><div class="captec-side-card"><h3>Gestão completa da Home</h3><ul class="captec-mini-list"><li><i></i>Hero, institucional e mídia</li><li><i></i>Aplicações, diferenciais e processo</li><li><i></i>Conteúdo salvo na página Quem somos</li></ul></div><div class="captec-side-card">' + settingsActionButtons('Salvar rascunho de Quem somos') + '</div></aside></div></form>';
  }

  function renderPageContent() {
    return '<form data-form="settings" data-settings-scope="pagecontent"><div class="captec-editor-layout"><div class="captec-editor-stack">' + renderHomeEditorialBlocks() + '</div><aside class="captec-panel"><div class="captec-side-card"><h3>Conteúdo no WordPress</h3><p>Quem somos reúne o institucional, Aplicações, Diferenciais e Processo. O conteúdo também fica salvo no editor nativo de Páginas do WordPress.</p><ul class="captec-mini-list"><li><i></i>Quem somos, Aplicações e Diferenciais</li><li><i></i>Produtos, Unidades e Cobertura</li><li><i></i>Conteúdos, Cotação e Trabalhe conosco</li></ul></div><div class="captec-side-card">' + settingsActionButtons('Salvar rascunho das páginas') + '</div></aside></div></form>';
  }

  function renderHeroCardFields() {
    var output = '<div class="captec-field captec-field--full"><label>Cards de apoio do Hero <small>os quatro cards sobrepostos ao final da primeira tela</small></label></div>';
    for (var i = 1; i <= 4; i++) {
      output += textField('captec_hero_card_' + i + '_title', 'Card ' + i + ' — título', { defaultValue: ['Produtos de Qualidade', 'Atendimento Especializado', 'Logística Eficiente', 'Suporte Comercial'][i - 1] });
      output += textField('captec_hero_card_' + i + '_text', 'Card ' + i + ' — apoio', { defaultValue: ['Soluções alinhadas ao projeto', 'Escuta e orientação comercial', 'Planejamento para cada demanda', 'Acompanhamento do início ao pós-venda'][i - 1] });
    }
    return output;
  }

  function renderHomeEditorialBlocks() {
    var differentialFields = '';
    var differentialDefaults = [
      ['Atendimento Consultivo', 'Entendimento da demanda antes da construção da proposta.'],
      ['Equipe Comercial Especializada', 'Comunicação objetiva para apoiar a rotina de compras e obras.'],
      ['Qualidade dos Produtos', 'Portfólio apresentado de acordo com a especificação solicitada.'],
      ['Agilidade nas Cotações', 'Fluxo comercial organizado para dar visibilidade à solicitação.'],
      ['Planejamento Logístico', 'Programação alinhada à necessidade informada no pedido.'],
      ['Relacionamento de Longo Prazo', 'Proximidade e acompanhamento que valorizam a parceria.']
    ];
    for (var d = 1; d <= 6; d++) {
      differentialFields += textField('captec_differential_' + d + '_title', 'Diferencial ' + d + ' — título', { defaultValue: differentialDefaults[d - 1][0] });
      differentialFields += textField('captec_differential_' + d + '_text', 'Diferencial ' + d + ' — apoio', { defaultValue: differentialDefaults[d - 1][1], type: 'textarea' });
    }
    var processFields = '';
    var processDefaults = [
      ['Contato', 'Você compartilha os dados iniciais da sua necessidade.'],
      ['Cotação', 'A demanda é analisada para construção da proposta comercial.'],
      ['Negociação', 'Alinhamos as condições e os pontos relevantes do fornecimento.'],
      ['Programação', 'A entrega é organizada conforme o pedido confirmado.'],
      ['Entrega', 'Acompanhamos a etapa de fornecimento combinada.'],
      ['Pós-venda', 'Mantemos o canal aberto para continuidade do relacionamento.']
    ];
    for (var p = 1; p <= 6; p++) {
      processFields += textField('captec_process_' + p + '_title', 'Etapa ' + p + ' — título', { defaultValue: processDefaults[p - 1][0] });
      processFields += textField('captec_process_' + p + '_text', 'Etapa ' + p + ' — apoio', { defaultValue: processDefaults[p - 1][1], type: 'textarea' });
    }
    return '<section class="captec-panel captec-form-section">'
      + sectionTitle('layers', 'Portfólio e aplicações', 'Controle a redação de Produtos e da seção Aplicações, exibida dentro de Quem somos. Os cards são editados nos menus próprios.')
      + '<div class="captec-form-grid">'
      + textField('captec_products_eyebrow', 'Produtos — etiqueta', { defaultValue: 'Portfólio' })
      + textField('captec_products_title', 'Produtos — título', { defaultValue: 'Produtos para especificações que pedem precisão.', type: 'textarea' })
      + textField('captec_products_intro', 'Produtos — texto de apoio', { defaultValue: 'Conheça as soluções disponíveis e solicite uma cotação de acordo com as necessidades técnicas da sua obra.', type: 'textarea', full: true })
      + textField('captec_products_bar_text', 'Produtos — chamada auxiliar', { defaultValue: 'Selecione um produto para enviar sua demanda comercial.' })
      + textField('captec_products_bar_cta', 'Produtos — botão auxiliar', { defaultValue: 'Preciso de orientação' })
      + textField('captec_products_note', 'Produtos — observação', { defaultValue: 'A disponibilidade e a aplicação devem ser confirmadas na cotação, de acordo com a especificação da obra.', type: 'textarea', full: true })
      + textField('captec_applications_eyebrow', 'Aplicações — etiqueta', { defaultValue: 'Onde a CAPTEC atua' })
      + textField('captec_applications_title', 'Aplicações — título', { defaultValue: 'Soluções que acompanham diferentes contextos de infraestrutura.', type: 'textarea' })
      + textField('captec_applications_intro', 'Aplicações — texto de apoio', { defaultValue: 'Cada aplicação pede planejamento e produtos alinhados à sua especificação técnica.', type: 'textarea', full: true })
      + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('brand', 'Diferenciais', 'Edite os seis argumentos institucionais exibidos na seção Diferenciais da página Quem somos.')
      + '<div class="captec-form-grid">'
      + textField('captec_differentials_eyebrow', 'Etiqueta da seção', { defaultValue: 'Por que escolher a CAPTEC' })
      + textField('captec_differentials_title', 'Título da seção', { defaultValue: 'Uma experiência comercial orientada para a sua obra.', type: 'textarea' })
      + textField('captec_differentials_intro', 'Texto de apoio', { defaultValue: 'Mais clareza em cada etapa, para que a sua equipe avance com segurança na tomada de decisão.', type: 'textarea', full: true })
      + differentialFields + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('clock', 'Processo e jornada comercial', 'A sequência aparece como uma linha do tempo na página Quem somos.')
      + '<div class="captec-form-grid">'
      + textField('captec_process_eyebrow', 'Etiqueta da seção', { defaultValue: 'Processo' })
      + textField('captec_process_title', 'Título da seção', { defaultValue: 'Do primeiro contato ao pós-venda, com mais clareza.', type: 'textarea' })
      + textField('captec_process_intro', 'Texto de apoio', { defaultValue: 'Um caminho comercial pensado para tornar a solicitação mais simples e o acompanhamento mais próximo.', type: 'textarea', full: true })
      + processFields + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('settings', 'Cobertura, conteúdo, cotação e carreira', 'Ajuste as chamadas exibidas nas páginas correspondentes.')
      + '<div class="captec-form-grid">'
      + textField('captec_stats_eyebrow', 'Indicadores — etiqueta', { defaultValue: 'Indicadores' })
      + textField('captec_stats_title', 'Indicadores — título', { defaultValue: 'Indicadores que refletem nossa atuação', type: 'textarea' })
      + textField('captec_stats_intro', 'Indicadores — texto de apoio', { defaultValue: 'A transparência faz parte do nosso compromisso com clientes, parceiros e colaboradores. Nesta seção, apresentamos os principais indicadores da empresa, reunindo números que demonstram nossa capacidade de atendimento, presença nacional, portfólio de produtos e volume de fornecimento.', type: 'textarea', full: true })
      + textField('captec_map_eyebrow', 'Mapa — etiqueta', { defaultValue: 'Cobertura' })
      + textField('captec_map_title', 'Mapa — título', { defaultValue: 'Uma conversa começa onde a sua obra está.', type: 'textarea' })
      + textField('captec_map_intro', 'Mapa — texto de apoio', { defaultValue: 'Use o mapa como referência visual e entre em contato para verificar a disponibilidade de atendimento para sua localidade e demanda.', type: 'textarea', full: true })
      + textField('captec_map_feature_1', 'Mapa — item 1', { defaultValue: 'Mapa interativo preparado para destaque de estados.' })
      + textField('captec_map_feature_2', 'Mapa — item 2', { defaultValue: 'Estados configuráveis diretamente no Personalizar.' })
      + textField('captec_map_feature_3', 'Mapa — item 3', { defaultValue: 'Consulta comercial sem compromisso.', full: true })
      + textField('captec_blog_eyebrow', 'Blog — etiqueta', { defaultValue: 'Conteúdos' })
      + textField('captec_blog_title', 'Blog — título', { defaultValue: 'Informação técnica para decisões mais claras.', type: 'textarea' })
      + textField('captec_blog_cta', 'Blog — botão', { defaultValue: 'Ver todos os artigos', full: true })
      + textField('captec_quote_eyebrow', 'Cotação — etiqueta', { defaultValue: 'Fale com a CAPTEC' })
      + textField('captec_quote_title', 'Cotação — título', { defaultValue: 'Vamos entender a sua demanda.', type: 'textarea' })
      + textField('captec_quote_text', 'Cotação — texto de apoio', { defaultValue: 'Envie as informações da obra. Quanto mais contexto você compartilhar, mais objetiva será a análise comercial.', type: 'textarea', full: true })
      + textField('captec_quote_form_title', 'Cotação — título do formulário', { defaultValue: 'Solicitar cotação', full: true })
      + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('mail', 'Trabalhe conosco', 'Defina o texto da página e o canal que recebe currículos. Se este e-mail ficar vazio, o e-mail comercial será usado.')
      + '<div class="captec-form-grid">'
      + textField('captec_careers_eyebrow', 'Etiqueta', { defaultValue: 'Trabalhe conosco' })
      + textField('captec_careers_title', 'Título', { defaultValue: 'Construa caminhos com a CAPTEC.', type: 'textarea' })
      + textField('captec_careers_text', 'Texto de apresentação', { defaultValue: 'Se você deseja fazer parte do nosso time, envie seu currículo para análise.', type: 'textarea', full: true })
      + textField('captec_careers_instruction', 'Orientação para candidatura', { defaultValue: 'No e-mail, informe sua cidade/UF, área de interesse e envie o currículo em PDF.', type: 'textarea', full: true })
      + textField('captec_careers_email', 'E-mail para currículos', { type: 'email', optional: true, hint: 'Opcional. Se ficar vazio, será usado o e-mail comercial.' })
      + '<div class="captec-field captec-field--full"><div class="captec-inline-note"><span>' + icon('info') + '</span><p>O botão de currículo é administrado em Botões do site. Lá você pode editar texto, destino, estilo e status.</p>' + button('Gerenciar botões', { className:'captec-button--line', attrs:' data-view="buttons"', icon:'settings' }) + '</div></div>'
      + textField('captec_careers_note', 'Observação final', { defaultValue: 'As candidaturas são avaliadas conforme as necessidades da empresa.', type: 'textarea', full: true })
      + '</div></section>';
  }

  function statusToggleButton(item, type) {
    var published = item.status === 'publish';
    return button(published ? 'Publicado' : 'Rascunho', {
      className: published ? 'captec-button--yellow' : 'captec-button--line',
      action: 'toggle-item-status',
      icon: published ? 'check' : 'edit',
      attrs: ' data-content-type="' + escapeAttr(type) + '" data-id="' + Number(item.id) + '" data-status="' + (published ? 'draft' : 'publish') + '"'
    });
  }

  function catalogItemCard(item, type) {
    var isProduct = type === 'product';
    var isLocation = type === 'location';
    var detail = isProduct ? (item.description || item.content || 'Descrição ainda não preenchida.') : isLocation ? ([item.street, item.number, item.city, item.state].filter(Boolean).join(', ') || 'Endereço ainda não preenchido.') : (item.subtitle || 'Linha de apoio ainda não preenchida.');
    var visual = item.image_url ? '<img src="' + escapeAttr(item.image_url) + '" alt="">' : icon(isProduct ? 'layers' : isLocation ? 'pin' : 'map');
    var meta = isProduct ? (item.product_type || 'Produto asfáltico') : isLocation ? (item.kind === 'headquarters' ? 'Matriz' : 'Filial') : (item.subtitle || 'Aplicação');
    return '<article class="captec-catalog-card"><div class="captec-catalog-card__image' + (!item.image_url ? ' captec-catalog-card__image--empty' : '') + '">' + visual + '<span class="captec-status captec-status--' + statusClass(item.status) + '">' + escapeHtml(item.status === 'publish' && isLocation ? 'Ativa' : statusLabel(item.status)) + '</span></div><div class="captec-catalog-card__body"><p class="captec-catalog-card__meta">' + escapeHtml(meta) + '</p><h2>' + escapeHtml(item.title) + '</h2><p>' + escapeHtml(detail) + '</p></div><footer class="captec-catalog-card__footer"><span class="captec-order">Ordem <strong>' + String(Number(item.order || 0) + 1).padStart(2, '0') + '</strong></span><div class="captec-catalog-card__actions">' + statusToggleButton(item, type) + button('Editar', { className: 'captec-button--line', action: 'edit-item', icon: 'edit', attrs: ' data-content-type="' + type + '" data-id="' + item.id + '"' }) + '</div></footer></article>';
  }

  function renderCatalog(type) {
    var source = type === 'product' ? (state.data.products || []) : type === 'application' ? (state.data.applications || []) : (state.data.locations || []);
    var search = state.catalogSearch || '';
    var items = source.filter(function (item) {
      return String(item.title || '').toLowerCase().indexOf(search.toLowerCase()) > -1 || String(item.description || item.subtitle || item.city || item.state || '').toLowerCase().indexOf(search.toLowerCase()) > -1;
    });
    var singular = type === 'product' ? 'produto' : type === 'application' ? 'aplicação' : 'unidade';
    var plural = type === 'product' ? 'produtos' : type === 'application' ? 'aplicações' : 'unidades';
    var emptyIcon = type === 'product' ? 'layers' : type === 'application' ? 'map' : 'pin';
    var createLabel = type === 'product' ? 'Criar produto' : type === 'application' ? 'Criar aplicação' : 'Criar unidade';
    var toolbar = '<div class="captec-catalog-toolbar"><div class="captec-search">' + icon('search') + '<input class="captec-input" type="search" value="' + escapeAttr(search) + '" placeholder="Buscar ' + plural + '" data-catalog-search="' + type + '"></div><div class="captec-catalog-meta">' + items.length + ' ' + plural + ' exibidos</div></div>';
    if (!state.data.catalog_ready) return '<div class="captec-theme-warning">' + icon('info') + '<div><strong>Catálogo indisponível</strong>O tema CAPTEC Asfaltos precisa estar ativo para registrar produtos, aplicações e unidades.</div></div>';
    if (!source.length) return toolbar + '<div class="captec-empty"><div><span class="captec-empty__icon">' + icon(emptyIcon) + '</span><h2>Nenhuma ' + singular + ' cadastrada</h2><p>Crie o item manualmente ou prepare a estrutura inicial do portal.</p>' + button(createLabel, { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="' + type + '"' }) + (type !== 'application' ? ' ' + button('Preparar estrutura base', { className: 'captec-button--line', action: 'seed-catalog', icon: 'layers' }) : '') + '</div></div>';
    return toolbar + '<div class="captec-catalog-grid">' + items.map(function (item) { return catalogItemCard(item, type); }).join('') + '</div>';
  }

  function pageContentExcerpt(page) {
    var content = String((page && page.content) || '').trim();
    if (!content) return 'Nenhum conteúdo no WordPress ainda.';
    var labels = {
      '[captec_quem_somos]': 'Seção Quem somos',
      '[captec_aplicacoes]': 'Seção Aplicações',
      '[captec_diferenciais]': 'Seção Diferenciais e Processo'
    };
    Object.keys(labels).forEach(function(shortcode) { content = content.split(shortcode).join(labels[shortcode]); });
    content = content.replace(/<!--[^>]*-->/g, ' ').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    return content.length > 170 ? content.slice(0, 167) + '…' : content;
  }

  function renderPages() {
    var pages = state.data.pages || [];
    var expected = ['inicio', 'produtos', 'unidades', 'cobertura', 'blog', 'trabalhe-conosco', 'cotacao'];
    var available = expected.filter(function (slug) { return pages.some(function (page) { return page.slug === slug; }); }).length;
    var rows = pages.length ? pages.map(function (page) {
      var path = page.slug === 'inicio' ? '/' : '/' + page.slug + '/';
      var statusText = page.status === 'publish' ? 'Publicado e exibido no menu' : 'Rascunho — removido do menu público';
      return '<li class="captec-article-row captec-page-row"><span class="captec-article-row__image">' + icon('document') + '</span><div><h2>' + escapeHtml(page.title) + '</h2><p>' + escapeHtml(path) + ' · ' + statusText + '</p><p class="captec-page-content-preview"><strong>Conteúdo WordPress:</strong> ' + escapeHtml(pageContentExcerpt(page)) + '</p></div><div class="captec-article-row__actions">' + statusToggleButton(page, 'page') + button('Editar conteúdo', { className: 'captec-button--line', action: 'edit-item', icon: 'edit', attrs: ' data-content-type="page" data-id="' + page.id + '"' }) + '</div></li>';
    }).join('') : '';
    return '<div class="captec-articles-layout"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Páginas do portal</h2><p>' + available + ' de ' + expected.length + ' páginas estruturais prontas.</p></div>' + button('Criar / atualizar estrutura', { className: 'captec-button--dark', action: 'setup-pages', icon: 'plus' }) + '</div>' + (rows ? '<ul class="captec-article-list">' + rows + '</ul>' : '<div class="captec-empty"><div><span class="captec-empty__icon">' + icon('document') + '</span><h2>Estrutura ainda não criada</h2><p>Crie páginas independentes para cada item do menu com um clique.</p>' + button('Criar estrutura de páginas', { className: 'captec-button--yellow', action: 'setup-pages', icon: 'plus' }) + '</div></div>') + '</section><aside class="captec-panel"><div class="captec-content-side"><h2>Menu e conteúdo</h2><p>Quem somos concentra as seções Institucional, Aplicações, Diferenciais e Processo. O conteúdo de cada página fica salvo no WordPress e pode ser editado aqui.</p><ul class="captec-mini-list"><li><i></i>Publicado/Rascunho controla o menu público.</li><li><i></i>Editar conteúdo abre o editor da página WordPress.</li><li><i></i>Aplicações e Diferenciais foram unificadas em Quem somos.</li></ul></div></aside></div>';
  }

  function renderContent() {
    var articles = state.data.articles || [];
    var topics = state.data.suggested_topics || [];
    var rows = articles.length ? articles.map(function (article) {
      var category = (article.category_names || []).join(', ') || 'Sem categoria';
      var detail = (article.status === 'publish' ? 'Publicado em ' + formatDate(article.date) : 'Rascunho — pronto para revisão') + ' · Categoria: ' + category;
      return '<li class="captec-article-row"><span class="captec-article-row__image">' + (article.image_url ? '<img src="' + escapeAttr(article.image_url) + '" alt="">' : icon('document')) + '</span><div><h2>' + escapeHtml(article.title) + '</h2><p>' + escapeHtml(detail) + '</p></div><div class="captec-article-row__actions">' + statusToggleButton(article, 'article') + button('Editar', { className: 'captec-button--line', action: 'edit-item', icon: 'edit', attrs: ' data-content-type="article" data-id="' + article.id + '"' }) + '</div></li>';
    }).join('') : '<div class="captec-empty"><div><span class="captec-empty__icon">' + icon('document') + '</span><h2>O blog está pronto para começar</h2><p>Carregue uma pauta atual ou crie manualmente o primeiro artigo.</p>' + button('Novo artigo', { className: 'captec-button--yellow', action: 'new-item', icon: 'plus', attrs: ' data-content-type="article"' }) + '</div></div>';
    var topicsMarkup = topics.length ? topics.map(function (topic) {
      var image = topic.image_url ? '<span class="captec-topic-card__image"><img src="' + escapeAttr(topic.image_url) + '" alt=""></span>' : '<span class="captec-topic-card__image">' + icon('image') + '</span>';
      return '<li class="captec-topic-card">' + image + '<div><span>' + escapeHtml(topic.category || 'Atualização') + ' · ' + escapeHtml(topic.date || 'Atualizada') + '</span><strong>' + escapeHtml(topic.title) + '</strong><p>' + escapeHtml(topic.summary || '') + '</p></div>' + button('Carregar', { className: 'captec-button--line', action: 'generate-topic', icon: 'plus', attrs: ' data-topic-id="' + escapeAttr(topic.id) + '"' }) + '</li>';
    }).join('') : '<li class="captec-topic-card captec-topic-card--empty"><div><strong>Pautas carregadas</strong><p>As pautas utilizadas foram removidas da lista para evitar artigos duplicados.</p></div></li>';
    return '<div class="captec-articles-layout"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Artigos</h2><p>Gerencie título, categoria, conteúdo, imagem e status de publicação.</p></div>' + button('Novo artigo', { className: 'captec-button--dark', action: 'new-item', icon: 'plus', attrs: ' data-content-type="article"' }) + '</div><ul class="captec-article-list">' + rows + '</ul></section><aside class="captec-panel"><div class="captec-content-side"><h2>Pautas atuais</h2><p>Cada pauta mostra categoria e imagem relacionada. Ao carregar, o artigo recebe a categoria e a imagem destacada como rascunho.</p><ol class="captec-topic-list captec-topic-list--current">' + topicsMarkup + '</ol></div></aside></div>';
  }

  function renderBrand() {
    var logoUrl = valueOf('custom_logo_url', '');
    return '<form data-form="settings" data-settings-scope="brand"><div class="captec-editor-layout"><div class="captec-editor-stack"><section class="captec-panel captec-form-section">'
      + sectionTitle('brand', 'Marca e identidade', 'Use o arquivo oficial aprovado pela CAPTEC. A marca tipográfica do tema é apenas um fallback visual.')
      + '<input type="hidden" name="custom_logo_id" value="' + escapeAttr(valueOf('custom_logo_id', '0')) + '"><input type="hidden" name="custom_logo_url" value="' + escapeAttr(logoUrl) + '"><div class="captec-media-card"><div class="captec-media-card__preview" data-logo-preview>' + (logoUrl ? '<img src="' + escapeAttr(logoUrl) + '" alt="Logo selecionado">' : icon('image')) + '</div><div class="captec-media-card__body"><strong>Logo oficial</strong><p>Selecione uma imagem da Biblioteca de Mídia do WordPress. PNG e WebP são recomendados.</p><div class="captec-media-actions">' + button('Selecionar logo', { className: 'captec-button--line', action: 'pick-logo', icon: 'upload' }) + button('Remover', { className: 'captec-button--line', action: 'clear-logo', icon: 'close' }) + '</div></div></div><div class="captec-form-grid" style="margin-top:18px">' + textField('site_title', 'Nome do site') + textField('site_tagline', 'Descrição curta', { optional: true }) + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('phone', 'Canais comerciais', 'Os dados informados aqui alimentam cabeçalho, formulário e rodapé do portal.')
      + '<div class="captec-form-grid">' + textField('captec_phone', 'Telefone', { type: 'tel', optional: true }) + textField('captec_whatsapp', 'WhatsApp com DDI', { type: 'tel', hint: 'Ex.: 5571XXXXXXXXX. Usado nos botões de WhatsApp.' }) + textField('captec_email', 'E-mail comercial', { type: 'email' }) + textField('captec_quote_email', 'E-mail de recebimento das cotações', { type: 'email' }) + textField('captec_location_label', 'Localização exibida') + mediaUrlField('captec_maps_url', 'Link do Google Maps', { mediaType: 'none', optional: true }) + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('external', 'Presença digital', 'Links que serão exibidos no rodapé quando preenchidos.')
      + '<div class="captec-form-grid">' + mediaUrlField('captec_instagram', 'URL do Instagram', { mediaType: 'none', optional: true }) + mediaUrlField('captec_linkedin', 'URL do LinkedIn', { mediaType: 'none', optional: true }) + textField('captec_footer_text', 'Texto institucional do rodapé', { type: 'textarea', full: true, defaultValue: 'Soluções inteligentes para pavimentação e infraestrutura, com atendimento consultivo e foco em eficiência.' }) + '</div></section></div><aside class="captec-panel"><div class="captec-side-card"><h3>Dados ainda pendentes</h3><p>Campos vazios não são preenchidos com informações inventadas.</p><ul class="captec-mini-list"><li><i></i>Logo e contatos oficiais</li><li><i></i>Links de redes sociais</li><li><i></i>Localização e Google Maps</li></ul></div><div class="captec-side-card">' + settingsActionButtons('Salvar rascunho de marca') + '</div></aside></div></form>';
  }

  function appearanceRangeField(key, label, value, min, max, step, hint) {
    var unit = key.indexOf('opacity') > -1 ? '%' : 'px';
    return '<div class="captec-field"><label for="field-' + key + '">' + escapeHtml(label) + ' <small data-appearance-value="' + key + '">' + value + ' ' + unit + '</small></label><input class="captec-menu-range" data-menu-control id="field-' + key + '" name="' + key + '" type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + value + '"><div class="captec-menu-range__scale"><span>' + min + ' ' + unit + '</span><span>' + max + ' ' + unit + '</span></div>' + (hint ? '<p class="captec-field__hint">' + escapeHtml(hint) + '</p>' : '') + '</div>';
  }
  function appearanceColorField(key, label, value, hint) {
    return '<div class="captec-field"><label for="field-' + key + '">' + escapeHtml(label) + '</label><input class="captec-input captec-color-input" data-menu-control id="field-' + key + '" name="' + key + '" type="color" value="' + escapeAttr(value) + '">' + (hint ? '<p class="captec-field__hint">' + escapeHtml(hint) + '</p>' : '') + '</div>';
  }
  function appearanceSelectField(key, label, value, options) {
    var items = options.map(function(option){ return '<option value="' + escapeAttr(option.value) + '"' + (String(option.value) === String(value) ? ' selected' : '') + '>' + escapeHtml(option.label) + '</option>'; }).join('');
    return '<div class="captec-field"><label for="field-' + key + '">' + escapeHtml(label) + '</label><select class="captec-select" data-menu-control id="field-' + key + '" name="' + key + '">' + items + '</select></div>';
  }

  function renderAppearance() {
    var menuBackground = valueOf('captec_menu_background_color', '#111111');
    var menuText = valueOf('captec_menu_text_color', '#FFFFFF');
    var menuSize = Math.min(24, Math.max(10, Number(valueOf('captec_menu_font_size', '13'))));
    var menuFont = valueOf('captec_menu_font_family', 'inter');
    var menuMode = valueOf('captec_menu_mode', 'scroll');
    var menuOpacity = Math.min(100, Math.max(35, Number(valueOf('captec_menu_overlay_opacity', '92'))));
    var menuLogoSize = Math.min(320, Math.max(150, Number(valueOf('captec_menu_logo_size', '224'))));
    var footerLogoSize = Math.min(260, Math.max(90, Number(valueOf('captec_footer_logo_size', '164'))));
    var pageBackground = valueOf('captec_page_background_color', '#FFFFFF');
    var pageSurface = valueOf('captec_page_surface_color', '#F4F4F4');
    var pageBar = valueOf('captec_page_bar_color', '#111111');
    var pageBarText = valueOf('captec_page_bar_text_color', '#FFFFFF');
    var pageWidth = Math.min(1800, Math.max(960, Number(valueOf('captec_site_width', '1360'))));
    var pageGutter = Math.min(120, Math.max(16, Number(valueOf('captec_page_gutter', '80'))));
    var sectionSpacing = Math.min(190, Math.max(42, Number(valueOf('captec_section_spacing', '120'))));
    var headerHeight = Math.min(140, Math.max(64, Number(valueOf('captec_header_height', '92'))));
    var menuGap = Math.min(42, Math.max(6, Number(valueOf('captec_menu_item_gap', '22'))));
    var footerSpacing = Math.min(150, Math.max(32, Number(valueOf('captec_footer_spacing', '74'))));
    var menuPreview = '<div class="captec-menu-style-preview" data-menu-preview style="--menu-preview-bg:' + escapeAttr(menuBackground) + ';--menu-preview-ink:' + escapeAttr(menuText) + ';--menu-preview-size:' + menuSize + 'px;--menu-preview-opacity:' + (menuOpacity / 100) + '"><div class="captec-menu-style-preview__image"></div><div class="captec-menu-style-preview__bar"><strong>CAPTEC</strong><nav><span>Quem somos</span><span>Produtos</span><span>Unidades</span></nav><b>Cotação</b></div><p data-menu-preview-mode>' + (menuMode === 'scroll' ? 'Transparente no Hero; recebe sua cor ao rolar.' : menuMode === 'image' ? 'Mantém imagem de fundo com filtro na cor escolhida.' : 'Cor fixa sobre a imagem de fundo.') + '</p></div>';
    var pagePreview = '<div class="captec-appearance-preview" data-appearance-preview style="--appearance-page:' + escapeAttr(pageBackground) + ';--appearance-surface:' + escapeAttr(pageSurface) + ';--appearance-bar:' + escapeAttr(pageBar) + ';--appearance-bar-text:' + escapeAttr(pageBarText) + ';--appearance-width:' + pageWidth + 'px;--appearance-header:' + headerHeight + 'px;--appearance-footer:' + footerSpacing + 'px"><div class="captec-appearance-preview__header"><span>CAPTEC</span><i></i><i></i><i></i></div><div class="captec-appearance-preview__page"><span></span><span></span><span></span></div><div class="captec-appearance-preview__footer"><span>Rodapé</span><i></i><i></i></div></div>';
    return '<form data-form="settings" data-settings-scope="appearance"><div class="captec-editor-layout"><div class="captec-editor-stack"><section class="captec-panel captec-form-section">'
      + sectionTitle('brand', 'Cores das páginas e barras', 'Defina o fundo geral, as áreas suaves e as barras institucionais usadas nos títulos e no rodapé.')
      + pagePreview + '<div class="captec-form-grid" style="margin-top:20px">'
      + appearanceColorField('captec_page_background_color', 'Fundo das páginas', pageBackground, 'Fundo principal das páginas públicas.')
      + appearanceColorField('captec_page_surface_color', 'Fundo das áreas suaves', pageSurface, 'Fundos de blocos, mapas e seções alternadas.')
      + appearanceColorField('captec_page_bar_color', 'Cor das barras', pageBar, 'Usada nos títulos de páginas, faixas escuras e rodapé.')
      + appearanceColorField('captec_page_bar_text_color', 'Texto das barras', pageBarText, 'Mantenha contraste suficiente com a cor da barra.')
      + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('grid', 'Tamanho e espaços das páginas', 'Controle a largura do conteúdo, margens laterais e distância entre seções com limites seguros para telas responsivas.')
      + '<div class="captec-form-grid">'
      + appearanceRangeField('captec_site_width', 'Largura máxima da página', pageWidth, 960, 1800, 20, 'Aumente para páginas mais largas em telas grandes.')
      + appearanceRangeField('captec_page_gutter', 'Espaço lateral da página', pageGutter, 16, 120, 2, 'Margem segura entre o conteúdo e os cantos da tela.')
      + appearanceRangeField('captec_section_spacing', 'Espaço entre seções', sectionSpacing, 42, 190, 2, 'Respiro vertical usado nas áreas principais.')
      + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('brand', 'Cabeçalho e menu', 'Ajuste as dimensões, cores e comportamento da navegação principal.')
      + menuPreview + '<div class="captec-form-grid" style="margin-top:20px">'
      + appearanceRangeField('captec_header_height', 'Altura do cabeçalho', headerHeight, 64, 140, 2, 'Altura da barra superior do site.')
      + appearanceRangeField('captec_menu_font_size', 'Tamanho da fonte do menu', menuSize, 10, 24, 1, '')
      + appearanceRangeField('captec_menu_item_gap', 'Espaço entre itens do menu', menuGap, 6, 42, 1, '')
      + appearanceColorField('captec_menu_background_color', 'Cor de fundo do menu', menuBackground, '')
      + appearanceColorField('captec_menu_text_color', 'Cor da fonte do menu', menuText, '')
      + appearanceSelectField('captec_menu_font_family', 'Tipo de fonte do menu', menuFont, [{value:'inter',label:'Inter / corporativa'},{value:'poppins',label:'Poppins / geométrica'},{value:'system',label:'Sistema / alta performance'},{value:'serif',label:'Serifada / editorial'}])
      + appearanceSelectField('captec_menu_mode', 'Comportamento do fundo', menuMode, [{value:'scroll',label:'Transparente → cor ao rolar'},{value:'image',label:'Imagem de fundo + cor selecionada'},{value:'fixed',label:'Cor fixa sobre a imagem'}])
      + appearanceRangeField('captec_menu_overlay_opacity', 'Intensidade da cor do menu', menuOpacity, 35, 100, 1, '')
      + appearanceRangeField('captec_menu_logo_size', 'Tamanho da logo no menu', menuLogoSize, 150, 320, 2, '')
      + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('document', 'Rodapé', 'Ajuste o respiro vertical e o tamanho da logomarca. Os links e textos continuam editáveis em Rodapé.')
      + '<div class="captec-form-grid">'
      + appearanceRangeField('captec_footer_spacing', 'Espaço vertical do rodapé', footerSpacing, 32, 150, 2, 'Controla o tamanho visual da área superior do rodapé.')
      + appearanceRangeField('captec_footer_logo_size', 'Tamanho da logo no rodapé', footerLogoSize, 90, 260, 2, '')
      + '</div></section></div><aside class="captec-panel"><div class="captec-side-card"><h3>Controle visual completo</h3><p>As alterações são salvas como rascunho. Use a prévia responsiva e publique somente depois de conferir cores, contrastes e espaçamentos.</p><ul class="captec-mini-list"><li><i></i>Páginas e barras</li><li><i></i>Largura e espaços</li><li><i></i>Cabeçalho, menu e rodapé</li></ul></div><div class="captec-side-card">' + settingsActionButtons('Salvar rascunho das aparências') + '</div></aside></div></form>';
  }

  function updateMenuPreview() {
    var form = app.querySelector('[data-settings-scope="appearance"]');
    if (!form) return;
    var value = function(name, fallback) { return (form.querySelector('[name="' + name + '"]') || {}).value || fallback; };
    var menuPreview = app.querySelector('[data-menu-preview]');
    var appearancePreview = app.querySelector('[data-appearance-preview]');
    var menuBackground = value('captec_menu_background_color', '#111111');
    var menuText = value('captec_menu_text_color', '#ffffff');
    var menuSize = value('captec_menu_font_size', '13');
    var menuOpacity = value('captec_menu_overlay_opacity', '92');
    var menuMode = value('captec_menu_mode', 'scroll');
    var menuFont = value('captec_menu_font_family', 'inter');
    var pageBackground = value('captec_page_background_color', '#ffffff');
    var pageSurface = value('captec_page_surface_color', '#f4f4f4');
    var pageBar = value('captec_page_bar_color', '#111111');
    var pageBarText = value('captec_page_bar_text_color', '#ffffff');
    var stacks = { inter: 'Inter, Arial, Helvetica, sans-serif', poppins: 'Poppins, Segoe UI, Arial, sans-serif', system: '-apple-system, BlinkMacSystemFont, Segoe UI, Arial, sans-serif', serif: 'Georgia, Times New Roman, serif' };
    if (menuPreview) {
      menuPreview.style.setProperty('--menu-preview-bg', menuBackground);
      menuPreview.style.setProperty('--menu-preview-ink', menuText);
      menuPreview.style.setProperty('--menu-preview-size', menuSize + 'px');
      menuPreview.style.setProperty('--menu-preview-opacity', Number(menuOpacity) / 100);
      var previewBar = menuPreview.querySelector('.captec-menu-style-preview__bar');
      if (previewBar) previewBar.style.fontFamily = stacks[menuFont] || stacks.inter;
      var modeLabel = menuPreview.querySelector('[data-menu-preview-mode]');
      if (modeLabel) modeLabel.textContent = menuMode === 'scroll' ? 'Transparente no Hero; recebe sua cor ao rolar.' : menuMode === 'image' ? 'Mantém imagem de fundo com filtro na cor escolhida.' : 'Cor fixa sobre a imagem de fundo.';
    }
    if (appearancePreview) {
      appearancePreview.style.setProperty('--appearance-page', pageBackground);
      appearancePreview.style.setProperty('--appearance-surface', pageSurface);
      appearancePreview.style.setProperty('--appearance-bar', pageBar);
      appearancePreview.style.setProperty('--appearance-bar-text', pageBarText);
      appearancePreview.style.setProperty('--appearance-width', value('captec_site_width', '1360') + 'px');
      appearancePreview.style.setProperty('--appearance-header', value('captec_header_height', '92') + 'px');
      appearancePreview.style.setProperty('--appearance-footer', value('captec_footer_spacing', '74') + 'px');
    }
    form.querySelectorAll('[data-appearance-value]').forEach(function(label) {
      var input = form.querySelector('[name="' + label.getAttribute('data-appearance-value') + '"]');
      if (input) label.textContent = input.value + (label.getAttribute('data-appearance-value').indexOf('opacity') > -1 ? ' %' : ' px');
    });
  }

  function buttonSlotOptions() {
    return [
      {value:'header_quote',label:'Cabeçalho — Solicitar cotação'}, {value:'hero_quote',label:'Quem somos — botão principal'}, {value:'hero_whatsapp',label:'Quem somos — botão WhatsApp'}, {value:'home_institutional',label:'Quem somos — chamada institucional'}, {value:'product_quote',label:'Produtos — Solicitar cotação'}, {value:'applications_quote',label:'Quem somos — Aplicações — Solicitar cotação'}, {value:'not_found_home',label:'Página 404 — Voltar para Quem somos'}, {value:'coverage_whatsapp',label:'Cobertura — WhatsApp'}, {value:'coverage_quote',label:'Cobertura — Solicitar cotação'}, {value:'careers_email',label:'Trabalhe conosco — Enviar currículo'}, {value:'quote_submit',label:'Cotação — Enviar formulário'}, {value:'floating_whatsapp',label:'Botão flutuante — WhatsApp'}, {value:'footer_custom_1',label:'Rodapé — botão adicional 1'}, {value:'footer_custom_2',label:'Rodapé — botão adicional 2'}, {value:'footer_custom_3',label:'Rodapé — botão adicional 3'}
    ];
  }
  function nextButtonSlot() {
    var used = (state.data.buttons || []).map(function(item){ return item.slot; });
    var open = buttonSlotOptions().filter(function(item){ return used.indexOf(item.value) === -1; })[0];
    return open ? open.value : 'header_quote';
  }
  function footerSectionOptions() { return [{value:'navigation',label:'Navegação'}, {value:'atendimento',label:'Atendimento'}, {value:'institucional',label:'Institucional'}, {value:'bottom',label:'Rodapé inferior'}]; }
  function buttonSlotLabel(slot) { var item = buttonSlotOptions().filter(function(entry){ return entry.value === slot; })[0]; return item ? item.label : 'Área não definida'; }
  function footerSectionLabel(section) { var item = footerSectionOptions().filter(function(entry){ return entry.value === section; })[0]; return item ? item.label : 'Rodapé'; }
  function destinationLabel(action) { return {quote:'Solicitar cotação',whatsapp:'WhatsApp',career_email:'E-mail de currículos',home:'Página Quem somos',phone:'Telefone',email:'E-mail comercial',privacy:'Política de Privacidade',cookies:'Política de Cookies',maps:'Google Maps',url:'URL personalizada'}[action] || 'URL personalizada'; }
  function managerRow(item, type) {
    var detail = type === 'button' ? buttonSlotLabel(item.slot) + ' · ' + destinationLabel(item.action) + ' · ' + ({left:'Esquerda',center:'Centro',right:'Direita',default:'Padrão'}[item.position] || 'Padrão') : type === 'footer_item' ? footerSectionLabel(item.section) + ' · ' + (item.kind === 'text' ? 'Texto simples' : destinationLabel(item.action)) : (item.label || item.title) + (item.value ? ' · ' + item.value : ' · Valor não informado');
    var iconName = type === 'button' ? 'settings' : type === 'footer_item' ? 'document' : 'chart';
    return '<li class="captec-article-row captec-control-row"><span class="captec-article-row__image">' + icon(iconName) + '</span><div><h2>' + escapeHtml(item.title) + '</h2><p>' + escapeHtml(detail) + '</p></div><div class="captec-article-row__actions">' + statusToggleButton(item, type) + button('Editar', { className: 'captec-button--line', action: 'edit-item', icon: 'edit', attrs: ' data-content-type="' + type + '" data-id="' + item.id + '"' }) + button('Excluir', { className: 'captec-button--danger', action: 'delete-item', icon: 'trash', attrs: ' data-content-type="' + type + '" data-id="' + item.id + '" data-item-title="' + escapeAttr(item.title) + '"' }) + '</div></li>';
  }
  function renderButtons() {
    var items = state.data.buttons || [];
    var rows = items.length ? items.map(function(item){ return managerRow(item, 'button'); }).join('') : '<div class="captec-empty"><div><span class="captec-empty__icon">' + icon('settings') + '</span><h2>Nenhum botão configurado</h2><p>Crie o primeiro botão e selecione a área pública onde ele deve aparecer.</p>' + button('Novo botão', { className:'captec-button--yellow',action:'new-item',icon:'plus',attrs:' data-content-type="button"' }) + '</div></div>';
    return '<div class="captec-articles-layout"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Botões públicos</h2><p>Os botões possuem nome, texto, destino, estilo, posição e status próprios.</p></div>' + button('Novo botão', {className:'captec-button--dark',action:'new-item',icon:'plus',attrs:' data-content-type="button"'}) + '</div><ul class="captec-article-list">' + rows + '</ul></section><aside class="captec-panel"><div class="captec-content-side"><h2>Controle por área</h2><p>Edite os botões de Quem somos, Produtos, Cobertura, Trabalhe conosco, Cotação e cabeçalho em um único local.</p><ul class="captec-mini-list"><li><i></i>Publicado: aparece no site.</li><li><i></i>Rascunho: aparece apenas na prévia administrativa.</li><li><i></i>Excluir: remove o botão da área selecionada.</li></ul></div></aside></div>';
  }
  function renderFooterManager() {
    var items = state.data.footer_items || [];
    var rows = items.length ? items.map(function(item){ return managerRow(item, 'footer_item'); }).join('') : '<div class="captec-empty"><div><span class="captec-empty__icon">' + icon('document') + '</span><h2>Nenhum item no rodapé</h2><p>Crie um link ou texto e escolha a coluna do rodapé.</p>' + button('Novo item do rodapé', {className:'captec-button--yellow',action:'new-item',icon:'plus',attrs:' data-content-type="footer_item"'}) + '</div></div>';
    return '<div class="captec-articles-layout"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Informações do rodapé</h2><p>Controle links, informações e status de cada item do rodapé.</p></div>' + button('Novo item do rodapé', {className:'captec-button--dark',action:'new-item',icon:'plus',attrs:' data-content-type="footer_item"'}) + '</div><ul class="captec-article-list">' + rows + '</ul></section><aside class="captec-panel"><div class="captec-content-side"><h2>Colunas disponíveis</h2><p>Escolha Navegação, Atendimento, Institucional ou Rodapé inferior. Marca, contatos e texto institucional continuam em Marca e contatos.</p><ul class="captec-mini-list"><li><i></i>Links e textos editáveis</li><li><i></i>Status Publicado / Rascunho</li><li><i></i>Exclusão sem apagar os dados de marca</li></ul></div></aside></div>';
  }

  function renderCoverage() {
    var stats = state.data.stats || [];
    var statsRows = stats.length ? stats.map(function(stat){ return managerRow(stat, 'stat'); }).join('') : '<div class="captec-empty captec-empty--compact"><div><span class="captec-empty__icon">' + icon('chart') + '</span><h2>Nenhum indicador criado</h2><p>Inclua somente dados aprovados pela empresa.</p>' + button('Novo indicador', { className:'captec-button--yellow', action:'new-item', icon:'plus', attrs:' data-content-type="stat"' }) + '</div></div>';
    return '<form data-form="settings" data-settings-scope="coverage"><div class="captec-editor-layout"><div class="captec-editor-stack"><section class="captec-panel captec-form-section">'
      + sectionTitle('chart', 'Indicadores institucionais', 'Crie, edite, publique, deixe em rascunho ou exclua cada indicador sem alterar código.')
      + '<div class="captec-inline-manager"><div class="captec-inline-manager__head"><p>Os valores só aparecem no site quando o indicador estiver publicado.</p>' + button('Novo indicador', { className:'captec-button--line', action:'new-item', icon:'plus', attrs:' data-content-type="stat"' }) + '</div><ul class="captec-article-list captec-article-list--compact">' + statsRows + '</ul></div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('map', 'Mapa de cobertura', 'Estados configurados permanecem destacados mesmo após o clique. Ajuste também a mensagem exibida após selecionar um estado.')
      + '<div class="captec-map-editor"><p class="captec-map-editor__eyebrow">Cobertura comercial</p><h3>Estados configuráveis conforme a operação.</h3><p>Separe as siglas por vírgula. Ex.: BA, SE, AL.</p><input class="captec-input" name="captec_active_states" value="' + escapeAttr(valueOf('captec_active_states', '')) + '" placeholder="BA, SE, AL"></div><div class="captec-form-grid" style="margin-top:16px">' + textField('captec_map_status_message', 'Mensagem após selecionar um estado', { defaultValue:'disponível para atendimento', full:true, hint:'O nome do estado é incluído automaticamente. Ex.: Mato Grosso: disponível para atendimento.' }) + '</div></section></div><aside class="captec-panel"><div class="captec-side-card"><h3>Mapa e indicadores</h3><ul class="captec-mini-list"><li><i></i>Estados destacados não perdem a cor ao clicar.</li><li><i></i>A mensagem de disponibilidade é editável.</li><li><i></i>Use os botões do site para editar WhatsApp e Cotação da cobertura.</li></ul></div><div class="captec-side-card">' + settingsActionButtons('Salvar rascunho de cobertura') + '</div></aside></div></form>';
  }

  function formatNumber(value) {
    try { return new Intl.NumberFormat('pt-BR').format(Number(value || 0)); } catch (e) { return String(value || 0); }
  }

  function formatSeconds(value) {
    var seconds = Math.max(0, Number(value || 0));
    var minutes = Math.floor(seconds / 60);
    var rest = Math.round(seconds % 60);
    return minutes ? minutes + ' min ' + rest + ' s' : rest + ' s';
  }

  function analyticsRows(rows, nameKey, valueKey, extra) {
    rows = rows || [];
    var max = Math.max.apply(null, rows.map(function (item) { return Number(item[valueKey] || 0); }).concat([1]));
    return rows.map(function (item, index) {
      var value = Number(item[valueKey] || 0);
      var label = item[nameKey] || '(não informado)';
      return '<div class="captec-analytics-row"><span class="captec-analytics-rank">' + String(index + 1).padStart(2, '0') + '</span><span class="captec-analytics-name" title="' + escapeAttr(label) + '">' + escapeHtml(label) + '</span><span class="captec-analytics-bar"><i style="width:' + Math.max(4, Math.round((value / max) * 100)) + '%"></i></span><strong>' + formatNumber(value) + '</strong>' + (extra ? '<small>' + escapeHtml(extra(item)) + '</small>' : '') + '</div>';
    }).join('') || '<p class="captec-analytics-empty">Ainda não há dados para o período selecionado.</p>';
  }

  function trafficDashboardUrl() {
    var base = (state.data && state.data.admin_url) || config.adminUrl || '/wp-admin/';
    return base.replace(/\/?$/, '/') + 'admin.php?page=captec-traffic';
  }

  function renderAnalyticsConfig(notice) {
    var settings = state.data.analytics || { property_id: '', configured: false, credential_present: false };
    return '<div class="captec-analytics-layout"><section class="captec-panel captec-form-section"><div class="captec-form-section__title">' + icon('chart') + '<div><h2>Conectar ao Google Analytics 4</h2><p>Configure uma conta de serviço somente para leitura para consultar dados reais do portal.</p></div></div>' + (notice ? '<div class="captec-theme-warning">' + icon('info') + '<div><strong>Conexão pendente</strong>' + escapeHtml(notice) + '</div></div>' : '') + '<form data-form="analytics"><div class="captec-form-grid">' + textField('property_id', 'ID numérico da propriedade GA4', { value: settings.property_id || '', placeholder: 'Ex.: 123456789', full: true, hint: 'Não é o ID de medição G-XXXXXXXX. Encontre-o em Administrador > Detalhes da propriedade.' }) + textField('service_account_json', settings.credential_present ? 'Novo JSON da conta de serviço (opcional)' : 'JSON da conta de serviço Google', { value: '', type: 'textarea', full: true, editor: true, placeholder: settings.credential_present ? 'Deixe em branco para manter a conta já conectada.' : 'Cole aqui o conteúdo completo do arquivo JSON baixado no Google Cloud.', hint: 'A conta de serviço precisa ter acesso de leitura à propriedade GA4 e a API Google Analytics Data deve estar ativada.' }) + '</div><div class="captec-analytics-setup"><a class="captec-button captec-button--line" href="' + escapeAttr(trafficDashboardUrl()) + '">' + icon('chart') + ' Dashboard de tráfego local</a>' + button('Salvar e consultar dados', { className: 'captec-button--yellow', type: 'submit', icon: 'check' }) + '</div></form></section><aside class="captec-panel"><div class="captec-content-side"><h2>Passo a passo simples</h2><ol class="captec-topic-list"><li>Crie uma conta de serviço no Google Cloud.</li><li>Ative a Google Analytics Data API.</li><li>Adicione o e-mail da conta como leitor na propriedade GA4.</li><li>Baixe o JSON e cole-o aqui.</li></ol><p class="captec-analytics-side-note">As credenciais são usadas somente pelo servidor WordPress para consultas de leitura. Nenhum dado é exibido até a conexão ser configurada.</p></div></aside></div>';
  }

  function analyticsFilterMarkup(report) {
    var filters = state.analyticsFilters || { period: 'year', start: '', end: '' };
    var period = filters.period || 'year';
    var selected = function (value) { return period === value ? ' selected' : ''; };
    var range = report && report.range ? report.range : null;
    return '<form class="captec-analytics-filter" data-form="analytics-filter"><span class="captec-analytics-filter__label">Período detalhado</span><select class="captec-select" name="period" data-analytics-filter-control><option value="today"' + selected('today') + '>Hoje</option><option value="7days"' + selected('7days') + '>Últimos 7 dias</option><option value="30days"' + selected('30days') + '>Últimos 30 dias</option><option value="month"' + selected('month') + '>Este mês</option><option value="year"' + selected('year') + '>Este ano</option><option value="custom"' + selected('custom') + '>Intervalo personalizado</option></select>' + (period === 'custom' ? '<input class="captec-input" name="start" data-analytics-filter-control type="date" value="' + escapeAttr(filters.start || '') + '" required><input class="captec-input" name="end" data-analytics-filter-control type="date" value="' + escapeAttr(filters.end || '') + '" required>' : '') + '<button class="captec-button captec-button--line" type="submit">' + icon('refresh') + ' Aplicar</button>' + (range ? '<small>Dados detalhados: ' + escapeHtml(range.label || '') + '</small>' : '') + '</form>';
  }

  function trafficFilterMarkup(report) {
    var filters = state.trafficFilters || { period: '30days', start: '', end: '' };
    var period = filters.period || '30days';
    var opts = [{value:'today',label:'Hoje'},{value:'7days',label:'Últimos 7 dias'},{value:'30days',label:'Últimos 30 dias'},{value:'90days',label:'Últimos 90 dias'},{value:'year',label:'Este ano'},{value:'custom',label:'Intervalo personalizado'}].map(function(item){return '<option value="'+item.value+'"'+(item.value===period?' selected':'')+'>'+item.label+'</option>';}).join('');
    return '<form class="captec-analytics-filter" data-form="traffic-filter"><span class="captec-analytics-filter__label">Período</span><select class="captec-select" name="period" data-traffic-filter-control>'+opts+'</select>'+(period==='custom'?'<input class="captec-input" name="start" data-traffic-filter-control type="date" value="'+escapeAttr(filters.start||'')+'" required><input class="captec-input" name="end" data-traffic-filter-control type="date" value="'+escapeAttr(filters.end||'')+'" required>':'')+'<button class="captec-button captec-button--line" type="submit">'+icon('refresh')+' Aplicar</button>'+(report&&report.range?'<small>'+escapeHtml(report.range.label||'')+'</small>':'')+'</form>';
  }

  function trafficListRows(rows, labelKey, valueKey, extra) {
    rows = rows || [];
    var max = Math.max.apply(null, rows.map(function(item){return Number(item[valueKey] || 0);}).concat([1]));
    if (!rows.length) return '<p class="captec-analytics-empty">Ainda não há dados. Navegue pelo site após aceitar os cookies analíticos.</p>';
    return rows.slice(0, 12).map(function(item,index){var value=Number(item[valueKey]||0);return '<div class="captec-analytics-row"><span class="captec-analytics-rank">'+String(index+1).padStart(2,'0')+'</span><span class="captec-analytics-name" title="'+escapeAttr(item[labelKey]||'')+'">'+escapeHtml(item[labelKey]||'(não informado)')+'</span><span class="captec-analytics-bar"><i style="width:'+Math.max(4,Math.round(value/max*100))+'%"></i></span><strong>'+formatNumber(value)+'</strong>'+(extra?'<small>'+escapeHtml(extra(item))+'</small>':'')+'</div>';}).join('');
  }

  function renderAnalytics() {
    if (state.trafficLoading) return '<div class="captec-analytics-loading"><span class="captec-skeleton"></span><span class="captec-skeleton"></span><span class="captec-skeleton"></span><p>Carregando dados de tráfego…</p></div>';
    if (state.trafficError) return '<section class="captec-panel"><div class="captec-panel__body"><div class="captec-theme-warning">'+icon('info')+'<div><strong>Tráfego CAPTEC indisponível</strong>'+escapeHtml(state.trafficError)+'</div></div>'+trafficFilterMarkup(null)+'</div></section>';
    var report = state.trafficReport;
    if (!report) return '<section class="captec-panel"><div class="captec-panel__body"><div class="captec-empty"><div><span class="captec-empty__icon">'+icon('chart')+'</span><h2>Dashboard de tráfego pronto</h2><p>O plugin registra visualizações, cliques e permanência depois que visitantes aceitam cookies analíticos.</p>'+button('Carregar tráfego', {className:'captec-button--yellow',action:'refresh-traffic',icon:'refresh'})+'</div></div></div></section>';
    var summary = report.summary || {}, health = state.trafficHealth || {}, pages = report.pages || [];
    var metrics = [
      {label:'Visualizações',value:summary.pageviews||0,icon:'chart'},
      {label:'Sessões únicas',value:summary.sessions||0,icon:'grid'},
      {label:'Cliques registrados',value:summary.clicks||0,icon:'arrow'},
      {label:'Permanência média',value:formatSeconds(summary.average_seconds||0),icon:'clock',plain:true}
    ].map(function(metric){return '<article class="captec-metric captec-metric--analytics"><span class="captec-metric__icon">'+icon(metric.icon)+'</span><strong class="captec-metric__value'+(metric.plain?' captec-metric__value--hour':'')+'">'+(metric.plain?escapeHtml(metric.value):formatNumber(metric.value))+'</strong><span class="captec-metric__label">'+escapeHtml(metric.label)+'</span></article>';}).join('');
    var clickRows=(report.clicks||[]).map(function(item){return {label:(item.element_label||'Clique')+' — '+(item.page_path||''),total:item.total};});
    var refRows=(report.referrers||[]).map(function(item){return {label:item.referrer_host,total:item.total};});
    var dateRows=(report.days||[]).map(function(item){return {label:item.date,total:item.views};});
    return '<div class="captec-analytics-toolbar"><span>'+(health.events!=null?'Eventos registrados: '+formatNumber(health.events):'Dashboard de tráfego local')+'</span>'+trafficFilterMarkup(report)+'</div><div class="captec-dashboard-grid captec-dashboard-grid--analytics">'+metrics+'</div><div class="captec-analytics-columns"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Páginas mais acessadas</h2><p>Visualizações, cliques e tempo médio por página.</p></div></div><div class="captec-analytics-list">'+trafficListRows(pages.map(function(item){return {label:item.page_title||item.page_path,total:item.views,average_seconds:item.average_seconds,clicks:item.clicks};}),'label','total',function(item){return 'Cliques: '+formatNumber(item.clicks)+' · Média: '+formatSeconds(item.average_seconds);})+'</div></section><section class="captec-panel"><div class="captec-panel__head"><div><h2>Elementos mais clicados</h2><p>Links e botões com maior interação.</p></div></div><div class="captec-analytics-list">'+trafficListRows(clickRows,'label','total')+'</div></section></div><div class="captec-analytics-geo"><section class="captec-panel"><div class="captec-panel__head"><div><h2>Atividade por dia</h2><p>Visualizações registradas no período.</p></div></div><div class="captec-analytics-list">'+trafficListRows(dateRows,'label','total')+'</div></section><section class="captec-panel"><div class="captec-panel__head"><div><h2>Origem dos acessos</h2><p>Principais domínios de referência.</p></div></div><div class="captec-analytics-list">'+trafficListRows(refRows,'label','total')+'</div></section><section class="captec-panel"><div class="captec-panel__head"><div><h2>Diagnóstico da coleta</h2><p>'+escapeHtml(health.consent_note||'A coleta começa após consentimento analítico.')+'</p></div></div><div class="captec-panel__body"><div class="captec-status-stack"><div class="captec-status-card"><span class="captec-status-card__icon">'+icon('check')+'</span><div><strong>'+(health.table_ready?'Banco de dados pronto':'Verificando banco de dados')+'</strong><span>'+formatNumber(health.events||0)+' eventos armazenados.</span></div></div><div class="captec-status-card"><span class="captec-status-card__icon">'+icon('clock')+'</span><div><strong>Última coleta</strong><span>'+escapeHtml(health.last_event?formatDateTime(health.last_event):'Ainda não há eventos. Aceite cookies e navegue pelo site.')+'</span></div></div></div></div></section></div>';
  }

  function formatDateTime(value) {
    if (!value) return '—';
    try { return new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(new Date(value.replace(' ', 'T') + (value.indexOf('Z') === -1 ? 'Z' : ''))); }
    catch (e) { return value; }
  }

  function renderActivity() {
    if (state.activityLoading) return '<div class="captec-analytics-loading"><span class="captec-skeleton"></span><span class="captec-skeleton"></span><span class="captec-skeleton"></span><p>Carregando histórico de atividades…</p></div>';
    var logs = state.activityLogs || [];
    var options = [7,30,90,180].map(function(days){return '<option value="'+days+'"'+(Number(state.activityDays)===days?' selected':'')+'>'+days+' dias</option>';}).join('');
    var rows = logs.length ? logs.map(function(log){return '<tr><td><strong>' + escapeHtml(log.description || log.action_key || 'Atividade registrada') + '</strong><small>' + escapeHtml((log.object_type || 'portal') + (log.object_id ? ' #' + log.object_id : '')) + '</small></td><td>' + escapeHtml(log.display_name || 'Sistema') + '</td><td>' + escapeHtml(formatDateTime(log.created_at)) + '</td></tr>';}).join('') : '<tr><td colspan="3" class="captec-log-empty">Nenhuma atividade encontrada para este período.</td></tr>';
    var diagnostic = state.activityError ? '<div class="captec-theme-warning">' + icon('info') + '<div><strong>Diagnóstico de registro</strong>' + escapeHtml(state.activityError) + '</div></div>' : '';
    return diagnostic + '<section class="captec-panel"><div class="captec-panel__head"><div><h2>Histórico operacional</h2><p>As atividades ficam armazenadas por até seis meses e identificam a pessoa usuária que executou a ação.</p></div><form class="captec-log-filter" data-form="activity-filter"><label>Exibir<select class="captec-select" name="days">'+options+'</select></label><button class="captec-button captec-button--line" type="submit">'+icon('refresh')+' Atualizar</button></form></div><div class="captec-log-table-wrap"><table class="captec-log-table"><thead><tr><th>Atividade</th><th>Usuário</th><th>Data e hora</th></tr></thead><tbody>'+rows+'</tbody></table></div></section><div class="captec-activity-note">'+icon('info')+'<span>O log registra ações realizadas pelo Portal CAPTEC e pelo Agente IA. Credenciais, senhas e conteúdo sensível não são armazenados no histórico.</span></div>';
  }

  function featurePreviewInfo(key) {
    var data = {
      hero_video: { title: 'Vídeo do Hero', text: 'Controla o vídeo de fundo da primeira tela. Quando inativo, a imagem de fallback permanece visível.', visual: 'hero' },
      products: { title: 'Vitrine de produtos', text: 'Mostra ou oculta a vitrine na página Produtos. O catálogo continua preservado no painel.', visual: 'products' },
      applications: { title: 'Aplicações', text: 'Mostra ou oculta a seção Aplicações dentro de Quem somos, sem apagar os cards cadastrados.', visual: 'applications' },
      differentials: { title: 'Diferenciais', text: 'Mostra ou oculta os seis cards de diferenciais da página Quem somos.', visual: 'differentials' },
      process: { title: 'Processo comercial', text: 'Mostra ou oculta a linha do tempo integrada à página Quem somos.', visual: 'process' },
      stats: { title: 'Indicadores', text: 'Mostra ou oculta o quadro de números institucionais. Os valores ficam preservados no painel.', visual: 'stats' },
      map: { title: 'Mapa de cobertura', text: 'Mostra ou oculta o quadro do mapa do Brasil e a mensagem de disponibilidade.', visual: 'map' },
      locations: { title: 'Matriz e filiais', text: 'Mostra ou oculta a página de Matriz e filiais, sem apagar as unidades cadastradas.', visual: 'locations' },
      blog: { title: 'Conteúdos', text: 'Mostra ou oculta a página Conteúdos. Os artigos publicados permanecem preservados.', visual: 'blog' },
      quote: { title: 'Formulário de cotação', text: 'Mostra ou oculta a página Solicitar Cotação, sem apagar as solicitações já recebidas.', visual: 'quote' },
      whatsapp: { title: 'Botão de WhatsApp', text: 'Mostra ou oculta o botão flutuante. Não altera os links de WhatsApp presentes em outras áreas.', visual: 'whatsapp' },
      maintenance: { title: 'Modo de manutenção', text: 'Substitui temporariamente o site público por uma mensagem de manutenção. Administradores continuam com acesso.', visual: 'maintenance' }
    };
    return data[key] || { title: 'Funcionalidade', text: 'Pré-visualização da funcionalidade selecionada.', visual: 'generic' };
  }

  function featurePreviewPage(key) {
    var map = { hero_video:'inicio', products:'produtos', applications:'inicio', differentials:'inicio', process:'inicio', stats:'cobertura', map:'cobertura', locations:'unidades', blog:'blog', quote:'cotacao', whatsapp:'cotacao', maintenance:'inicio' };
    var slug = map[key] || 'inicio';
    return previewPages().filter(function(page){ return page.slug === slug; })[0] || previewPages()[0];
  }
  function openFeaturePreview(key) {
    var info = featurePreviewInfo(key);
    var page = featurePreviewPage(key);
    var url = portalPreviewUrl(page);
    var root = app.querySelector('[data-modal-root]');
    if (!root) return;
    root.innerHTML = '<div class="captec-modal-backdrop is-open" data-modal-backdrop><div class="captec-modal captec-feature-preview-modal" role="dialog" aria-modal="true" aria-labelledby="captec-feature-preview-title"><header class="captec-modal__head"><div><h2 id="captec-feature-preview-title">Visualização: ' + escapeHtml(info.title) + '</h2><p>Página atual: ' + escapeHtml(page.title) + '. Esta visualização usa o estado atual do portal.</p></div><button class="captec-modal__close" type="button" data-action="close-modal" aria-label="Fechar">' + icon('close') + '</button></header><div class="captec-feature-page-preview"><div class="captec-feature-page-preview__bar"><span>' + icon('external') + escapeHtml(url.replace(/\?.*/, '')) + '</span>' + button('Abrir página', {className:'captec-button--line', action:'open-feature-preview-page', icon:'external', attrs:' data-preview-url="' + escapeAttr(url) + '"'}) + '</div><iframe title="Visualização de ' + escapeAttr(info.title) + '" src="' + escapeAttr(url) + '"></iframe></div></div></div>';
  }
  function renderFeatures() {
    var features = state.data.features || { items: [], maintenance: false, message: '' };
    var rows = (features.items || []).map(function (feature) {
      return '<div class="captec-feature-row"><label class="captec-feature-row__control"><input type="checkbox" name="feature_' + escapeAttr(feature.key) + '" value="1"' + (feature.enabled ? ' checked' : '') + '><span class="captec-feature-toggle"><i></i></span><span><strong>' + escapeHtml(feature.label) + '</strong><small>' + (feature.enabled ? 'Ativa no portal público' : 'Inativa no portal público') + '</small></span></label>' + button('Visualizar', { className:'captec-button--line', action:'preview-feature', icon:'external', attrs:' data-feature-key="' + escapeAttr(feature.key) + '"' }) + '</div>';
    }).join('');
    return '<form data-form="features"><div class="captec-editor-layout"><div class="captec-editor-stack"><section class="captec-panel captec-form-section">'
      + sectionTitle('power', 'Funcionalidades do portal', 'Use Visualizar para abrir um pop-up com a página atual relacionada à funcionalidade.')
      + '<div class="captec-feature-list">' + rows + '</div></section><section class="captec-panel captec-form-section">'
      + sectionTitle('power', 'Modo de manutenção', 'Quando ativado, visitantes veem uma página de manutenção. Administradores continuam acessando o site e o painel.')
      + '<div class="captec-feature-row captec-feature-row--maintenance"><label class="captec-feature-row__control"><input type="checkbox" name="maintenance" value="1"' + (features.maintenance ? ' checked' : '') + '><span class="captec-feature-toggle"><i></i></span><span><strong>Ativar modo de manutenção</strong><small>' + (features.maintenance ? 'O site público está em manutenção.' : 'O site público está disponível.') + '</small></span></label>' + button('Visualizar', {className:'captec-button--line',action:'preview-feature',icon:'external',attrs:' data-feature-key="maintenance"'}) + '</div>'
      + textField('maintenance_message', 'Mensagem exibida durante a manutenção', { type: 'textarea', value: features.message, full: true, hint: 'Use uma mensagem curta e objetiva. Administradores não veem a tela de manutenção.' })
      + '</section></div><aside class="captec-panel"><div class="captec-side-card"><h3>Controle seguro</h3><p>Inativar uma funcionalidade não apaga produtos, páginas, conteúdos ou cotações. Use Visualizar para conferir a página antes de salvar.</p></div><div class="captec-side-card">' + button('Salvar funcionalidades', { className: 'captec-button--yellow', type: 'submit', icon: 'check' }) + '</div></aside></div></form>';
  }

  function renderAssistant() {
    var ai = state.data.ai || { name: 'Nina CAPTEC', avatar_url: '', greeting: '' };
    var name = ai.name || 'Nina CAPTEC';
    var greeting = agentGreeting(ai, name);
    var avatar = ai.avatar_url ? '<img src="' + escapeAttr(ai.avatar_url) + '" alt="' + escapeAttr(name) + '">' : icon('assistant');
    return '<div class="captec-ai-layout"><section class="captec-panel"><div class="captec-ai-hero"><div class="captec-ai-avatar" data-ai-avatar>' + avatar + '</div><div><p class="captec-kicker">Layout do assistente</p><h2>' + escapeHtml(name) + '</h2><p>O assistente fica no canto inferior direito do Portal CAPTEC e está disponível em qualquer tela.</p></div></div><div class="captec-ai-chat"><h3 class="captec-ai-layout-title">Como o agente funciona</h3><div class="captec-ai-empty">' + icon('assistant') + '<p>Ele orienta tarefas do portal, recebe comandos por voz ou texto, mostra uma prévia e só executa ações depois da sua autorização. Caso não compreenda uma pergunta, orienta a entrar em contato com o Administrador do site.</p></div><div class="captec-ai-layout-preview"><div class="captec-ai-layout-preview__avatar">' + avatar + '</div><div><span>Prévia da janela flutuante</span><strong>' + escapeHtml(name) + '</strong><small>Assistente IA · canto inferior direito</small></div></div></div></section><aside class="captec-panel"><form data-form="ai-settings" class="captec-side-card"><h3>Configuração de layout</h3><p>Defina apenas o nome e a imagem que serão apresentados para a equipe.</p><input type="hidden" name="avatar_id" value="' + Number(ai.avatar_id || 0) + '"><div class="captec-ai-profile-image" data-ai-profile-image>' + avatar + '</div><div class="captec-media-actions">' + button('Selecionar imagem', { className: 'captec-button--line', action: 'pick-ai-avatar', icon: 'upload' }) + button('Remover', { className: 'captec-button--line', action: 'clear-ai-avatar', icon: 'close' }) + '</div><div style="margin-top:15px">' + textField('name', 'Nome do agente', { value: name }) + textField('greeting', 'Mensagem de saudação', { value: ai.greeting || 'Oi! Meu nome é {nome}, seu assistente virtual!\n\nComo posso te ajudar?', type: 'textarea', full: true, hint: 'Use {nome} para inserir automaticamente o nome cadastrado.' }) + '</div>' + button('Salvar layout do agente', { className: 'captec-button--yellow', type: 'submit', icon: 'check' }) + '</form></aside></div>';
  }

  function renderIntegrations() {
    return '<form data-form="settings" data-settings-scope="integrations"><div class="captec-integration-grid"><section class="captec-integration-card">'
      + '<span class="captec-integration-card__icon">' + icon('chart') + '</span><h2>Google Analytics 4</h2><p>As métricas são carregadas somente depois que a pessoa aceita cookies analíticos.</p>'
      + textField('captec_ga4_id', 'ID de medição', { placeholder: 'G-XXXXXXXXXX', optional: true })
      + '</section><section class="captec-integration-card"><span class="captec-integration-card__icon">' + icon('chart') + '</span><h2>Meta Pixel</h2><p>Informe apenas o ID numérico. O Pixel também respeita a escolha de consentimento.</p>'
      + textField('captec_meta_pixel_id', 'ID do Pixel', { placeholder: '000000000000000', optional: true })
      + '</section></div><div class="captec-editor-layout" style="margin-top:16px"><section class="captec-panel captec-form-section">'
      + sectionTitle('brand', 'Privacidade e consentimento', 'Os links aparecem no rodapé, no formulário de cotação e no banner de cookies.')
      + '<div class="captec-form-grid">' + mediaUrlField('captec_privacy_url', 'URL da Política de Privacidade', { mediaType: 'none', full: true }) + mediaUrlField('captec_cookie_url', 'URL da Política de Cookies', { mediaType: 'none', full: true }) + '</div><div class="captec-privacy-note">' + icon('info') + '<span>Revise as políticas com a área jurídica antes de publicá-las. O painel oferece os campos e o bloqueio técnico das integrações opcionais; a redação legal deve ser validada pela empresa.</span></div></section><aside class="captec-panel"><div class="captec-side-card"><h3>Proteção de dados</h3><p>O formulário de cotação registra consentimento e mantém as solicitações privadas no WordPress. Defina internamente o prazo de retenção dos dados.</p></div><div class="captec-side-card">' + settingsActionButtons('Salvar rascunho de integrações') + '</div></aside></div></form>';
  }

  function itemCollectionKey(type) {
    return type === 'product' ? 'products' : type === 'application' ? 'applications' : type === 'location' ? 'locations' : type === 'page' ? 'pages' : type === 'button' ? 'buttons' : type === 'footer_item' ? 'footer_items' : type === 'stat' ? 'stats' : 'articles';
  }
  function categoryOptions() {
    var options = [{value:'0',label:'Sem categoria'}];
    (state.data.categories || []).forEach(function(category){ options.push({value:String(category.id),label:category.name}); });
    return options;
  }
  function itemDefaults(type) {
    if (type === 'product') return { type: type, id: 0, title: '', product_type: 'Produto asfáltico', description: '', applications: '', file_url: '', status: 'publish', order: (state.data.products || []).length, image_id: 0, image_url: '' };
    if (type === 'application') return { type: type, id: 0, title: '', subtitle: '', content: '', status: 'publish', order: (state.data.applications || []).length, image_id: 0, image_url: '' };
    if (type === 'location') return { type: type, id: 0, title: '', kind: 'branch', company_name: 'CAPTEC ASFALTOS LTDA', cnpj: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '', cep: '', phone: '', email: '', map_url: '', status: 'publish', order: (state.data.locations || []).length, image_id: 0, image_url: '' };
    if (type === 'page') return { type: type, id: 0, title: '', slug: '', content: '', status: 'draft', order: (state.data.pages || []).length, image_id: 0, image_url: '' };
    if (type === 'button') return { type:type, id:0, title:'', slot:nextButtonSlot(), label:'', action:'quote', url:'', style:'yellow', target:'same', position:'default', status:'publish', order:(state.data.buttons || []).length, image_id:0, image_url:'' };
    if (type === 'footer_item') return { type:type, id:0, title:'', section:'navigation', label:'', kind:'link', action:'url', url:'', target:'same', status:'publish', order:(state.data.footer_items || []).length, image_id:0, image_url:'' };
    if (type === 'stat') return { type:type, id:0, title:'', label:'', value:'', status:'draft', order:(state.data.stats || []).length, image_id:0, image_url:'' };
    return { type: 'article', id: 0, title: '', excerpt: '', content: '', category_id: 0, category_name: '', status: 'draft', image_id: 0, image_url: '' };
  }
  function findItem(type, id) {
    var collection = state.data[itemCollectionKey(type)] || [];
    return collection.filter(function (item) { return Number(item.id) === Number(id); })[0];
  }

  function openItemModal(type, item) {
    item = Object.assign({}, itemDefaults(type), item || {});
    state.modal = { type: type, item: item };
    var labels = { product: 'produto', application: 'aplicação', location: 'unidade', page: 'página', article: 'artigo', button: 'botão', footer_item: 'item do rodapé', stat: 'indicador' };
    var title = item.id ? 'Editar ' + labels[type] : 'Novo ' + labels[type];
    var detail = type === 'product' ? 'Informações exibidas no card de produtos.' : type === 'application' ? 'Defina o contexto e uma imagem horizontal para o card.' : type === 'location' ? 'Dados institucionais, cadastrais e de contato da matriz ou filial.' : type === 'page' ? 'Página WordPress independente. O conteúdo deste formulário é salvo no WordPress. Publicado aparece no menu; Rascunho remove o item do menu público.' : type === 'button' ? 'Controle texto, destino, estilo e status do botão na área escolhida.' : type === 'footer_item' ? 'Controle uma informação ou link nas colunas do rodapé.' : type === 'stat' ? 'Informe somente um indicador institucional já validado.' : 'Crie conteúdo editorial, escolha ou crie uma categoria e publique quando revisar.';
    var withMedia = type === 'product' || type === 'application' || type === 'article';
    var media = withMedia ? '<div class="captec-modal-media"><div class="captec-modal-media__thumb" data-modal-image-preview>' + (item.image_url ? '<img src="' + escapeAttr(item.image_url) + '" alt="">' : icon('image')) + '</div><div class="captec-modal-media__copy"><strong>Imagem destacada</strong><span data-modal-image-name>' + escapeHtml(item.image_url ? 'Imagem selecionada da Biblioteca de Mídia' : 'Nenhuma imagem selecionada') + '</span></div><div class="captec-modal-media__actions">' + button('Selecionar', { className: 'captec-button--line', action: 'pick-item-image', icon: 'upload' }) + button('Remover', { className: 'captec-button--line', action: 'clear-item-image', icon: 'close' }) + '</div></div>' : '';
    var titleLabel = type === 'button' || type === 'footer_item' || type === 'stat' ? 'Nome interno no painel' : 'Título';
    var body = '<form data-form="item" data-item-type="' + type + '"><input type="hidden" name="id" value="' + Number(item.id || 0) + '"><input type="hidden" name="type" value="' + type + '"><input type="hidden" name="image_id" value="' + Number(item.image_id || 0) + '"><input type="hidden" name="image_url" value="' + escapeAttr(item.image_url || '') + '"><input type="hidden" name="clear_image" value="0">' + media + '<div class="captec-form-grid">' + textField('title', titleLabel, { value: item.title, required: true, full: true });
    if (type === 'product') {
      body += textField('product_type', 'Categoria curta', { value: item.product_type }) + textField('order', 'Ordem de exibição', { value: item.order, type: 'number', hint: 'Comece em 0 para o primeiro card.' }) + textField('description', 'Descrição resumida', { value: item.description || item.content, type: 'textarea', full: true }) + textField('applications', 'Aplicações', { value: item.applications, type: 'textarea', full: true }) + mediaUrlField('file_url', 'URL da ficha técnica', { value: item.file_url, mediaType: 'file', full: true, hint: 'Selecione um PDF na Biblioteca de Mídia ou cole a URL do arquivo.' });
    } else if (type === 'application') {
      body += textField('subtitle', 'Linha de apoio', { value: item.subtitle }) + textField('order', 'Ordem de exibição', { value: item.order, type: 'number', hint: 'Comece em 0 para o primeiro card.' }) + textField('content', 'Descrição interna', { value: item.content, type: 'textarea', full: true, optional: true });
    } else if (type === 'location') {
      body += textField('kind', 'Tipo de unidade', { type: 'select', value: item.kind, options: [{value:'headquarters',label:'Matriz'}, {value:'branch',label:'Filial'}] }) + textField('order', 'Ordem de exibição', { value: item.order, type: 'number' }) + textField('company_name', 'Razão social', { value: item.company_name, full: true }) + textField('cnpj', 'CNPJ', { value: item.cnpj }) + textField('phone', 'Telefone', { value: item.phone, type: 'tel' }) + textField('email', 'E-mail', { value: item.email, type: 'email', full: true }) + textField('street', 'Logradouro', { value: item.street, full: true }) + textField('number', 'Número', { value: item.number }) + textField('complement', 'Complemento', { value: item.complement }) + textField('neighborhood', 'Bairro', { value: item.neighborhood }) + textField('city', 'Cidade', { value: item.city }) + textField('state', 'UF', { value: item.state }) + textField('cep', 'CEP', { value: item.cep }) + mediaUrlField('map_url', 'URL do Google Maps', { value: item.map_url, mediaType: 'none', full: true, optional: true });
    } else if (type === 'page') {
      body += textField('slug', 'Slug / URL', { value: item.slug, hint: 'Ex.: unidades, produtos ou cotacao.' }) + textField('order', 'Ordem de exibição', { value: item.order, type: 'number' }) + textField('content', 'Conteúdo da página no WordPress', { value: item.content, type: 'textarea', full: true, editor: true, optional: true, hint: item.slug === 'inicio' ? 'Quem somos usa os shortcodes [captec_quem_somos], [captec_aplicacoes] e [captec_diferenciais].' : 'Este conteúdo fica salvo na página nativa do WordPress.' });
    } else if (type === 'button') {
      body += textField('slot', 'Área do site', { type:'select', value:item.slot, options:buttonSlotOptions(), full:true }) + textField('label', 'Texto visível do botão', { value:item.label, required:true, full:true }) + textField('action', 'Destino do botão', { type:'select', value:item.action, options:[{value:'quote',label:'Abrir Solicitar cotação'},{value:'whatsapp',label:'Abrir WhatsApp'},{value:'career_email',label:'Abrir e-mail para currículos'},{value:'url',label:'URL personalizada'}] }) + textField('url', 'URL personalizada', { type:'url', value:item.url, full:true, optional:true, hint:'Preencha quando o destino for URL personalizada.' }) + textField('style', 'Estilo visual', { type:'select', value:item.style, options:[{value:'yellow',label:'Amarelo principal'},{value:'dark',label:'Escuro'},{value:'ghost',label:'Contorno claro'},{value:'line',label:'Contorno escuro'}] }) + textField('position', 'Posição na área da página', { type:'select', value:item.position || 'default', options:[{value:'default',label:'Padrão da área'},{value:'left',label:'Alinhado à esquerda'},{value:'center',label:'Centralizado'},{value:'right',label:'Alinhado à direita'}], hint:'A posição é aplicada dentro da área escolhida sem comprometer a responsividade.' }) + textField('target', 'Abrir destino', { type:'select', value:item.target, options:[{value:'same',label:'Na mesma aba'},{value:'new',label:'Em nova aba'}] }) + textField('order','Ordem',{type:'number',value:item.order});
    } else if (type === 'footer_item') {
      body += textField('section','Coluna do rodapé',{type:'select',value:item.section,options:footerSectionOptions()}) + textField('label','Texto visível',{value:item.label,required:true}) + textField('kind','Tipo de informação',{type:'select',value:item.kind,options:[{value:'link',label:'Link'},{value:'text',label:'Texto simples'}]}) + textField('action','Destino do link',{type:'select',value:item.action,options:[{value:'home',label:'Quem somos'},{value:'quote',label:'Solicitar cotação'},{value:'whatsapp',label:'WhatsApp'},{value:'phone',label:'Telefone cadastrado'},{value:'email',label:'E-mail comercial'},{value:'privacy',label:'Política de Privacidade'},{value:'cookies',label:'Política de Cookies'},{value:'maps',label:'Google Maps'},{value:'url',label:'URL personalizada'}]}) + textField('url','URL personalizada',{type:'url',value:item.url,full:true,optional:true}) + textField('target','Abrir destino',{type:'select',value:item.target,options:[{value:'same',label:'Na mesma aba'},{value:'new',label:'Em nova aba'}]}) + textField('order','Ordem',{type:'number',value:item.order});
    } else if (type === 'stat') {
      body += textField('label','Rótulo exibido',{value:item.label,required:true}) + textField('value','Valor validado',{value:item.value,required:true,hint:'Ex.: 250+, 1.500 t ou outro formato aprovado.'}) + textField('order','Ordem de exibição',{type:'number',value:item.order,hint:'Comece em 0 para o primeiro indicador.'});
    } else {
      body += textField('excerpt', 'Resumo', { value: item.excerpt, type: 'textarea', full: true, optional: true }) + textField('category_id', 'Categoria', { type:'select', value:item.category_id || 0, options:categoryOptions(), full:true }) + textField('category_name', 'Nova categoria ou alteração', { value:'', full:true, optional:true, hint:'Preencha para criar e usar uma categoria diferente.' }) + textField('content', 'Conteúdo do artigo', { value: item.content, type: 'textarea', full: true, editor: true, hint: 'Você pode usar parágrafos e marcações HTML básicas.' });
    }
    var statusOptions = type === 'location' || type === 'page' || type === 'footer_item' ? [{value:'publish',label:'Ativa / publicada'}, {value:'draft',label:'Inativa / rascunho'}] : [{value:'publish',label:'Publicado'}, {value:'draft',label:'Rascunho'}];
    body += textField('status', 'Status', { type: 'select', value: item.status, options: statusOptions, full: true }) + '</div></form>';
    renderModal(title, detail, body, item.id ? true : false);
  }

  function renderModal(title, detail, body, canDelete) {
    var root = app.querySelector('[data-modal-root]');
    if (!root) return;
    root.innerHTML = '<div class="captec-modal-backdrop is-open" data-modal-backdrop><div class="captec-modal" role="dialog" aria-modal="true" aria-labelledby="captec-modal-title"><header class="captec-modal__head"><div><h2 id="captec-modal-title">' + escapeHtml(title) + '</h2><p>' + escapeHtml(detail) + '</p></div><button class="captec-modal__close" type="button" data-action="close-modal" aria-label="Fechar">' + icon('close') + '</button></header><div class="captec-modal__body">' + body + '</div><footer class="captec-modal__footer">' + (canDelete ? button('Mover para lixeira', { className: 'captec-button--danger', action: 'delete-current-item', icon: 'trash' }) : '<span></span>') + '<div class="captec-modal__footer-actions">' + button('Cancelar', { className: 'captec-button--line', action: 'close-modal' }) + '<button class="captec-button captec-button--yellow" type="submit" form="captec-modal-form" data-action="submit-modal-form">' + icon('check') + ' Salvar item</button></div></footer></div></div>';
    var form = root.querySelector('[data-form="item"]');
    if (form) form.id = 'captec-modal-form';
    window.setTimeout(function () { var first = root.querySelector('input[name="title"]'); if (first) first.focus(); }, 60);
  }

  function closeModal() {
    state.modal = null;
    var root = app.querySelector('[data-modal-root]');
    if (!root) return;
    var back = root.querySelector('[data-modal-backdrop]');
    if (back) {
      back.classList.remove('is-open');
      window.setTimeout(function () { root.innerHTML = ''; }, 210);
    } else root.innerHTML = '';
  }

  function formDataObject(form) {
    var obj = {};
    new FormData(form).forEach(function (value, key) { obj[key] = value; });
    return obj;
  }

  function updateItemInState(type, item) {
    if (!item) return;
    var key = itemCollectionKey(type);
    var collection = state.data[key] || [];
    var index = collection.findIndex(function (entry) { return Number(entry.id) === Number(item.id); });
    if (index > -1) collection[index] = Object.assign({}, collection[index], item);
    else collection.unshift(item);
    if (type === 'product' || type === 'application' || type === 'location' || type === 'page' || type === 'button' || type === 'footer_item' || type === 'stat') collection.sort(function (a, b) { return Number(a.order || 0) - Number(b.order || 0); });
  }

  function handleClick(event) {
    var viewButton = event.target.closest('[data-view]');
    if (viewButton) {
      event.preventDefault();
      state.view = viewButton.getAttribute('data-view');
      var sidebar = app.querySelector('[data-sidebar]');
      if (sidebar) sidebar.classList.remove('is-open');
      renderView();
      if (state.view === 'analytics') loadTrafficReport(false);
      if (state.view === 'activity') loadActivityLogs(state.activityDays || 30);
      trackPortalNavigation(state.view);
      return;
    }
    var actionTarget = event.target.closest('[data-action]');
    if (!actionTarget) return;
    event.preventDefault();
    var action = actionTarget.getAttribute('data-action');
    if (action === 'toggle-sidebar') {
      var side = app.querySelector('[data-sidebar]'); if (side) side.classList.toggle('is-open'); return;
    }
    if (action === 'toggle-ai-widget') { state.assistantOpen = !state.assistantOpen; if (state.assistantOpen) trackPortalNavigation('assistant'); renderAssistantWidget(); return; }
    if (action === 'close-ai-widget') { state.assistantOpen = false; renderAssistantWidget(); return; }
    if (action === 'open-full-ai') { state.assistantOpen = false; state.view = 'assistant'; renderView(); renderAssistantWidget(); return; }
    if (action === 'set-ai-mode') { state.aiMode = actionTarget.getAttribute('data-ai-mode') === 'action' ? 'action' : 'guidance'; state.aiProposal = null; state.aiResponse = ''; renderAssistantWidget(); return; }
    if (action === 'clear-ai-response') { state.aiResponse = ''; renderAssistantWidget(); return; }
    if (action === 'open-preview') { state.view = 'preview'; renderView(); return; }
    if (action === 'set-preview-device') { state.previewDevice = actionTarget.getAttribute('data-preview-device') || 'desktop'; renderView(); return; }
    if (action === 'set-preview-page') { state.previewPage = actionTarget.getAttribute('data-preview-page') || 'inicio'; renderView(); return; }
    if (action === 'refresh-preview') { renderView(); return; }
    if (action === 'publish-draft-settings') { publishDraftSettings(actionTarget); return; }
    if (action === 'toggle-item-status') { toggleItemStatus(actionTarget); return; }
    if (action === 'preview-feature') { openFeaturePreview(actionTarget.getAttribute('data-feature-key') || ''); return; }
    if (action === 'open-feature-preview-page') { var featureUrl = actionTarget.getAttribute('data-preview-url'); if (featureUrl) window.open(featureUrl, '_blank', 'noopener'); return; }
    if (action === 'reload' || action === 'refresh') { boot(); return; }
    if (action === 'go-home') { state.view = 'home'; renderView(); return; }
    if (action === 'new-item') { openItemModal(actionTarget.getAttribute('data-content-type'), null); return; }
    if (action === 'edit-item') { openItemModal(actionTarget.getAttribute('data-content-type'), findItem(actionTarget.getAttribute('data-content-type'), actionTarget.getAttribute('data-id'))); return; }
    if (action === 'close-modal') { closeModal(); return; }
    if (action === 'seed-catalog') { seedCatalog(actionTarget); return; }
    if (action === 'setup-pages') { setupPages(actionTarget); return; }
    if (action === 'generate-topic') { generateTopic(actionTarget); return; }
    if (action === 'refresh-analytics') { loadAnalytics(true); return; }
    if (action === 'refresh-traffic') { loadTrafficReport(true); return; }
    if (action === 'voice-command') { startVoiceCommand(actionTarget); return; }
    if (action === 'execute-ai-proposal') { executeAIProposal(actionTarget); return; }
    if (action === 'clear-ai-proposal') { state.aiProposal = null; if (state.view === 'assistant') renderView(); renderAssistantWidget(); return; }
    if (action === 'pick-ai-avatar') { pickAIAvatar(); return; }
    if (action === 'clear-ai-avatar') { clearAIAvatar(); return; }
    if (action === 'select-quote') { state.selectedQuote = actionTarget.getAttribute('data-id'); renderView(); return; }
    if (action === 'delete-current-item') { deleteCurrentItem(); return; }
    if (action === 'delete-item') { deleteItemById(actionTarget); return; }
    if (action === 'pick-setting-media') { pickSettingMedia(actionTarget); return; }
    if (action === 'pick-logo') { pickLogo(); return; }
    if (action === 'clear-logo') { clearLogo(); return; }
    if (action === 'pick-item-image') { pickItemImage(); return; }
    if (action === 'clear-item-image') { clearItemImage(); return; }
    if (action === 'submit-modal-form') { var form = app.querySelector('#captec-modal-form'); if (form) form.requestSubmit(); return; }
  }

  function handleInput(event) {
    var searchInput = event.target.closest('[data-catalog-search]');
    if (searchInput) {
      state.catalogSearch = searchInput.value;
      var cursor = searchInput.selectionStart;
      renderView();
      var next = app.querySelector('[data-catalog-search]');
      if (next) { next.focus(); try { next.setSelectionRange(cursor, cursor); } catch (e) {} }
      return;
    }
    var menuControl = event.target.closest('[data-menu-control]');
    if (menuControl) { updateMenuPreview(); return; }
    var analyticsControl = event.target.closest('[data-analytics-filter-control]');
    if (analyticsControl) {
      state.analyticsFilters[analyticsControl.name] = analyticsControl.value;
      if (analyticsControl.name === 'period' && state.view === 'analytics') renderView();
      return;
    }
    var trafficControl = event.target.closest('[data-traffic-filter-control]');
    if (trafficControl) {
      state.trafficFilters[trafficControl.name] = trafficControl.value;
      if (trafficControl.name === 'period' && state.view === 'analytics') renderView();
    }
  }

  function handleSubmit(event) {
    var form = event.target;
    if (!form.matches('[data-form]')) return;
    event.preventDefault();
    var type = form.getAttribute('data-form');
    if (type === 'settings') saveSettings(form);
    if (type === 'item') saveItem(form);
    if (type === 'quote') saveQuote(form);
    if (type === 'features') saveFeatures(form);
    if (type === 'analytics') saveAnalytics(form);
    if (type === 'analytics-filter') applyAnalyticsFilters(form);
    if (type === 'traffic-filter') applyTrafficFilters(form);
    if (type === 'activity-filter') loadActivityLogs((form.querySelector('[name="days"]') || {}).value || 30);
    if (type === 'ai-settings') saveAISettings(form);
    if (type === 'ai-command') proposeAICommand(form);
    if (type === 'ai-guidance') askAIOrientation(form);
  }

  function setSubmitting(form, active) {
    var buttonElement = form.querySelector('button[type="submit"]');
    if (!buttonElement) return;
    if (active) { buttonElement.dataset.original = buttonElement.innerHTML; buttonElement.disabled = true; buttonElement.innerHTML = icon('refresh') + ' Salvando…'; }
    else { buttonElement.disabled = false; if (buttonElement.dataset.original) buttonElement.innerHTML = buttonElement.dataset.original; }
  }

  function publishDraftSettings(buttonElement) {
    var count = Number(state.data.draft_settings_count || 0);
    if (!count) { toast('Não há configurações pendentes para publicar.', 'info'); return; }
    if (!window.confirm('Publicar ' + count + ' alteração' + (count > 1 ? 'ões' : '') + ' no portal?')) return;
    buttonElement.disabled = true;
    request('captec_portal_publish_settings').then(function (response) {
      state.data.settings = response.settings || state.data.settings;
      state.data.dashboard = response.dashboard || state.data.dashboard;
      state.data.draft_settings_count = response.draft_settings_count != null ? response.draft_settings_count : 0;
      refreshAdminLogo();
      renderView();
      toast(response.message || 'Configurações publicadas.', 'success');
    }).catch(function (error) { buttonElement.disabled = false; toast(error.message, 'error'); });
  }

  function saveSettings(form) {
    var payload = formDataObject(form);
    setSubmitting(form, true);
    request('captec_portal_save_settings', { payload: payload }).then(function (response) {
      state.data.settings = response.settings || state.data.settings;
      state.data.dashboard = response.dashboard || state.data.dashboard;
      state.data.draft_settings_count = response.draft_settings_count != null ? response.draft_settings_count : state.data.draft_settings_count;
      refreshAdminLogo();
      setSubmitting(form, false);
      toast(response.message || 'Alterações salvas.', 'success');
      if (state.view === 'home' || state.view === 'brand' || state.view === 'pagecontent' || state.view === 'appearance' || state.view === 'coverage' || state.view === 'integrations') renderView();
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function toggleItemStatus(buttonElement) {
    var type = buttonElement.getAttribute('data-content-type');
    var id = Number(buttonElement.getAttribute('data-id') || 0);
    var target = buttonElement.getAttribute('data-status') || 'draft';
    if (!type || !id) return;
    var label = target === 'publish' ? 'Publicado' : 'Rascunho';
    if (!window.confirm('Alterar este item para ' + label + '?')) return;
    buttonElement.disabled = true;
    request('captec_portal_toggle_item_status', { id:id, content_type:type, status:target }).then(function(response) {
      updateItemInState(type, response.item);
      state.data.dashboard = response.dashboard || state.data.dashboard;
      renderView();
      toast(response.message || 'Status atualizado.', 'success');
    }).catch(function(error) { buttonElement.disabled = false; toast(error.message || 'Não foi possível alterar o status.', 'error'); });
  }

  function saveItem(form) {
    var payload = formDataObject(form);
    payload.id = Number(payload.id || 0);
    payload.order = Number(payload.order || 0);
    payload.image_id = Number(payload.image_id || 0);
    payload.clear_image = payload.clear_image === '1';
    setSubmitting(form, true);
    request('captec_portal_save_item', { payload: payload }).then(function (response) {
      updateItemInState(payload.type, response.item);
      if (response.categories) state.data.categories = response.categories;
      state.data.dashboard = response.dashboard || state.data.dashboard;
      closeModal();
      renderView();
      toast(response.message || 'Item salvo.', 'success');
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function saveQuote(form) {
    var payload = formDataObject(form);
    payload.id = Number(form.getAttribute('data-id'));
    setSubmitting(form, true);
    request('captec_portal_save_quote', { payload: payload }).then(function (response) {
      var index = (state.data.quotes || []).findIndex(function (quote) { return Number(quote.id) === Number(response.item.id); });
      if (index > -1) state.data.quotes[index] = response.item;
      setSubmitting(form, false);
      renderView();
      toast(response.message || 'Cotação atualizada.', 'success');
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function trackPortalNavigation(view) {
    request('captec_portal_log_navigation', { view: view }).catch(function () { /* Histórico não bloqueia a navegação. */ });
  }

  function loadActivityLogs(days) {
    state.activityDays = Number(days || 30);
    state.activityLoading = true;
    if (state.view === 'activity') renderView();
    request('captec_portal_activity_logs', { days: state.activityDays }).then(function (response) {
      state.activityLogs = response.logs || [];
      state.activityError = response.last_error || '';
      state.activityLoading = false;
      if (state.view === 'activity') renderView();
    }).catch(function (error) {
      state.activityLoading = false;
      if (state.view === 'activity') { renderView(); toast(error.message || 'Não foi possível carregar o histórico.', 'error'); }
    });
  }

  function applyTrafficFilters(form) {
    var values = formDataObject(form);
    state.trafficFilters = { period: values.period || '30days', start: values.start || '', end: values.end || '' };
    loadTrafficReport(true);
  }

  function loadTrafficReport(force) {
    if (state.trafficLoading) return;
    state.trafficLoading = true;
    state.trafficError = '';
    if (state.view === 'analytics') renderView();
    var filters = state.trafficFilters || { period:'30days', start:'', end:'' };
    request('captec_portal_traffic_report', { period:filters.period||'30days', start:filters.start||'', end:filters.end||'', force:force?'1':'' }).then(function(response){
      state.trafficReport = response.report || null;
      state.trafficHealth = response.health || null;
      state.trafficLoading = false;
      if (state.view === 'analytics') renderView();
    }).catch(function(error){
      state.trafficLoading = false;
      state.trafficError = error.message || 'Não foi possível carregar o tráfego.';
      if (state.view === 'analytics') renderView();
    });
  }

  function applyAnalyticsFilters(form) {
    var values = formDataObject(form);
    state.analyticsFilters = { period: values.period || 'year', start: values.start || '', end: values.end || '' };
    loadAnalytics(true);
  }

  function loadAnalytics(force) {
    var settings = state.data.analytics || {};
    if (!settings.configured) { state.analyticsLoading = false; return; }
    if (state.analyticsLoading) return;
    state.analyticsLoading = true;
    state.analyticsError = '';
    if (state.view === 'analytics') renderView();
    var filters = state.analyticsFilters || { period: 'year', start: '', end: '' };
    request('captec_portal_analytics', { force: force ? '1' : '', period: filters.period || 'year', start: filters.start || '', end: filters.end || '' }).then(function (response) {
      state.analyticsReport = response.report || null;
      state.data.analytics = response.analytics || state.data.analytics;
      state.analyticsLoading = false;
      state.analyticsError = '';
      if (state.view === 'analytics') renderView();
    }).catch(function (error) {
      state.analyticsLoading = false;
      state.analyticsError = error.message || 'Não foi possível carregar a análise.';
      if (state.view === 'analytics') renderView();
    });
  }

  function saveAnalytics(form) {
    var payload = formDataObject(form);
    setSubmitting(form, true);
    request('captec_portal_save_analytics', { payload: payload }).then(function (response) {
      state.data.analytics = response.analytics || state.data.analytics;
      state.analyticsReport = null;
      state.analyticsError = '';
      setSubmitting(form, false);
      toast(response.message || 'Configuração de análise salva.', 'success');
      loadAnalytics(true);
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function setupPages(buttonElement) {
    if (!window.confirm('Criar ou atualizar as páginas do portal e configurar o menu principal? Páginas existentes não serão apagadas.')) return;
    if (buttonElement) buttonElement.disabled = true;
    request('captec_portal_setup_pages').then(function (response) {
      state.data.pages = response.pages || [];
      state.data.dashboard = response.dashboard || state.data.dashboard;
      state.view = 'pages';
      renderView();
      toast(response.message || 'Estrutura de páginas criada.', 'success');
    }).catch(function (error) { if (buttonElement) buttonElement.disabled = false; toast(error.message, 'error'); });
  }

  function saveFeatures(form) {
    var formData = formDataObject(form);
    var payload = { items: {}, maintenance: formData.maintenance === '1', message: formData.maintenance_message || '' };
    ((state.data.features || {}).items || []).forEach(function (feature) {
      var input = form.querySelector('[name="feature_' + feature.key + '"]');
      payload.items[feature.key] = !!(input && input.checked);
    });
    setSubmitting(form, true);
    request('captec_portal_save_features', { payload: payload }).then(function (response) {
      state.data.features = response.features || state.data.features;
      setSubmitting(form, false);
      renderView();
      toast(response.message || 'Funcionalidades atualizadas.', 'success');
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function saveAISettings(form) {
    var payload = formDataObject(form);
    setSubmitting(form, true);
    request('captec_portal_ai_settings', { payload: payload }).then(function (response) {
      state.data.ai = response.ai || state.data.ai;
      setSubmitting(form, false);
      renderView();
      renderAssistantWidget();
      toast(response.message || 'Perfil do agente salvo.', 'success');
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function askAIOrientation(form) {
    var question = (form.querySelector('[name="question"]') || {}).value || '';
    if (!question.trim()) { toast('Descreva sua dúvida para receber uma orientação.', 'error'); return; }
    setSubmitting(form, true);
    request('captec_portal_ai_orient', { question: question }).then(function (response) {
      state.aiResponse = response.message || 'Não compreendi esta solicitação.\nEntre em contato com o Administrador do site para receber orientação.';
      setSubmitting(form, false);
      renderAssistantWidget();
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function proposeAICommand(form) {
    var command = (form.querySelector('[name="command"]') || {}).value || '';
    if (!command.trim()) { toast('Descreva uma tarefa para gerar uma prévia.', 'error'); return; }
    setSubmitting(form, true);
    request('captec_portal_ai_propose', { command: command }).then(function (response) {
      state.aiProposal = response.proposal;
      setSubmitting(form, false);
      if (state.view === 'assistant') renderView();
      renderAssistantWidget();
    }).catch(function (error) { setSubmitting(form, false); toast(error.message, 'error'); });
  }

  function executeAIProposal(buttonElement) {
    if (!state.aiProposal || !state.aiProposal.id) return;
    buttonElement.disabled = true;
    request('captec_portal_ai_execute', { proposal_id: state.aiProposal.id }).then(function (response) {
      if (response.item) updateItemInState(response.item.type || (state.aiProposal.type === 'create_product' ? 'product' : 'page'), response.item);
      if (response.pages) state.data.pages = response.pages;
      if (response.features) state.data.features = response.features;
      state.data.dashboard = response.dashboard || state.data.dashboard;
      state.aiProposal = null;
      if (state.view === 'assistant' || state.view === 'products' || state.view === 'pages' || state.view === 'features') renderView();
      renderAssistantWidget();
      toast(response.message || 'Ação executada após sua autorização.', 'success');
    }).catch(function (error) { buttonElement.disabled = false; toast(error.message, 'error'); });
  }

  function startVoiceCommand(buttonElement) {
    var Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    var voiceForm = buttonElement.closest('form');
    var fieldName = buttonElement.getAttribute('data-voice-target') || 'command';
    var status = voiceForm ? voiceForm.querySelector('[data-voice-status]') : app.querySelector('[data-voice-status]');
    if (!Recognition) { toast('O reconhecimento de voz não é suportado neste navegador. Use Chrome ou Edge em localhost/HTTPS.', 'error'); return; }
    var recognition = new Recognition();
    recognition.lang = 'pt-BR';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    if (status) status.textContent = 'Ouvindo… fale sua solicitação.';
    buttonElement.classList.add('is-listening');
    recognition.onresult = function (event) {
      var text = event.results[0][0].transcript;
      var input = voiceForm ? voiceForm.querySelector('[name="' + fieldName + '"]') : app.querySelector('[name="' + fieldName + '"]');
      if (input) { input.value = text; input.focus(); }
      if (status) status.textContent = 'Solicitação convertida em texto. Revise e escolha Gerar resposta ou Gerar prévia.';
    };
    recognition.onerror = function () { if (status) status.textContent = 'Não foi possível reconhecer a voz. Tente novamente ou digite o comando.'; };
    recognition.onend = function () { buttonElement.classList.remove('is-listening'); };
    recognition.start();
  }

  function pickAIAvatar() {
    openMediaPicker({ title: 'Selecionar imagem do agente', type: 'image' }, function (attachment) {
      var form = app.querySelector('[data-form="ai-settings"]');
      if (!form) return;
      var input = form.querySelector('[name="avatar_id"]');
      var preview = app.querySelector('[data-ai-profile-image]');
      if (input) input.value = attachment.id || 0;
      if (preview) preview.innerHTML = '<img src="' + escapeAttr(attachment.url || '') + '" alt="Agente">';
    });
  }

  function clearAIAvatar() {
    var form = app.querySelector('[data-form="ai-settings"]');
    var preview = app.querySelector('[data-ai-profile-image]');
    if (form && form.querySelector('[name="avatar_id"]')) form.querySelector('[name="avatar_id"]').value = '0';
    if (preview) preview.innerHTML = icon('assistant');
  }

  function generateTopic(buttonElement) {
    var topicId = buttonElement.getAttribute('data-topic-id');
    if (!topicId) return;
    buttonElement.disabled = true;
    request('captec_portal_generate_article', { topic_id: topicId }).then(function (response) {
      if (response.item) updateItemInState('article', response.item);
      state.data.suggested_topics = response.topics || [];
      if (response.categories) state.data.categories = response.categories;
      renderView();
      toast(response.message || 'Artigo gerado como rascunho.', 'success');
    }).catch(function (error) { buttonElement.disabled = false; toast(error.message, 'error'); });
  }

  function seedCatalog(buttonElement) {
    buttonElement.disabled = true;
    request('captec_portal_seed_catalog').then(function (response) {
      state.data.products = response.products || [];
      state.data.applications = response.applications || [];
      state.data.dashboard = response.dashboard || state.data.dashboard;
      renderView();
      toast(response.message || 'Catálogo preparado.', 'success');
    }).catch(function (error) { buttonElement.disabled = false; toast(error.message, 'error'); });
  }

  function deleteItemById(buttonElement) {
    var type = buttonElement.getAttribute('data-content-type');
    var id = Number(buttonElement.getAttribute('data-id') || 0);
    var title = buttonElement.getAttribute('data-item-title') || 'este item';
    if (!type || !id || !window.confirm('Mover “' + title + '” para a lixeira?')) return;
    buttonElement.disabled = true;
    request('captec_portal_delete_item', { id:id, content_type:type }).then(function(response) {
      var key = itemCollectionKey(type);
      state.data[key] = (state.data[key] || []).filter(function(entry){ return Number(entry.id) !== id; });
      state.data.dashboard = response.dashboard || state.data.dashboard;
      renderView();
      toast(response.message || 'Item movido para a lixeira.', 'success');
    }).catch(function(error){ buttonElement.disabled = false; toast(error.message || 'Não foi possível excluir o item.', 'error'); });
  }

  function deleteCurrentItem() {
    if (!state.modal || !state.modal.item || !state.modal.item.id) return;
    var item = state.modal.item;
    var type = state.modal.type;
    if (!window.confirm('Mover “' + (item.title || 'este item') + '” para a lixeira?')) return;
    request('captec_portal_delete_item', { id: item.id, content_type: type }).then(function (response) {
      var key = itemCollectionKey(type);
      state.data[key] = (state.data[key] || []).filter(function (entry) { return Number(entry.id) !== Number(item.id); });
      state.data.dashboard = response.dashboard || state.data.dashboard;
      closeModal(); renderView(); toast(response.message || 'Item movido para a lixeira.', 'success');
    }).catch(function (error) { toast(error.message, 'error'); });
  }

  function openMediaPicker(options, callback) {
    options = options || {};
    if (config.demo || !window.wp || !window.wp.media) {
      toast('A seleção de mídia é aberta pela Biblioteca de Mídia quando o painel está no WordPress.', 'info');
      return;
    }
    var frame = window.wp.media({ title: options.title || 'Selecionar arquivo', button: { text: 'Usar este arquivo' }, library: options.type && options.type !== 'none' ? { type: options.type } : {}, multiple: false });
    frame.on('select', function () {
      var attachment = frame.state().get('selection').first().toJSON();
      callback(attachment);
    });
    frame.open();
  }

  function pickSettingMedia(buttonElement) {
    var id = buttonElement.getAttribute('data-target');
    var input = document.getElementById(id);
    if (!input) return;
    var type = buttonElement.getAttribute('data-media-type') || 'image';
    openMediaPicker({ title: 'Selecionar arquivo', type: type === 'file' ? '' : type }, function (attachment) {
      input.value = attachment.url || '';
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  }

  function pickLogo() {
    openMediaPicker({ title: 'Selecionar logo oficial', type: 'image' }, function (attachment) {
      var root = app.querySelector('[data-form="settings"]');
      if (!root) return;
      var id = root.querySelector('[name="custom_logo_id"]');
      var url = root.querySelector('[name="custom_logo_url"]');
      var preview = root.querySelector('[data-logo-preview]');
      if (id) id.value = attachment.id || 0;
      if (url) url.value = attachment.url || '';
      if (preview) preview.innerHTML = '<img src="' + escapeAttr(attachment.url || '') + '" alt="Logo selecionado">';
    });
  }

  function clearLogo() {
    var root = app.querySelector('[data-form="settings"]');
    if (!root) return;
    var id = root.querySelector('[name="custom_logo_id"]');
    var url = root.querySelector('[name="custom_logo_url"]');
    var preview = root.querySelector('[data-logo-preview]');
    if (id) id.value = '0'; if (url) url.value = ''; if (preview) preview.innerHTML = icon('image');
  }

  function pickItemImage() {
    openMediaPicker({ title: 'Selecionar imagem destacada', type: 'image' }, function (attachment) {
      var modal = app.querySelector('[data-modal-backdrop]');
      if (!modal) return;
      var imageId = modal.querySelector('[name="image_id"]');
      var imageUrl = modal.querySelector('[name="image_url"]');
      var preview = modal.querySelector('[data-modal-image-preview]');
      var name = modal.querySelector('[data-modal-image-name]');
      if (imageId) imageId.value = attachment.id || 0;
      if (imageUrl) imageUrl.value = attachment.url || '';
      if (preview) preview.innerHTML = '<img src="' + escapeAttr(attachment.url || '') + '" alt="Imagem selecionada">';
      if (name) name.textContent = attachment.filename || 'Imagem selecionada da Biblioteca de Mídia';
    });
  }

  function clearItemImage() {
    var modal = app.querySelector('[data-modal-backdrop]');
    if (!modal) return;
    var imageId = modal.querySelector('[name="image_id"]');
    var imageUrl = modal.querySelector('[name="image_url"]');
    var clear = modal.querySelector('[name="clear_image"]');
    var preview = modal.querySelector('[data-modal-image-preview]');
    var name = modal.querySelector('[data-modal-image-name]');
    if (imageId) imageId.value = '0'; if (imageUrl) imageUrl.value = ''; if (clear) clear.value = '1'; if (preview) preview.innerHTML = icon('image'); if (name) name.textContent = 'Nenhuma imagem selecionada';
  }

  function toast(message, type) {
    var target = app.querySelector('[data-toast]');
    if (!target) return;
    window.clearTimeout(state.toastTimer);
    type = type || 'success';
    target.className = 'captec-toast captec-toast--' + type + ' is-visible';
    target.innerHTML = '<span class="captec-toast__icon">' + (type === 'error' ? icon('info') : type === 'success' ? icon('check') : icon('info')) + '</span><p>' + escapeHtml(message || '') + '</p><button class="captec-toast__close" type="button" data-action="dismiss-toast" aria-label="Fechar">' + icon('close') + '</button>';
    target.querySelector('[data-action="dismiss-toast"]').addEventListener('click', function () { target.classList.remove('is-visible'); });
    state.toastTimer = window.setTimeout(function () { target.classList.remove('is-visible'); }, 4700);
  }

  boot();
}());

<?php
/**
 * Plugin Name: Portal Administrativo CAPTEC
 * Description: Painel administrativo visual para gerir todo o conteúdo do portal CAPTEC Asfaltos conectado ao WordPress.
 * Version: 3.4.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: CAPTEC Asfaltos
 * Text Domain: captec-portal-admin
 */

defined( 'ABSPATH' ) || exit;

require_once plugin_dir_path( __FILE__ ) . 'inc/agent-knowledge.php';

final class CAPTEC_Portal_Admin {
	const VERSION    = '3.4.0';
	const STRUCTURE_VERSION = '3.4.0';
	const PRESENTATION_VERSION = '3.3.0';
	const CAPABILITY = 'captec_manage_portal';
	const SLUG       = 'captec-portal';

	/** @var CAPTEC_Portal_Admin|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'init', array( $this, 'maybe_seed_catalog' ), 30 );
		add_action( 'init', array( $this, 'maybe_seed_presentation_content' ), 40 );
		add_action( 'admin_init', array( $this, 'maybe_upgrade_portal_structure' ), 35 );
		add_action( 'template_redirect', array( $this, 'maybe_render_maintenance' ), 0 );
		add_action( 'init', array( $this, 'maybe_upgrade_activity_log' ), 5 );
		add_action( 'captec_portal_cleanup_logs', array( $this, 'cleanup_activity_logs' ) );

		add_action( 'wp_ajax_captec_portal_bootstrap', array( $this, 'ajax_bootstrap' ) );
		add_action( 'wp_ajax_captec_portal_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_captec_portal_publish_settings', array( $this, 'ajax_publish_settings' ) );
		add_action( 'wp_ajax_captec_portal_save_item', array( $this, 'ajax_save_item' ) );
		add_action( 'wp_ajax_captec_portal_delete_item', array( $this, 'ajax_delete_item' ) );
		add_action( 'wp_ajax_captec_portal_toggle_item_status', array( $this, 'ajax_toggle_item_status' ) );
		add_action( 'wp_ajax_captec_portal_save_quote', array( $this, 'ajax_save_quote' ) );
		add_action( 'wp_ajax_captec_portal_seed_catalog', array( $this, 'ajax_seed_catalog' ) );
		add_action( 'wp_ajax_captec_portal_setup_pages', array( $this, 'ajax_setup_pages' ) );
		add_action( 'wp_ajax_captec_portal_save_features', array( $this, 'ajax_save_features' ) );
		add_action( 'wp_ajax_captec_portal_ai_propose', array( $this, 'ajax_ai_propose' ) );
		add_action( 'wp_ajax_captec_portal_ai_orient', array( $this, 'ajax_ai_orient' ) );
		add_action( 'wp_ajax_captec_portal_ai_execute', array( $this, 'ajax_ai_execute' ) );
		add_action( 'wp_ajax_captec_portal_ai_settings', array( $this, 'ajax_ai_settings' ) );
		add_action( 'wp_ajax_captec_portal_analytics', array( $this, 'ajax_analytics' ) );
		add_action( 'wp_ajax_captec_portal_traffic_report', array( $this, 'ajax_traffic_report' ) );
		add_action( 'wp_ajax_captec_portal_save_analytics', array( $this, 'ajax_save_analytics' ) );
		add_action( 'wp_ajax_captec_portal_generate_article', array( $this, 'ajax_generate_article' ) );
		add_action( 'wp_ajax_captec_portal_activity_logs', array( $this, 'ajax_activity_logs' ) );
		add_action( 'wp_ajax_captec_portal_log_navigation', array( $this, 'ajax_log_navigation' ) );
	}

	public static function install_activity_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = $wpdb->prefix . 'captec_activity_log';
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action_key varchar(100) NOT NULL,
			object_type varchar(80) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			description text NOT NULL,
			context longtext NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY user_id (user_id),
			KEY action_key (action_key)
		) $charset;";
		dbDelta( $sql );
		update_option( 'captec_activity_log_version', self::VERSION, false );
	}

	public function maybe_upgrade_activity_log() {
		if ( get_option( 'captec_activity_log_version' ) !== self::VERSION || ! $this->activity_table_exists() ) {
			self::install_activity_table();
		}
		if ( ! wp_next_scheduled( 'captec_portal_cleanup_logs' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'captec_portal_cleanup_logs' );
		}
	}

	public static function activate() {
		self::install_activity_table();
		if ( ! wp_next_scheduled( 'captec_portal_cleanup_logs' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'captec_portal_cleanup_logs' );
		}
		$administrator = get_role( 'administrator' );
		if ( $administrator ) {
			$administrator->add_cap( self::CAPABILITY );
		}

		$manager = get_role( 'captec_manager' );
		if ( ! $manager ) {
			add_role( 'captec_manager', __( 'Gestor CAPTEC', 'captec-portal-admin' ), array(
				'read'                => true,
				'edit_posts'          => true,
				'upload_files'        => true,
				self::CAPABILITY      => true,
			) );
		} else {
			$manager->add_cap( self::CAPABILITY );
			$manager->add_cap( 'edit_posts' );
			$manager->add_cap( 'upload_files' );
		}

		// A importação só ocorre se os CPTs do tema existirem e estiverem vazios.
		update_option( 'captec_portal_seed_catalog', '1', false );
		update_option( 'captec_presentation_version', '', false );
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'captec_portal_cleanup_logs' );
		// Não removemos conteúdo, configurações ou registros de cotação ao desativar.
	}

	public function register_menu() {
		add_menu_page(
			__( 'Portal CAPTEC', 'captec-portal-admin' ),
			__( 'Portal CAPTEC', 'captec-portal-admin' ),
			self::CAPABILITY,
			self::SLUG,
			array( $this, 'render_app' ),
			'dashicons-screenoptions',
			2
		);
	}

	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}

		wp_enqueue_media();
		$css       = plugin_dir_path( __FILE__ ) . 'assets/css/portal-admin.css';
		$extra_css = plugin_dir_path( __FILE__ ) . 'assets/css/portal-admin-extra.css';
		$js        = plugin_dir_path( __FILE__ ) . 'assets/js/portal-admin.js';
		wp_enqueue_style( 'captec-portal-admin', plugin_dir_url( __FILE__ ) . 'assets/css/portal-admin.css', array(), file_exists( $css ) ? (string) filemtime( $css ) : self::VERSION );
		wp_enqueue_style( 'captec-portal-admin-extra', plugin_dir_url( __FILE__ ) . 'assets/css/portal-admin-extra.css', array( 'captec-portal-admin' ), file_exists( $extra_css ) ? (string) filemtime( $extra_css ) : self::VERSION );
		wp_enqueue_script( 'captec-portal-admin', plugin_dir_url( __FILE__ ) . 'assets/js/portal-admin.js', array(), file_exists( $js ) ? (string) filemtime( $js ) : self::VERSION, true );
		wp_localize_script( 'captec-portal-admin', 'CaptecPortalAdmin', array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'captec_portal_admin' ),
			'siteUrl'     => home_url( '/' ),
			'adminUrl'    => admin_url(),
			'pluginUrl'   => plugin_dir_url( __FILE__ ),
			'manualUrl'   => plugin_dir_url( __FILE__ ) . 'docs/manual-portal-captec.pdf',
			'demo'        => false,
			'labels'      => array(
				'save'    => __( 'Salvar alterações', 'captec-portal-admin' ),
				'saving'  => __( 'Salvando…', 'captec-portal-admin' ),
				'saved'   => __( 'Alterações salvas', 'captec-portal-admin' ),
				'error'   => __( 'Não foi possível concluir a ação.', 'captec-portal-admin' ),
			),
		) );
	}

	public function render_app() {
		if ( ! $this->can_manage() ) {
			wp_die( esc_html__( 'Você não tem permissão para acessar o Portal CAPTEC.', 'captec-portal-admin' ) );
		}
		?>
		<div id="captec-portal-app" class="captec-portal-app" data-site-url="<?php echo esc_url( home_url( '/' ) ); ?>">
			<div class="captec-portal-loading" aria-live="polite">
				<div class="captec-loader-mark"><i></i><strong>CAPTEC</strong></div>
				<p><?php esc_html_e( 'Carregando o portal administrativo…', 'captec-portal-admin' ); ?></p>
			</div>
		</div>
		<?php
	}

	private function can_manage() {
		return current_user_can( self::CAPABILITY ) || current_user_can( 'manage_options' );
	}

	private function guard_ajax() {
		if ( ! check_ajax_referer( 'captec_portal_admin', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Sessão expirada. Atualize a página e tente novamente.', 'captec-portal-admin' ) ), 403 );
		}
		if ( ! $this->can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Você não tem permissão para executar esta ação.', 'captec-portal-admin' ) ), 403 );
		}
	}

	private function activity_table() {
		global $wpdb;
		return $wpdb->prefix . 'captec_activity_log';
	}

	private function activity_table_exists() {
		global $wpdb;
		$table = $this->activity_table();
		return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	}

	private function ensure_activity_table() {
		if ( ! $this->activity_table_exists() ) {
			self::install_activity_table();
		}
	}

	private function log_activity( $action_key, $description, $object_type = '', $object_id = 0, $context = array() ) {
		global $wpdb;
		$this->ensure_activity_table();
		$table = $this->activity_table();
		$inserted = $wpdb->insert( $table, array(
			'user_id'     => get_current_user_id(),
			'action_key'  => sanitize_key( $action_key ),
			'object_type' => sanitize_key( $object_type ),
			'object_id'   => absint( $object_id ),
			'description' => sanitize_text_field( $description ),
			'context'     => $context ? wp_json_encode( $context ) : '',
			'created_at'  => current_time( 'mysql', true ),
		), array( '%d', '%s', '%s', '%d', '%s', '%s', '%s' ) );
		if ( false === $inserted ) {
			update_option( 'captec_activity_log_last_error', $wpdb->last_error, false );
			return false;
		}
		delete_option( 'captec_activity_log_last_error' );
		return true;
	}

	public function cleanup_activity_logs() {
		global $wpdb;
		$this->ensure_activity_table();
		$table = $this->activity_table();
		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-6 months' ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE created_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name é interno e controlado.
	}

	private function activity_logs( $days = 30, $limit = 100 ) {
		global $wpdb;
		$this->ensure_activity_table();
		$this->cleanup_activity_logs();
		$table = $this->activity_table();
		$days  = min( 180, max( 1, absint( $days ) ) );
		$limit = min( 250, max( 1, absint( $limit ) ) );
		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $days . ' days' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT log.*, users.display_name FROM $table AS log LEFT JOIN {$wpdb->users} AS users ON users.ID = log.user_id WHERE log.created_at >= %s ORDER BY log.created_at DESC LIMIT %d", $cutoff, $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nomes de tabela internos.
		foreach ( $rows as &$row ) {
			$row['id'] = (int) $row['id'];
			$row['user_id'] = (int) $row['user_id'];
			$row['object_id'] = (int) $row['object_id'];
			$row['context'] = $row['context'] ? json_decode( $row['context'], true ) : array();
		}
		unset( $row );
		return $rows;
	}

	private function setting_schema() {
		return array(
			'site_title'                 => array( 'default' => 'CAPTEC Asfaltos', 'kind' => 'option_text' ),
			'site_tagline'               => array( 'default' => '', 'kind' => 'option_text' ),
			'custom_logo_id'             => array( 'default' => 0, 'kind' => 'logo' ),
			'captec_hero_title'          => array( 'default' => 'CAPTEC ASFALTOS', 'kind' => 'text' ),
			'captec_hero_subtitle'       => array( 'default' => 'Soluções inteligentes para pavimentação e infraestrutura.', 'kind' => 'text' ),
			'captec_hero_text'           => array( 'default' => 'Especialistas no fornecimento de produtos asfálticos para obras públicas e privadas com atendimento consultivo, eficiência logística e compromisso com resultados.', 'kind' => 'textarea' ),
			'captec_hero_poster'         => array( 'default' => '', 'kind' => 'url' ),
			'captec_hero_video_url'      => array( 'default' => '', 'kind' => 'url' ),
			'captec_about_eyebrow'       => array( 'default' => 'Quem somos', 'kind' => 'text' ),
			'captec_about_title'         => array( 'default' => 'Distribuição que conecta qualidade, planejamento e resultado.', 'kind' => 'textarea' ),
			'captec_about_text_1'        => array( 'default' => 'A CAPTEC Asfaltos atua na distribuição de produtos asfálticos para obras públicas e privadas, com foco em qualidade, relacionamento e eficiência.', 'kind' => 'textarea' ),
			'captec_about_text_2'        => array( 'default' => 'Da demanda inicial à entrega, trabalhamos para tornar o processo comercial mais claro e alinhado às necessidades de cada projeto.', 'kind' => 'textarea' ),
			'captec_about_image'         => array( 'default' => '', 'kind' => 'url' ),
			'captec_careers_eyebrow'     => array( 'default' => 'Trabalhe conosco', 'kind' => 'text' ),
			'captec_careers_title'        => array( 'default' => 'Construa caminhos com a CAPTEC.', 'kind' => 'textarea' ),
			'captec_careers_text'         => array( 'default' => 'Se você deseja fazer parte do nosso time, envie seu currículo para análise.', 'kind' => 'textarea' ),
			'captec_careers_instruction'  => array( 'default' => 'No e-mail, informe sua cidade/UF, área de interesse e envie o currículo em PDF.', 'kind' => 'textarea' ),
			'captec_careers_email'        => array( 'default' => '', 'kind' => 'email' ),
			'captec_careers_button_label' => array( 'default' => 'Enviar currículo', 'kind' => 'text' ),
			'captec_careers_note'         => array( 'default' => 'As candidaturas são avaliadas conforme as necessidades da empresa.', 'kind' => 'textarea' ),
			'captec_phone'               => array( 'default' => '', 'kind' => 'phone' ),
			'captec_whatsapp'            => array( 'default' => '', 'kind' => 'phone' ),
			'captec_email'               => array( 'default' => '', 'kind' => 'email' ),
			'captec_quote_email'         => array( 'default' => get_option( 'admin_email' ), 'kind' => 'email' ),
			'captec_instagram'           => array( 'default' => '', 'kind' => 'url' ),
			'captec_linkedin'            => array( 'default' => '', 'kind' => 'url' ),
			'captec_maps_url'            => array( 'default' => '', 'kind' => 'url' ),
			'captec_location_label'      => array( 'default' => 'Salvador/BA', 'kind' => 'text' ),
			'captec_menu_background_color' => array( 'default' => '#111111', 'kind' => 'color' ),
			'captec_menu_text_color'       => array( 'default' => '#FFFFFF', 'kind' => 'color' ),
			'captec_menu_font_size'        => array( 'default' => '13', 'kind' => 'menu_size' ),
			'captec_menu_font_family'      => array( 'default' => 'inter', 'kind' => 'menu_font' ),
			'captec_menu_mode'             => array( 'default' => 'scroll', 'kind' => 'menu_mode' ),
			'captec_menu_overlay_opacity'  => array( 'default' => '92', 'kind' => 'opacity' ),
			'captec_menu_logo_size'        => array( 'default' => '224', 'kind' => 'menu_logo_size' ),
			'captec_footer_logo_size'      => array( 'default' => '164', 'kind' => 'footer_logo_size' ),
			'captec_page_background_color' => array( 'default' => '#FFFFFF', 'kind' => 'page_background_color' ),
			'captec_page_surface_color'    => array( 'default' => '#F4F4F4', 'kind' => 'page_surface_color' ),
			'captec_page_bar_color'        => array( 'default' => '#111111', 'kind' => 'page_bar_color' ),
			'captec_page_bar_text_color'   => array( 'default' => '#FFFFFF', 'kind' => 'page_bar_text_color' ),
			'captec_site_width'            => array( 'default' => '1360', 'kind' => 'site_width' ),
			'captec_page_gutter'           => array( 'default' => '80', 'kind' => 'page_gutter' ),
			'captec_section_spacing'       => array( 'default' => '120', 'kind' => 'section_spacing' ),
			'captec_header_height'         => array( 'default' => '92', 'kind' => 'header_height' ),
			'captec_menu_item_gap'         => array( 'default' => '22', 'kind' => 'menu_gap' ),
			'captec_footer_spacing'        => array( 'default' => '74', 'kind' => 'footer_spacing' ),
			'captec_active_states'       => array( 'default' => '', 'kind' => 'states' ),
			'captec_privacy_url'         => array( 'default' => '', 'kind' => 'url' ),
			'captec_cookie_url'          => array( 'default' => '', 'kind' => 'url' ),
			'captec_ga4_id'              => array( 'default' => '', 'kind' => 'tracking' ),
			'captec_meta_pixel_id'       => array( 'default' => '', 'kind' => 'pixel' ),
			'captec_stat_1_label'        => array( 'default' => 'Clientes Atendidos', 'kind' => 'text' ),
			'captec_stat_1_value'        => array( 'default' => '', 'kind' => 'text' ),
			'captec_stat_2_label'        => array( 'default' => 'Estados Atendidos', 'kind' => 'text' ),
			'captec_stat_2_value'        => array( 'default' => '', 'kind' => 'text' ),
			'captec_stat_3_label'        => array( 'default' => 'Produtos Comercializados', 'kind' => 'text' ),
			'captec_stat_3_value'        => array( 'default' => '', 'kind' => 'text' ),
			'captec_stat_4_label'        => array( 'default' => 'Obras Atendidas', 'kind' => 'text' ),
			'captec_stat_4_value'        => array( 'default' => '', 'kind' => 'text' ),
			'captec_stat_5_label'        => array( 'default' => 'Toneladas Fornecidas', 'kind' => 'text' ),
			'captec_stat_5_value'        => array( 'default' => '', 'kind' => 'text' ),

			// Textos dos blocos institucionais da Home — editáveis pelo Portal CAPTEC.
			'captec_hero_card_1_title'   => array( 'default' => 'Produtos de Qualidade', 'kind' => 'text' ),
			'captec_hero_card_1_text'    => array( 'default' => 'Soluções alinhadas ao projeto', 'kind' => 'text' ),
			'captec_hero_card_2_title'   => array( 'default' => 'Atendimento Especializado', 'kind' => 'text' ),
			'captec_hero_card_2_text'    => array( 'default' => 'Escuta e orientação comercial', 'kind' => 'text' ),
			'captec_hero_card_3_title'   => array( 'default' => 'Logística Eficiente', 'kind' => 'text' ),
			'captec_hero_card_3_text'    => array( 'default' => 'Planejamento para cada demanda', 'kind' => 'text' ),
			'captec_hero_card_4_title'   => array( 'default' => 'Suporte Comercial', 'kind' => 'text' ),
			'captec_hero_card_4_text'    => array( 'default' => 'Acompanhamento do início ao pós-venda', 'kind' => 'text' ),
			'captec_hero_kicker'         => array( 'default' => 'Produtos asfálticos para infraestrutura', 'kind' => 'text' ),
			'captec_hero_quote_label'    => array( 'default' => 'Solicitar Cotação', 'kind' => 'text' ),
			'captec_hero_whatsapp_label' => array( 'default' => 'Falar pelo WhatsApp', 'kind' => 'text' ),
			'captec_hero_scroll_label'   => array( 'default' => 'Conheça a CAPTEC', 'kind' => 'text' ),
			'captec_about_badge_label'   => array( 'default' => 'Infraestrutura', 'kind' => 'text' ),
			'captec_about_badge_text'    => array( 'default' => 'com visão de parceria', 'kind' => 'text' ),
			'captec_about_pillar_1'      => array( 'default' => 'Foco na qualidade', 'kind' => 'text' ),
			'captec_about_pillar_2'      => array( 'default' => 'Relações de confiança', 'kind' => 'text' ),
			'captec_about_pillar_3'      => array( 'default' => 'Eficiência comercial', 'kind' => 'text' ),
			'captec_about_pillar_4'      => array( 'default' => 'Visão de longo prazo', 'kind' => 'text' ),
			'captec_products_eyebrow'    => array( 'default' => 'Portfólio', 'kind' => 'text' ),
			'captec_products_title'      => array( 'default' => 'Produtos para especificações que pedem precisão.', 'kind' => 'textarea' ),
			'captec_products_intro'      => array( 'default' => 'Conheça as soluções disponíveis e solicite uma cotação de acordo com as necessidades técnicas da sua obra.', 'kind' => 'textarea' ),
			'captec_products_bar_text'   => array( 'default' => 'Selecione um produto para enviar sua demanda comercial.', 'kind' => 'text' ),
			'captec_products_bar_cta'    => array( 'default' => 'Preciso de orientação', 'kind' => 'text' ),
			'captec_products_note'       => array( 'default' => 'A disponibilidade e a aplicação devem ser confirmadas na cotação, de acordo com a especificação da obra.', 'kind' => 'textarea' ),
			'captec_applications_eyebrow'=> array( 'default' => 'Onde a CAPTEC atua', 'kind' => 'text' ),
			'captec_applications_title'  => array( 'default' => 'Soluções que acompanham diferentes contextos de infraestrutura.', 'kind' => 'textarea' ),
			'captec_applications_intro'  => array( 'default' => 'Cada aplicação pede planejamento e produtos alinhados à sua especificação técnica.', 'kind' => 'textarea' ),
			'captec_differentials_eyebrow' => array( 'default' => 'Por que escolher a CAPTEC', 'kind' => 'text' ),
			'captec_differentials_title' => array( 'default' => 'Uma experiência comercial orientada para a sua obra.', 'kind' => 'textarea' ),
			'captec_differentials_intro' => array( 'default' => 'Mais clareza em cada etapa, para que a sua equipe avance com segurança na tomada de decisão.', 'kind' => 'textarea' ),
			'captec_differential_1_title'=> array( 'default' => 'Atendimento Consultivo', 'kind' => 'text' ),
			'captec_differential_1_text' => array( 'default' => 'Entendimento da demanda antes da construção da proposta.', 'kind' => 'textarea' ),
			'captec_differential_2_title'=> array( 'default' => 'Equipe Comercial Especializada', 'kind' => 'text' ),
			'captec_differential_2_text' => array( 'default' => 'Comunicação objetiva para apoiar a rotina de compras e obras.', 'kind' => 'textarea' ),
			'captec_differential_3_title'=> array( 'default' => 'Qualidade dos Produtos', 'kind' => 'text' ),
			'captec_differential_3_text' => array( 'default' => 'Portfólio apresentado de acordo com a especificação solicitada.', 'kind' => 'textarea' ),
			'captec_differential_4_title'=> array( 'default' => 'Agilidade nas Cotações', 'kind' => 'text' ),
			'captec_differential_4_text' => array( 'default' => 'Fluxo comercial organizado para dar visibilidade à solicitação.', 'kind' => 'textarea' ),
			'captec_differential_5_title'=> array( 'default' => 'Planejamento Logístico', 'kind' => 'text' ),
			'captec_differential_5_text' => array( 'default' => 'Programação alinhada à necessidade informada no pedido.', 'kind' => 'textarea' ),
			'captec_differential_6_title'=> array( 'default' => 'Relacionamento de Longo Prazo', 'kind' => 'text' ),
			'captec_differential_6_text' => array( 'default' => 'Proximidade e acompanhamento que valorizam a parceria.', 'kind' => 'textarea' ),
			'captec_process_eyebrow'     => array( 'default' => 'Processo', 'kind' => 'text' ),
			'captec_process_title'       => array( 'default' => 'Do primeiro contato ao pós-venda, com mais clareza.', 'kind' => 'textarea' ),
			'captec_process_intro'       => array( 'default' => 'Um caminho comercial pensado para tornar a solicitação mais simples e o acompanhamento mais próximo.', 'kind' => 'textarea' ),
			'captec_process_1_title'     => array( 'default' => 'Contato', 'kind' => 'text' ),
			'captec_process_1_text'      => array( 'default' => 'Você compartilha os dados iniciais da sua necessidade.', 'kind' => 'textarea' ),
			'captec_process_2_title'     => array( 'default' => 'Cotação', 'kind' => 'text' ),
			'captec_process_2_text'      => array( 'default' => 'A demanda é analisada para construção da proposta comercial.', 'kind' => 'textarea' ),
			'captec_process_3_title'     => array( 'default' => 'Negociação', 'kind' => 'text' ),
			'captec_process_3_text'      => array( 'default' => 'Alinhamos as condições e os pontos relevantes do fornecimento.', 'kind' => 'textarea' ),
			'captec_process_4_title'     => array( 'default' => 'Programação', 'kind' => 'text' ),
			'captec_process_4_text'      => array( 'default' => 'A entrega é organizada conforme o pedido confirmado.', 'kind' => 'textarea' ),
			'captec_process_5_title'     => array( 'default' => 'Entrega', 'kind' => 'text' ),
			'captec_process_5_text'      => array( 'default' => 'Acompanhamos a etapa de fornecimento combinada.', 'kind' => 'textarea' ),
			'captec_process_6_title'     => array( 'default' => 'Pós-venda', 'kind' => 'text' ),
			'captec_process_6_text'      => array( 'default' => 'Mantemos o canal aberto para continuidade do relacionamento.', 'kind' => 'textarea' ),
			'captec_stats_eyebrow'       => array( 'default' => 'Indicadores', 'kind' => 'text' ),
			'captec_stats_title'         => array( 'default' => 'Indicadores que refletem nossa atuação', 'kind' => 'textarea' ),
			'captec_stats_intro'         => array( 'default' => 'A transparência faz parte do nosso compromisso com clientes, parceiros e colaboradores. Nesta seção, apresentamos os principais indicadores da empresa, reunindo números que demonstram nossa capacidade de atendimento, presença nacional, portfólio de produtos e volume de fornecimento.', 'kind' => 'textarea' ),
			'captec_map_eyebrow'         => array( 'default' => 'Cobertura', 'kind' => 'text' ),
			'captec_map_title'           => array( 'default' => 'Uma conversa começa onde a sua obra está.', 'kind' => 'textarea' ),
			'captec_map_intro'           => array( 'default' => 'Use o mapa como referência visual e entre em contato para verificar a disponibilidade de atendimento para sua localidade e demanda.', 'kind' => 'textarea' ),
			'captec_map_status_message'  => array( 'default' => 'disponível para atendimento', 'kind' => 'text' ),
			'captec_map_feature_1'       => array( 'default' => 'Mapa interativo preparado para destaque de estados.', 'kind' => 'text' ),
			'captec_map_feature_2'       => array( 'default' => 'Estados configuráveis diretamente no Personalizar.', 'kind' => 'text' ),
			'captec_map_feature_3'       => array( 'default' => 'Consulta comercial sem compromisso.', 'kind' => 'text' ),
			'captec_blog_eyebrow'        => array( 'default' => 'Conteúdos', 'kind' => 'text' ),
			'captec_blog_title'          => array( 'default' => 'Informação técnica para decisões mais claras.', 'kind' => 'textarea' ),
			'captec_blog_cta'            => array( 'default' => 'Ver todos os artigos', 'kind' => 'text' ),
			'captec_quote_eyebrow'       => array( 'default' => 'Fale com a CAPTEC', 'kind' => 'text' ),
			'captec_quote_title'         => array( 'default' => 'Vamos entender a sua demanda.', 'kind' => 'textarea' ),
			'captec_quote_text'          => array( 'default' => 'Envie as informações da obra. Quanto mais contexto você compartilhar, mais objetiva será a análise comercial.', 'kind' => 'textarea' ),
			'captec_quote_form_title'    => array( 'default' => 'Solicitar cotação', 'kind' => 'text' ),
			'captec_footer_text'         => array( 'default' => 'Soluções inteligentes para pavimentação e infraestrutura, com atendimento consultivo e foco em eficiência.', 'kind' => 'textarea' ),
		);
	}

	private function draft_settings() {
		$draft = get_option( 'captec_portal_draft_settings', array() );
		return is_array( $draft ) ? $draft : array();
	}

	private function settings() {
		$settings = array();
		$draft = $this->draft_settings();
		foreach ( $this->setting_schema() as $key => $definition ) {
			if ( array_key_exists( $key, $draft ) ) {
				$value = $draft[ $key ];
			} elseif ( 'option_text' === $definition['kind'] ) {
				$value = get_option( 'site_title' === $key ? 'blogname' : 'blogdescription', $definition['default'] );
			} elseif ( 'logo' === $definition['kind'] ) {
				$value = absint( get_theme_mod( 'custom_logo', 0 ) );
			} else {
				$value = get_theme_mod( $key, $definition['default'] );
			}
			$settings[ $key ] = $value;
			if ( 'logo' === $definition['kind'] ) {
				$logo_id = absint( $value );
				$settings['custom_logo_url'] = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
			}
		}
		return $settings;
	}

	private function sanitize_setting( $value, $kind ) {
		switch ( $kind ) {
			case 'textarea':
				return sanitize_textarea_field( (string) $value );
			case 'url':
				return esc_url_raw( (string) $value );
			case 'email':
				return sanitize_email( (string) $value );
			case 'phone':
				return preg_replace( '/[^0-9+()\-\s]/', '', (string) $value );
			case 'states':
				$value = strtoupper( preg_replace( '/[^A-Za-z,\s]/', '', (string) $value ) );
				$parts = array_filter( array_map( 'trim', explode( ',', $value ) ) );
				return implode( ', ', array_unique( $parts ) );
			case 'tracking':
				return preg_replace( '/[^A-Za-z0-9\-_]/', '', (string) $value );
			case 'pixel':
				return preg_replace( '/\D+/', '', (string) $value );
			case 'color':
				$color = sanitize_hex_color( (string) $value );
				return $color ? $color : '#111111';
			case 'page_background_color':
				$color = sanitize_hex_color( (string) $value );
				return $color ? $color : '#FFFFFF';
			case 'page_surface_color':
				$color = sanitize_hex_color( (string) $value );
				return $color ? $color : '#F4F4F4';
			case 'page_bar_color':
				$color = sanitize_hex_color( (string) $value );
				return $color ? $color : '#111111';
			case 'page_bar_text_color':
				$color = sanitize_hex_color( (string) $value );
				return $color ? $color : '#FFFFFF';
			case 'site_width':
				return (string) min( 1800, max( 960, absint( $value ) ) );
			case 'page_gutter':
				return (string) min( 120, max( 16, absint( $value ) ) );
			case 'section_spacing':
				return (string) min( 190, max( 42, absint( $value ) ) );
			case 'header_height':
				return (string) min( 140, max( 64, absint( $value ) ) );
			case 'menu_gap':
				return (string) min( 42, max( 6, absint( $value ) ) );
			case 'footer_spacing':
				return (string) min( 150, max( 32, absint( $value ) ) );
			case 'menu_size':
				return (string) min( 24, max( 10, absint( $value ) ) );
			case 'menu_font':
				return in_array( $value, array( 'inter', 'poppins', 'system', 'serif' ), true ) ? $value : 'inter';
			case 'menu_mode':
				return in_array( $value, array( 'scroll', 'image', 'fixed' ), true ) ? $value : 'scroll';
			case 'opacity':
				return (string) min( 100, max( 35, absint( $value ) ) );
			case 'menu_logo_size':
				return (string) min( 320, max( 150, absint( $value ) ) );
			case 'footer_logo_size':
				return (string) min( 260, max( 90, absint( $value ) ) );
			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/** Slots visíveis de botões reutilizáveis no portal público. */
	private function button_slots() {
		return array(
			'header_quote'       => __( 'Cabeçalho — Solicitar cotação', 'captec-portal-admin' ),
			'hero_quote'         => __( 'Quem somos — botão principal', 'captec-portal-admin' ),
			'hero_whatsapp'      => __( 'Quem somos — botão WhatsApp', 'captec-portal-admin' ),
			'home_institutional' => __( 'Quem somos — chamada institucional', 'captec-portal-admin' ),
			'product_quote'      => __( 'Produtos — Solicitar cotação', 'captec-portal-admin' ),
			'applications_quote'  => __( 'Quem somos — Aplicações — Solicitar cotação', 'captec-portal-admin' ),
			'not_found_home'      => __( 'Página 404 — Voltar para Quem somos', 'captec-portal-admin' ),
			'coverage_whatsapp'  => __( 'Cobertura — WhatsApp', 'captec-portal-admin' ),
			'coverage_quote'     => __( 'Cobertura — Solicitar cotação', 'captec-portal-admin' ),
			'careers_email'      => __( 'Trabalhe conosco — Enviar currículo', 'captec-portal-admin' ),
			'quote_submit'       => __( 'Cotação — Enviar formulário', 'captec-portal-admin' ),
			'floating_whatsapp'  => __( 'Botão flutuante — WhatsApp', 'captec-portal-admin' ),
			'footer_custom_1'  => __( 'Rodapé — botão adicional 1', 'captec-portal-admin' ),
			'footer_custom_2'  => __( 'Rodapé — botão adicional 2', 'captec-portal-admin' ),
			'footer_custom_3'  => __( 'Rodapé — botão adicional 3', 'captec-portal-admin' ),
		);
	}

	private function footer_sections() {
		return array(
			'navigation'    => __( 'Navegação', 'captec-portal-admin' ),
			'atendimento'   => __( 'Atendimento', 'captec-portal-admin' ),
			'institucional' => __( 'Institucional', 'captec-portal-admin' ),
			'bottom'        => __( 'Rodapé inferior', 'captec-portal-admin' ),
		);
	}

	private function content_type_has_records( $post_type ) {
		if ( ! post_type_exists( $post_type ) ) {
			return false;
		}
		$records = get_posts( array(
			'post_type'      => $post_type,
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		) );
		return ! empty( $records );
	}

	private function insert_presentation_record( $post_type, $item, $order ) {
		$post_id = wp_insert_post( array(
			'post_type'   => $post_type,
			'post_status' => 'publish',
			'post_title'  => sanitize_text_field( $item['title'] ),
			'menu_order'  => absint( $order ),
		), true );
		if ( is_wp_error( $post_id ) || ! $post_id ) {
			return 0;
		}
		foreach ( (array) $item['meta'] as $key => $value ) {
			update_post_meta( $post_id, $key, $value );
		}
		return (int) $post_id;
	}

	private function default_site_buttons() {
		$hero_quote = get_theme_mod( 'captec_hero_quote_label', 'Solicitar Cotação' );
		$hero_whatsapp = get_theme_mod( 'captec_hero_whatsapp_label', 'Falar pelo WhatsApp' );
		$careers = get_theme_mod( 'captec_careers_button_label', 'Enviar currículo' );
		$quote_form = get_theme_mod( 'captec_quote_form_title', 'Solicitar cotação' );
		return array(
			array( 'title' => 'Cabeçalho — Solicitar cotação', 'meta' => array( '_captec_button_slot' => 'header_quote', '_captec_button_label' => 'Solicitar cotação', '_captec_button_action' => 'quote', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Quem somos — botão principal', 'meta' => array( '_captec_button_slot' => 'hero_quote', '_captec_button_label' => $hero_quote, '_captec_button_action' => 'quote', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Quem somos — botão WhatsApp', 'meta' => array( '_captec_button_slot' => 'hero_whatsapp', '_captec_button_label' => $hero_whatsapp, '_captec_button_action' => 'whatsapp', '_captec_button_url' => '', '_captec_button_style' => 'ghost', '_captec_button_target' => 'new' ) ),
			array( 'title' => 'Quem somos — chamada institucional', 'meta' => array( '_captec_button_slot' => 'home_institutional', '_captec_button_label' => 'Fale com a CAPTEC', '_captec_button_action' => 'quote', '_captec_button_url' => '', '_captec_button_style' => 'dark', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Produtos — Solicitar cotação', 'meta' => array( '_captec_button_slot' => 'product_quote', '_captec_button_label' => 'Solicitar cotação', '_captec_button_action' => 'quote', '_captec_button_url' => '', '_captec_button_style' => 'line', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Quem somos — Aplicações — Solicitar cotação', 'meta' => array( '_captec_button_slot' => 'applications_quote', '_captec_button_label' => 'Solicitar cotação', '_captec_button_action' => 'quote', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Página 404 — Voltar para Quem somos', 'meta' => array( '_captec_button_slot' => 'not_found_home', '_captec_button_label' => 'Ir para Quem somos', '_captec_button_action' => 'url', '_captec_button_url' => home_url( '/' ), '_captec_button_style' => 'yellow', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Cobertura — WhatsApp', 'meta' => array( '_captec_button_slot' => 'coverage_whatsapp', '_captec_button_label' => 'Falar pelo WhatsApp', '_captec_button_action' => 'whatsapp', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'new' ) ),
			array( 'title' => 'Cobertura — Solicitar cotação', 'meta' => array( '_captec_button_slot' => 'coverage_quote', '_captec_button_label' => 'Solicitar cotação', '_captec_button_action' => 'quote', '_captec_button_url' => '', '_captec_button_style' => 'line', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Trabalhe conosco — Enviar currículo', 'meta' => array( '_captec_button_slot' => 'careers_email', '_captec_button_label' => $careers, '_captec_button_action' => 'career_email', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Cotação — Enviar formulário', 'meta' => array( '_captec_button_slot' => 'quote_submit', '_captec_button_label' => $quote_form, '_captec_button_action' => 'url', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'same' ) ),
			array( 'title' => 'Botão flutuante — WhatsApp', 'meta' => array( '_captec_button_slot' => 'floating_whatsapp', '_captec_button_label' => 'Falar pelo WhatsApp', '_captec_button_action' => 'whatsapp', '_captec_button_url' => '', '_captec_button_style' => 'yellow', '_captec_button_target' => 'new' ) ),
		);
	}

	private function default_footer_items() {
		$phone = get_theme_mod( 'captec_phone', '' ) ?: __( 'Telefone', 'captec-portal-admin' );
		return array(
			array( 'title' => 'Navegação — Quem somos', 'meta' => array( '_captec_footer_section' => 'navigation', '_captec_footer_label' => 'Quem somos', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'home', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Navegação — Produtos', 'meta' => array( '_captec_footer_section' => 'navigation', '_captec_footer_label' => 'Produtos', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'url', '_captec_footer_url' => home_url( '/produtos/' ), '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Navegação — Unidades', 'meta' => array( '_captec_footer_section' => 'navigation', '_captec_footer_label' => 'Unidades', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'url', '_captec_footer_url' => home_url( '/unidades/' ), '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Navegação — Cobertura', 'meta' => array( '_captec_footer_section' => 'navigation', '_captec_footer_label' => 'Cobertura', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'url', '_captec_footer_url' => home_url( '/cobertura/' ), '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Navegação — Conteúdos', 'meta' => array( '_captec_footer_section' => 'navigation', '_captec_footer_label' => 'Conteúdos', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'url', '_captec_footer_url' => home_url( '/blog/' ), '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Navegação — Trabalhe conosco', 'meta' => array( '_captec_footer_section' => 'navigation', '_captec_footer_label' => 'Trabalhe conosco', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'url', '_captec_footer_url' => home_url( '/trabalhe-conosco/' ), '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Atendimento — Telefone', 'meta' => array( '_captec_footer_section' => 'atendimento', '_captec_footer_label' => $phone, '_captec_footer_kind' => 'link', '_captec_footer_action' => 'phone', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Atendimento — WhatsApp', 'meta' => array( '_captec_footer_section' => 'atendimento', '_captec_footer_label' => 'Falar pelo WhatsApp', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'whatsapp', '_captec_footer_url' => '', '_captec_footer_target' => 'new' ) ),
			array( 'title' => 'Atendimento — E-mail', 'meta' => array( '_captec_footer_section' => 'atendimento', '_captec_footer_label' => 'E-mail comercial', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'email', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Atendimento — Cotação', 'meta' => array( '_captec_footer_section' => 'atendimento', '_captec_footer_label' => 'Solicitar cotação', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'quote', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Institucional — Privacidade', 'meta' => array( '_captec_footer_section' => 'institucional', '_captec_footer_label' => 'Política de Privacidade', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'privacy', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Institucional — Cookies', 'meta' => array( '_captec_footer_section' => 'institucional', '_captec_footer_label' => 'Política de Cookies', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'cookies', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Institucional — Google Maps', 'meta' => array( '_captec_footer_section' => 'institucional', '_captec_footer_label' => 'Google Maps', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'maps', '_captec_footer_url' => '', '_captec_footer_target' => 'new' ) ),
			array( 'title' => 'Rodapé inferior — Privacidade', 'meta' => array( '_captec_footer_section' => 'bottom', '_captec_footer_label' => 'Privacidade', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'privacy', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
			array( 'title' => 'Rodapé inferior — Cookies', 'meta' => array( '_captec_footer_section' => 'bottom', '_captec_footer_label' => 'Cookies', '_captec_footer_kind' => 'link', '_captec_footer_action' => 'cookies', '_captec_footer_url' => '', '_captec_footer_target' => 'same' ) ),
		);
	}

	private function default_indicators() {
		return array(
			'Clientes Atendidos',
			'Estados Atendidos',
			'Produtos Comercializados',
			'Obras Atendidas',
			'Toneladas Fornecidas',
		);
	}

	private function seed_default_indicators() {
		$records = get_posts( array(
			'post_type'      => 'captec_stat',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'orderby'        => 'menu_order',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		) );
		$existing = array();
		foreach ( $records as $record ) {
			$label = get_post_meta( $record->ID, '_captec_stat_label', true ) ?: get_the_title( $record );
			$existing[ sanitize_title( $label ) ] = $record;
		}
		foreach ( $this->default_indicators() as $order => $label ) {
			$key = sanitize_title( $label );
			if ( isset( $existing[ $key ] ) ) {
				if ( 'publish' !== $existing[ $key ]->post_status ) {
					wp_update_post( array( 'ID' => $existing[ $key ]->ID, 'post_status' => 'publish' ) );
				}
				continue;
			}
			$this->insert_presentation_record( 'captec_stat', array( 'title' => $label, 'meta' => array( '_captec_stat_label' => $label, '_captec_stat_value' => '' ) ), $order );
		}
		update_option( 'captec_stats_configured', 1, false );
	}

	private function apply_requested_indicator_texts() {
		if ( self::PRESENTATION_VERSION === get_option( 'captec_indicator_text_version' ) ) {
			return;
		}
		$values = array(
			'captec_stats_eyebrow' => 'Indicadores',
			'captec_stats_title'   => 'Indicadores que refletem nossa atuação',
			'captec_stats_intro'   => 'A transparência faz parte do nosso compromisso com clientes, parceiros e colaboradores. Nesta seção, apresentamos os principais indicadores da empresa, reunindo números que demonstram nossa capacidade de atendimento, presença nacional, portfólio de produtos e volume de fornecimento.',
		);
		$draft = get_option( 'captec_portal_draft_settings', array() );
		foreach ( $values as $key => $value ) {
			set_theme_mod( $key, $value );
			if ( is_array( $draft ) && array_key_exists( $key, $draft ) ) {
				unset( $draft[ $key ] );
			}
		}
		if ( is_array( $draft ) ) {
			update_option( 'captec_portal_draft_settings', $draft, false );
		}
		update_option( 'captec_indicator_text_version', self::PRESENTATION_VERSION, false );
	}

	private function migrate_legacy_stats() {
		if ( $this->content_type_has_records( 'captec_stat' ) ) {
			return;
		}
		$created = 0;
		for ( $index = 1; $index <= 5; $index++ ) {
			$label = sanitize_text_field( get_theme_mod( 'captec_stat_' . $index . '_label', '' ) );
			$value = sanitize_text_field( get_theme_mod( 'captec_stat_' . $index . '_value', '' ) );
			if ( '' === $label && '' === $value ) {
				continue;
			}
			if ( ! $label ) {
				$label = sprintf( __( 'Indicador %d', 'captec-portal-admin' ), $index );
			}
			$this->insert_presentation_record( 'captec_stat', array( 'title' => $label, 'meta' => array( '_captec_stat_label' => $label, '_captec_stat_value' => $value ) ), $index - 1 );
			$created++;
		}
		if ( $created ) {
			update_option( 'captec_stats_configured', 1, false );
		}
	}

	/** Prepara botões, itens de rodapé e migra indicadores já salvos no tema. */
	public function maybe_seed_presentation_content() {
		if ( self::PRESENTATION_VERSION === get_option( 'captec_presentation_version' ) ) {
			return;
		}
		if ( ! post_type_exists( 'captec_button' ) || ! post_type_exists( 'captec_footer_item' ) || ! post_type_exists( 'captec_stat' ) ) {
			return;
		}
		if ( ! $this->content_type_has_records( 'captec_button' ) ) {
			foreach ( $this->default_site_buttons() as $order => $button ) {
				$this->insert_presentation_record( 'captec_button', $button, $order );
			}
		}
		if ( ! $this->content_type_has_records( 'captec_footer_item' ) ) {
			foreach ( $this->default_footer_items() as $order => $item ) {
				$this->insert_presentation_record( 'captec_footer_item', $item, $order );
			}
			update_option( 'captec_footer_configured_sections', array_keys( $this->footer_sections() ), false );
		}
		$this->migrate_legacy_stats();
		$this->seed_default_indicators();
		$this->apply_requested_indicator_texts();
		update_option( 'captec_presentation_version', self::PRESENTATION_VERSION, false );
	}

	private function article_categories() {
		$terms = get_categories( array( 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
		$items = array();
		foreach ( $terms as $term ) {
			$items[] = array( 'id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug );
		}
		return $items;
	}

	private function ensure_article_category( $name ) {
		$name = sanitize_text_field( $name );
		if ( ! $name ) {
			return 0;
		}
		$term = term_exists( $name, 'category' );
		if ( ! $term ) {
			$term = wp_insert_term( $name, 'category' );
		}
		if ( is_wp_error( $term ) || ! $term ) {
			return 0;
		}
		return is_array( $term ) ? absint( $term['term_id'] ) : absint( $term );
	}

	private function topic_image_filename( $topic_id ) {
		$images = array(
			'anp-897-produtos-2026'   => 'app-highways.jpg',
			'dnit-385-2026'           => 'hero-paving.jpg',
			'dnit-035-2026'           => 'app-urban.jpg',
			'manutencao-seguranca-2026' => 'app-concession.jpg',
			'cap-emulsao-guia'        => 'app-industrial.jpg',
			'pintura-ligacao'         => 'hero-paving.jpg',
			'logistica-asfaltos'      => 'app-industrial.jpg',
			'mapas-geotransportes'    => 'app-highways.jpg',
			'ficha-tecnica'           => 'app-municipal.jpg',
			'controle-recebimento'    => 'app-condo.jpg',
		);
		return isset( $images[ $topic_id ] ) ? $images[ $topic_id ] : 'hero-paving.jpg';
	}

	private function topic_image_url( $topic_id ) {
		$filename = $this->topic_image_filename( $topic_id );
		$path = get_template_directory() . '/assets/images/' . $filename;
		return file_exists( $path ) ? get_template_directory_uri() . '/assets/images/' . $filename : '';
	}

	private function attach_topic_image( $post_id, $topic_id ) {
		if ( has_post_thumbnail( $post_id ) ) {
			return (int) get_post_thumbnail_id( $post_id );
		}
		$filename = $this->topic_image_filename( $topic_id );
		$source = get_template_directory() . '/assets/images/' . $filename;
		if ( ! is_readable( $source ) ) {
			return 0;
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$contents = file_get_contents( $source ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $contents ) {
			return 0;
		}
		$file = wp_upload_bits( 'captec-' . sanitize_file_name( $topic_id ) . '-' . $filename, null, $contents );
		if ( ! empty( $file['error'] ) || empty( $file['file'] ) ) {
			return 0;
		}
		$filetype = wp_check_filetype( basename( $file['file'] ), null );
		$attachment_id = wp_insert_attachment( array(
			'post_mime_type' => $filetype['type'],
			'post_title'     => sanitize_text_field( get_the_title( $post_id ) ),
			'post_status'    => 'inherit',
		), $file['file'], $post_id, true );
		if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
			return 0;
		}
		$metadata = wp_generate_attachment_metadata( $attachment_id, $file['file'] );
		if ( $metadata ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}
		update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( get_the_title( $post_id ) ) );
		set_post_thumbnail( $post_id, $attachment_id );
		return (int) $attachment_id;
	}

	private function post_type_for( $type ) {
		$map = array(
			'product'     => 'captec_product',
			'application' => 'captec_application',
			'location'    => 'captec_location',
			'article'     => 'post',
			'page'        => 'page',
			'quote'       => 'captec_quote',
			'button'      => 'captec_button',
			'footer_item' => 'captec_footer_item',
			'stat'        => 'captec_stat',
		);
		return isset( $map[ $type ] ) ? $map[ $type ] : '';
	}

	private function serialize_item( $post, $type ) {
		$post = get_post( $post );
		if ( ! $post ) {
			return null;
		}
		$image_id = get_post_thumbnail_id( $post->ID );
		$data = array(
			'id'         => (int) $post->ID,
			'type'       => $type,
			'title'      => get_the_title( $post ),
			'content'    => (string) $post->post_content,
			'excerpt'    => (string) $post->post_excerpt,
			'status'     => (string) $post->post_status,
			'order'      => (int) $post->menu_order,
			'date'       => get_the_date( DATE_ATOM, $post ),
			'modified'   => get_post_modified_time( DATE_ATOM, false, $post ),
			'image_id'   => (int) $image_id,
			'image_url'  => $image_id ? wp_get_attachment_image_url( $image_id, 'medium_large' ) : '',
			'edit_url'   => get_edit_post_link( $post->ID, 'raw' ),
		);

		if ( 'product' === $type ) {
			$data['product_type'] = get_post_meta( $post->ID, '_captec_product_type', true );
			$data['description']  = get_post_meta( $post->ID, '_captec_product_description', true );
			$data['applications'] = get_post_meta( $post->ID, '_captec_product_applications', true );
			$data['file_url']     = get_post_meta( $post->ID, '_captec_product_file', true );
		}
		if ( 'application' === $type ) {
			$data['subtitle'] = get_post_meta( $post->ID, '_captec_application_subtitle', true );
		}
		if ( 'button' === $type ) {
			foreach ( array( 'slot', 'label', 'action', 'url', 'style', 'target', 'position' ) as $key ) {
				$data[ $key ] = get_post_meta( $post->ID, '_captec_button_' . $key, true );
			}
		}
		if ( 'footer_item' === $type ) {
			foreach ( array( 'section', 'label', 'kind', 'action', 'url', 'target' ) as $key ) {
				$data[ $key ] = get_post_meta( $post->ID, '_captec_footer_' . $key, true );
			}
		}
		if ( 'stat' === $type ) {
			$data['label'] = get_post_meta( $post->ID, '_captec_stat_label', true );
			$data['value'] = get_post_meta( $post->ID, '_captec_stat_value', true );
		}
		if ( 'location' === $type ) {
			$keys = array( 'kind', 'company_name', 'cnpj', 'street', 'number', 'complement', 'neighborhood', 'city', 'state', 'cep', 'phone', 'email', 'map_url' );
			foreach ( $keys as $key ) {
				$data[ $key ] = get_post_meta( $post->ID, '_captec_location_' . $key, true );
			}
		}
		if ( 'page' === $type ) {
			$data['slug'] = $post->post_name;
			$data['template'] = get_page_template_slug( $post->ID );
		}
		if ( 'article' === $type ) {
			$data['categories'] = wp_get_post_categories( $post->ID );
			$data['category_names'] = wp_get_post_categories( $post->ID, array( 'fields' => 'names' ) );
			$data['category_id'] = ! empty( $data['categories'] ) ? (int) $data['categories'][0] : 0;
		}
		if ( 'quote' === $type ) {
			$keys = array( 'name', 'company', 'phone', 'whatsapp', 'city', 'state', 'product', 'quantity', 'message', 'file_url', 'lgpd_consent_at' );
			foreach ( $keys as $key ) {
				$data[ $key ] = get_post_meta( $post->ID, '_captec_quote_' . $key, true );
			}
			$data['workflow_status'] = get_post_meta( $post->ID, '_captec_quote_status', true ) ?: 'new';
			$data['internal_note']   = get_post_meta( $post->ID, '_captec_quote_internal_note', true );
			$data['mail_status']     = get_post_meta( $post->ID, '_captec_quote_mail_status', true );
		}
		return $data;
	}

	private function list_items( $type, $limit = -1 ) {
		$post_type = $this->post_type_for( $type );
		if ( ! $post_type || ! post_type_exists( $post_type ) ) {
			return array();
		}
		$query = new WP_Query( array(
			'post_type'      => $post_type,
			'post_status'    => 'quote' === $type ? array( 'private', 'publish' ) : array( 'publish', 'draft' ),
			'posts_per_page' => $limit,
			'orderby'        => in_array( $type, array( 'product', 'application', 'location', 'page', 'button', 'footer_item', 'stat' ), true ) ? 'menu_order' : 'date',
			'order'          => in_array( $type, array( 'product', 'application', 'location', 'page', 'button', 'footer_item', 'stat' ), true ) ? 'ASC' : 'DESC',
			'no_found_rows'  => true,
		) );
		$items = array();
		foreach ( $query->posts as $post ) {
			$serialized = $this->serialize_item( $post, $type );
			if ( $serialized ) {
				$items[] = $serialized;
			}
		}
		return $items;
	}

	private function count_posts( $post_type, $status = 'publish' ) {
		if ( ! post_type_exists( $post_type ) ) {
			return 0;
		}
		$counts = wp_count_posts( $post_type );
		return isset( $counts->$status ) ? (int) $counts->$status : 0;
	}

	private function indicators_ready() {
		if ( post_type_exists( 'captec_stat' ) ) {
			foreach ( $this->list_items( 'stat' ) as $stat ) {
				if ( 'publish' === $stat['status'] && ! empty( $stat['value'] ) ) {
					return true;
				}
			}
		}
		return ! empty( get_theme_mod( 'captec_stat_1_value', '' ) ) && ! empty( get_theme_mod( 'captec_stat_2_value', '' ) );
	}

	private function dashboard() {
		$settings = $this->settings();
		$checks = array(
			array( 'label' => __( 'Logo oficial', 'captec-portal-admin' ), 'complete' => ! empty( $settings['custom_logo_id'] ), 'view' => 'brand' ),
			array( 'label' => __( 'Canais de contato', 'captec-portal-admin' ), 'complete' => ! empty( $settings['captec_whatsapp'] ) && ! empty( $settings['captec_email'] ), 'view' => 'brand' ),
			array( 'label' => __( 'Indicadores validados', 'captec-portal-admin' ), 'complete' => $this->indicators_ready(), 'view' => 'coverage' ),
			array( 'label' => __( 'Políticas legais', 'captec-portal-admin' ), 'complete' => ! empty( $settings['captec_privacy_url'] ) && ! empty( $settings['captec_cookie_url'] ), 'view' => 'integrations' ),
			array( 'label' => __( 'Páginas do portal', 'captec-portal-admin' ), 'complete' => $this->portal_pages_ready(), 'view' => 'pages' ),
		);
		$complete = 0;
		foreach ( $checks as $check ) {
			if ( $check['complete'] ) {
				++$complete;
			}
		}
		return array(
			'cards' => array(
				array( 'key' => 'products', 'label' => __( 'Produtos no catálogo', 'captec-portal-admin' ), 'value' => $this->count_posts( 'captec_product' ), 'icon' => 'layers', 'view' => 'products' ),
				array( 'key' => 'applications', 'label' => __( 'Aplicações cadastradas', 'captec-portal-admin' ), 'value' => $this->count_posts( 'captec_application' ), 'icon' => 'map', 'view' => 'applications' ),
				array( 'key' => 'locations', 'label' => __( 'Matriz e filiais', 'captec-portal-admin' ), 'value' => $this->count_posts( 'captec_location' ), 'icon' => 'pin', 'view' => 'locations' ),
				array( 'key' => 'quotes', 'label' => __( 'Cotações recebidas', 'captec-portal-admin' ), 'value' => $this->count_posts( 'captec_quote', 'private' ), 'icon' => 'inbox', 'view' => 'quotes' ),
				array( 'key' => 'articles', 'label' => __( 'Artigos publicados', 'captec-portal-admin' ), 'value' => $this->count_posts( 'post' ), 'icon' => 'document', 'view' => 'content' ),
			),
			'checks'       => $checks,
			'completion'   => count( $checks ) ? (int) round( ( $complete / count( $checks ) ) * 100 ) : 0,
			'theme_ready'  => function_exists( 'captec_products' ) || 'captec-asfaltos' === wp_get_theme()->get( 'TextDomain' ),
			'theme_name'   => wp_get_theme()->get( 'Name' ),
			'last_updated' => current_time( 'c' ),
		);
	}

	private function portal_page_definitions() {
		return array(
			array( 'slug' => 'inicio', 'title' => __( 'Quem somos', 'captec-portal-admin' ), 'template' => '' ),
			array( 'slug' => 'produtos', 'title' => __( 'Produtos', 'captec-portal-admin' ), 'template' => 'page-produtos.php' ),
			array( 'slug' => 'unidades', 'title' => __( 'Unidades', 'captec-portal-admin' ), 'template' => 'page-unidades.php' ),
			array( 'slug' => 'cobertura', 'title' => __( 'Cobertura', 'captec-portal-admin' ), 'template' => 'page-cobertura.php' ),
			array( 'slug' => 'blog', 'title' => __( 'Conteúdos', 'captec-portal-admin' ), 'template' => '' ),
			array( 'slug' => 'trabalhe-conosco', 'title' => __( 'Trabalhe conosco', 'captec-portal-admin' ), 'template' => 'page-trabalhe-conosco.php' ),
			array( 'slug' => 'cotacao', 'title' => __( 'Solicitar Cotação', 'captec-portal-admin' ), 'template' => 'page-cotacao.php' ),
		);
	}

	/** Conteúdos padrão que ficam visíveis no editor nativo de Páginas. */
	private function default_portal_page_content( $slug ) {
		$contents = array(
			'inicio' => "[captec_quem_somos]\n\n[captec_aplicacoes]\n\n[captec_diferenciais]",
			'produtos' => '<p>Portfólio de produtos asfálticos apresentado de acordo com as necessidades e especificações da obra.</p>',
			'unidades' => '<p>Dados cadastrais e canais de contato das unidades CAPTEC.</p>',
			'cobertura' => '<p>Indicadores institucionais, mapa de cobertura e canais para verificar atendimento.</p>',
			'blog' => '<p>Artigos e referências para apoiar conversas sobre pavimentação, produtos e infraestrutura.</p>',
			'trabalhe-conosco' => '<p>Informações para envio de currículo e candidatura espontânea.</p>',
			'cotacao' => '<p>Formulário para compartilhar informações da obra e solicitar uma cotação.</p>',
		);
		return isset( $contents[ $slug ] ) ? $contents[ $slug ] : '';
	}

	/** Preserva conteúdo manual já inserido nas páginas que serão unificadas. */
	private function legacy_merged_page_contents() {
		$contents = array();
		foreach ( array( 'aplicacoes', 'diferenciais' ) as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page && 'trash' !== $page->post_status && trim( wp_strip_all_tags( (string) $page->post_content ) ) ) {
				$contents[ $slug ] = wp_kses_post( $page->post_content );
			}
		}
		return $contents;
	}

	/** Garante que cada página estrutural possua conteúdo no próprio WordPress. */
	private function sync_portal_page_content( $page, $slug, $legacy_contents = array() ) {
		$page = get_post( $page );
		if ( ! $page ) {
			return;
		}
		$current = (string) $page->post_content;
		$content = trim( $current );
		if ( 'inicio' === $slug ) {
			foreach ( array( '[captec_quem_somos]', '[captec_aplicacoes]', '[captec_diferenciais]' ) as $shortcode ) {
				if ( false === strpos( $content, $shortcode ) ) {
					$content .= ( $content ? "\n\n" : '' ) . $shortcode;
				}
			}
			foreach ( (array) $legacy_contents as $legacy_slug => $legacy_content ) {
				$marker = '<!-- captec-migrado-' . sanitize_key( $legacy_slug ) . ' -->';
				if ( false === strpos( $content, $marker ) && trim( wp_strip_all_tags( $legacy_content ) ) ) {
					$content .= "\n\n" . $marker . "\n" . wp_kses_post( $legacy_content );
				}
			}
		} elseif ( ! trim( wp_strip_all_tags( $content ) ) ) {
			$content = $this->default_portal_page_content( $slug );
		}
		if ( $content !== trim( $current ) ) {
			wp_update_post( array( 'ID' => $page->ID, 'post_content' => $content ) );
		}
		update_post_meta( $page->ID, '_captec_portal_content_ready', '1' );
	}

	/** Remove páginas que agora integram Quem somos, sem apagar permanentemente conteúdo. */
	private function retire_legacy_merged_pages() {
		foreach ( array( 'empresa', 'aplicacoes', 'diferenciais' ) as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page && 'trash' !== $page->post_status ) {
				wp_trash_post( $page->ID );
			}
		}
	}

	/** Retira do menu qualquer referência às páginas unificadas, inclusive links personalizados. */
	private function remove_legacy_page_menu_items( $menu ) {
		if ( ! $menu ) {
			return;
		}
		$items = wp_get_nav_menu_items( $menu->term_id );
		foreach ( (array) $items as $item ) {
			$slug = $item->object_id ? get_post_field( 'post_name', $item->object_id ) : '';
			$path = trim( (string) wp_parse_url( $item->url, PHP_URL_PATH ), '/' );
			if ( in_array( $slug, array( 'empresa', 'aplicacoes', 'diferenciais' ), true ) || preg_match( '#/(?:empresa|aplicacoes|diferenciais)/?$#', '/' . $path ) ) {
				wp_delete_post( $item->ID, true );
			}
		}
	}

	/** Atualiza o nome administrativo do botão de Aplicações após a unificação. */
	private function refresh_merged_button_title() {
		$buttons = get_posts( array(
			'post_type'      => 'captec_button',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'meta_key'       => '_captec_button_slot',
			'meta_value'     => 'applications_quote',
			'no_found_rows'  => true,
		) );
		foreach ( $buttons as $button ) {
			if ( 'Quem somos — Aplicações — Solicitar cotação' !== $button->post_title ) {
				wp_update_post( array( 'ID' => $button->ID, 'post_title' => 'Quem somos — Aplicações — Solicitar cotação' ) );
			}
		}
	}

	/** Oculta do rodapé links das páginas integradas a Quem somos. */
	private function retire_legacy_footer_navigation_items() {
		$items = get_posts( array(
			'post_type'      => 'captec_footer_item',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => -1,
			'meta_key'       => '_captec_footer_section',
			'meta_value'     => 'navigation',
			'no_found_rows'  => true,
		) );
		foreach ( $items as $item ) {
			$label = sanitize_title( get_post_meta( $item->ID, '_captec_footer_label', true ) ?: get_the_title( $item ) );
			$url = (string) get_post_meta( $item->ID, '_captec_footer_url', true );
			if ( in_array( $label, array( 'aplicacoes', 'diferenciais', 'empresa' ), true ) || preg_match( '#/(?:aplicacoes|diferenciais|empresa)/?$#', $url ) ) {
				wp_trash_post( $item->ID );
			}
		}
	}

	/** Atualização única para instalações que já possuíam a estrutura anterior. */
	public function maybe_upgrade_portal_structure() {
		if ( self::STRUCTURE_VERSION === get_option( 'captec_portal_structure_version' ) || ! post_type_exists( 'page' ) ) {
			return;
		}
		$legacy_contents = $this->legacy_merged_page_contents();
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		$menu = ! empty( $locations['primary'] ) ? wp_get_nav_menu_object( (int) $locations['primary'] ) : wp_get_nav_menu_object( 'Menu Principal CAPTEC' );
		if ( ! $menu || 'Menu Principal CAPTEC' === $menu->name ) {
			$this->setup_portal_pages( $legacy_contents );
		} else {
			// Um menu personalizado é preservado, exceto pelos itens que deixaram de existir.
			$this->retire_legacy_merged_pages();
			$home = get_page_by_path( 'inicio' );
			if ( $home && __( 'Quem somos', 'captec-portal-admin' ) !== $home->post_title ) {
				wp_update_post( array( 'ID' => $home->ID, 'post_title' => __( 'Quem somos', 'captec-portal-admin' ) ) );
			}
			if ( $home ) {
				$this->sync_portal_page_content( $home, 'inicio', $legacy_contents );
			}
			foreach ( $this->portal_page_definitions() as $definition ) {
				if ( 'inicio' === $definition['slug'] ) {
					continue;
				}
				$portal_page = get_page_by_path( $definition['slug'] );
				if ( $portal_page ) {
					$this->sync_portal_page_content( $portal_page, $definition['slug'] );
				}
			}
			if ( ! get_page_by_path( 'trabalhe-conosco' ) ) {
				$career_id = wp_insert_post( array( 'post_title' => __( 'Trabalhe conosco', 'captec-portal-admin' ), 'post_name' => 'trabalhe-conosco', 'post_type' => 'page', 'post_status' => 'publish' ), true );
				if ( ! is_wp_error( $career_id ) && $career_id ) {
					update_post_meta( $career_id, '_wp_page_template', 'page-trabalhe-conosco.php' );
					$this->sync_portal_page_content( $career_id, 'trabalhe-conosco' );
				}
			}
			$this->remove_legacy_page_menu_items( $menu );
			flush_rewrite_rules();
		}
		$this->retire_legacy_footer_navigation_items();
		$this->refresh_merged_button_title();
		update_option( 'captec_portal_structure_version', self::STRUCTURE_VERSION, false );
	}

	private function portal_pages_ready() {
		foreach ( $this->portal_page_definitions() as $page ) {
			if ( ! get_page_by_path( $page['slug'] ) ) {
				return false;
			}
		}
		return true;
	}

	private function setup_portal_pages( $legacy_contents = null ) {
		if ( null === $legacy_contents ) {
			$legacy_contents = $this->legacy_merged_page_contents();
		}
		$this->retire_legacy_merged_pages();
		$pages = array();
		foreach ( $this->portal_page_definitions() as $definition ) {
			$page = get_page_by_path( $definition['slug'] );
			if ( ! $page ) {
				$id = wp_insert_post( array(
					'post_title'  => $definition['title'],
					'post_name'   => $definition['slug'],
					'post_type'   => 'page',
					'post_status' => 'publish',
					'menu_order'  => count( $pages ),
				), true );
				if ( is_wp_error( $id ) ) {
					continue;
				}
				$page = get_post( $id );
			}
			if ( $page && 'inicio' === $definition['slug'] && $definition['title'] !== $page->post_title ) {
				wp_update_post( array( 'ID' => $page->ID, 'post_title' => $definition['title'] ) );
				$page = get_post( $page->ID );
			}
			if ( $page && ! empty( $definition['template'] ) ) {
				update_post_meta( $page->ID, '_wp_page_template', $definition['template'] );
			}
			if ( $page ) {
				$this->sync_portal_page_content( $page, $definition['slug'], $legacy_contents );
			}
			if ( $page ) {
				$pages[ $definition['slug'] ] = (int) $page->ID;
			}
		}

		if ( ! empty( $pages['inicio'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $pages['inicio'] );
		}
		if ( ! empty( $pages['blog'] ) ) {
			update_option( 'page_for_posts', $pages['blog'] );
		}

		$menu_name = 'Menu Principal CAPTEC';
		$menu      = wp_get_nav_menu_object( $menu_name );
		$menu_id   = $menu ? (int) $menu->term_id : wp_create_nav_menu( $menu_name );
		if ( ! is_wp_error( $menu_id ) && $menu_id ) {
			$existing = wp_get_nav_menu_items( $menu_id );
			if ( $existing ) {
				foreach ( $existing as $existing_item ) {
					wp_delete_post( $existing_item->ID, true );
				}
			}
			foreach ( $this->portal_page_definitions() as $order => $definition ) {
				if ( empty( $pages[ $definition['slug'] ] ) ) {
					continue;
				}
				wp_update_nav_menu_item( $menu_id, 0, array(
					'menu-item-title'     => $definition['title'],
					'menu-item-object'    => 'page',
					'menu-item-object-id' => $pages[ $definition['slug'] ],
					'menu-item-type'      => 'post_type',
					'menu-item-status'    => 'publish',
					'menu-item-position'  => $order + 1,
				) );
			}
			$locations            = get_theme_mod( 'nav_menu_locations', array() );
			$locations['primary'] = $menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
		flush_rewrite_rules();
		$this->retire_legacy_footer_navigation_items();
		$this->refresh_merged_button_title();
		update_option( 'captec_portal_structure_version', self::STRUCTURE_VERSION, false );
		return $pages;
	}

	private function features() {
		$definitions = array(
			'hero_video'   => __( 'Vídeo do Hero', 'captec-portal-admin' ),
			'products'     => __( 'Vitrine de produtos', 'captec-portal-admin' ),
			'applications' => __( 'Seção Aplicações em Quem somos', 'captec-portal-admin' ),
			'differentials'=> __( 'Seção Diferenciais em Quem somos', 'captec-portal-admin' ),
			'process'      => __( 'Processo comercial', 'captec-portal-admin' ),
			'stats'        => __( 'Indicadores', 'captec-portal-admin' ),
			'map'          => __( 'Mapa de cobertura', 'captec-portal-admin' ),
			'locations'    => __( 'Página Matriz e filiais', 'captec-portal-admin' ),
			'blog'         => __( 'Página Conteúdos', 'captec-portal-admin' ),
			'quote'        => __( 'Página Solicitar Cotação', 'captec-portal-admin' ),
			'whatsapp'     => __( 'Botão flutuante de WhatsApp', 'captec-portal-admin' ),
		);
		$features = array();
		foreach ( $definitions as $key => $label ) {
			$features[] = array( 'key' => $key, 'label' => $label, 'enabled' => '0' !== (string) get_theme_mod( 'captec_feature_' . $key, '1' ) );
		}
		return array(
			'items'       => $features,
			'maintenance' => (bool) get_option( 'captec_maintenance_enabled', false ),
			'message'     => (string) get_option( 'captec_maintenance_message', __( 'Estamos realizando uma manutenção programada. Voltaremos em breve.', 'captec-portal-admin' ) ),
		);
	}

	private function ai_public_settings() {
		$avatar_id = absint( get_option( 'captec_ai_avatar_id', 0 ) );
		return array(
			'name'       => get_option( 'captec_ai_name', 'Nina CAPTEC' ),
			'greeting'   => get_option( 'captec_ai_greeting', "Oi! Meu nome é {nome}, seu assistente virtual!\n\nComo posso te ajudar?" ),
			'avatar_id'  => $avatar_id,
			'avatar_url' => $avatar_id ? wp_get_attachment_image_url( $avatar_id, 'thumbnail' ) : '',
		);
	}

	private function analytics_public_settings() {
		$property_id = preg_replace( '/\D+/', '', (string) get_option( 'captec_ga4_property_id', '' ) );
		$account_raw = (string) get_option( 'captec_ga4_service_account', '' );
		$account     = $account_raw ? json_decode( $account_raw, true ) : array();
		$configured  = $property_id && is_array( $account ) && ! empty( $account['client_email'] ) && ! empty( $account['private_key'] );
		return array(
			'property_id'       => $property_id,
			'configured'        => (bool) $configured,
			'credential_present' => is_array( $account ) && ! empty( $account['client_email'] ),
			'last_updated'      => (string) get_option( 'captec_ga4_last_updated', '' ),
		);
	}

	private function base64url_encode( $value ) {
		return rtrim( strtr( base64_encode( $value ), '+/', '-_' ), '=' );
	}

	private function ga4_access_token() {
		$cached = get_transient( 'captec_ga4_access_token' );
		if ( $cached ) {
			return $cached;
		}
		$account = json_decode( (string) get_option( 'captec_ga4_service_account', '' ), true );
		if ( ! is_array( $account ) || empty( $account['client_email'] ) || empty( $account['private_key'] ) ) {
			return new WP_Error( 'captec_ga4_credentials', __( 'Informe o JSON da conta de serviço do Google Analytics.', 'captec-portal-admin' ) );
		}
		if ( ! function_exists( 'openssl_sign' ) ) {
			return new WP_Error( 'captec_ga4_openssl', __( 'A extensão OpenSSL do PHP é necessária para conectar ao Google Analytics.', 'captec-portal-admin' ) );
		}
		$now    = time();
		$header = $this->base64url_encode( wp_json_encode( array( 'alg' => 'RS256', 'typ' => 'JWT' ) ) );
		$claims = $this->base64url_encode( wp_json_encode( array(
			'iss'   => $account['client_email'],
			'scope'  => 'https://www.googleapis.com/auth/analytics.readonly',
			'aud'   => ! empty( $account['token_uri'] ) ? $account['token_uri'] : 'https://oauth2.googleapis.com/token',
			'iat'   => $now,
			'exp'   => $now + 3600,
		) ) );
		$unsigned = $header . '.' . $claims;
		$signature = '';
		if ( ! openssl_sign( $unsigned, $signature, $account['private_key'], OPENSSL_ALGO_SHA256 ) ) {
			return new WP_Error( 'captec_ga4_signature', __( 'Não foi possível assinar a autenticação da conta de serviço.', 'captec-portal-admin' ) );
		}
		$assertion = $unsigned . '.' . $this->base64url_encode( $signature );
		$token_uri = ! empty( $account['token_uri'] ) ? esc_url_raw( $account['token_uri'] ) : 'https://oauth2.googleapis.com/token';
		$response = wp_remote_post( $token_uri, array(
			'timeout' => 25,
			'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
			'body'    => array(
				'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
				'assertion'  => $assertion,
			),
		) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'captec_ga4_token', $response->get_error_message() );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 > wp_remote_retrieve_response_code( $response ) || 299 < wp_remote_retrieve_response_code( $response ) || empty( $body['access_token'] ) ) {
			return new WP_Error( 'captec_ga4_token', isset( $body['error_description'] ) ? $body['error_description'] : __( 'O Google Analytics recusou as credenciais informadas.', 'captec-portal-admin' ) );
		}
		$ttl = ! empty( $body['expires_in'] ) ? max( 60, (int) $body['expires_in'] - 120 ) : 3300;
		set_transient( 'captec_ga4_access_token', $body['access_token'], $ttl );
		return $body['access_token'];
	}

	private function ga4_run_report( $dimensions, $metrics, $start_date, $end_date, $limit = 100, $order_bys = array(), $dimension_filter = array() ) {
		$settings = $this->analytics_public_settings();
		if ( empty( $settings['configured'] ) ) {
			return new WP_Error( 'captec_ga4_not_configured', __( 'Configure o ID da propriedade GA4 e a conta de serviço para visualizar os dados.', 'captec-portal-admin' ) );
		}
		$token = $this->ga4_access_token();
		if ( is_wp_error( $token ) ) {
			return $token;
		}
		$payload = array(
			'dateRanges' => array( array( 'startDate' => $start_date, 'endDate' => $end_date ) ),
			'metrics'    => array_map( static function( $name ) { return array( 'name' => $name ); }, $metrics ),
			'limit'       => (string) $limit,
		);
		if ( $dimensions ) {
			$payload['dimensions'] = array_map( static function( $name ) { return array( 'name' => $name ); }, $dimensions );
		}
		if ( $order_bys ) {
			$payload['orderBys'] = $order_bys;
		}
		if ( $dimension_filter ) {
			$payload['dimensionFilter'] = $dimension_filter;
		}
		$url = 'https://analyticsdata.googleapis.com/v1beta/properties/' . rawurlencode( $settings['property_id'] ) . ':runReport';
		$response = wp_remote_post( $url, array(
			'timeout' => 30,
			'headers' => array( 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $payload ),
		) );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'captec_ga4_request', $response->get_error_message() );
		}
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 > wp_remote_retrieve_response_code( $response ) || 299 < wp_remote_retrieve_response_code( $response ) ) {
			$message = isset( $body['error']['message'] ) ? $body['error']['message'] : __( 'Não foi possível consultar o Google Analytics.', 'captec-portal-admin' );
			return new WP_Error( 'captec_ga4_request', $message );
		}
		return is_array( $body ) ? $body : array();
	}

	private function ga4_total( $metric, $start_date, $end_date ) {
		$report = $this->ga4_run_report( array(), array( $metric ), $start_date, $end_date, 1 );
		if ( is_wp_error( $report ) ) {
			return $report;
		}
		return isset( $report['rows'][0]['metricValues'][0]['value'] ) ? (int) $report['rows'][0]['metricValues'][0]['value'] : 0;
	}

	private function ga4_rows( $report, $dimensions, $metrics ) {
		$items = array();
		if ( ! is_array( $report ) || empty( $report['rows'] ) ) {
			return $items;
		}
		foreach ( $report['rows'] as $row ) {
			$item = array();
			foreach ( $dimensions as $index => $dimension ) {
				$item[ $dimension ] = isset( $row['dimensionValues'][ $index ]['value'] ) ? $row['dimensionValues'][ $index ]['value'] : '';
			}
			foreach ( $metrics as $index => $metric ) {
				$item[ $metric ] = isset( $row['metricValues'][ $index ]['value'] ) ? (float) $row['metricValues'][ $index ]['value'] : 0;
			}
			$items[] = $item;
		}
		return $items;
	}

	private function brazil_macro_region( $state ) {
		$key = strtolower( remove_accents( preg_replace( '/^state of\s+/i', '', (string) $state ) ) );
		$regions = array(
			'acre' => 'Norte', 'amapa' => 'Norte', 'amazonas' => 'Norte', 'para' => 'Norte', 'rondonia' => 'Norte', 'roraima' => 'Norte', 'tocantins' => 'Norte',
			'alagoas' => 'Nordeste', 'bahia' => 'Nordeste', 'ceara' => 'Nordeste', 'maranhao' => 'Nordeste', 'paraiba' => 'Nordeste', 'pernambuco' => 'Nordeste', 'piaui' => 'Nordeste', 'rio grande do norte' => 'Nordeste', 'sergipe' => 'Nordeste',
			'distrito federal' => 'Centro-Oeste', 'goias' => 'Centro-Oeste', 'mato grosso' => 'Centro-Oeste', 'mato grosso do sul' => 'Centro-Oeste',
			'espirito santo' => 'Sudeste', 'minas gerais' => 'Sudeste', 'rio de janeiro' => 'Sudeste', 'sao paulo' => 'Sudeste',
			'parana' => 'Sul', 'rio grande do sul' => 'Sul', 'santa catarina' => 'Sul',
		);
		return isset( $regions[ $key ] ) ? $regions[ $key ] : __( 'Outras localidades', 'captec-portal-admin' );
	}

	private function analytics_date_range( $period, $custom_start = '', $custom_end = '' ) {
		$today  = wp_date( 'Y-m-d' );
		$period = sanitize_key( $period );
		$map = array(
			'today'  => array( 'start' => $today, 'end' => $today, 'label' => __( 'Hoje', 'captec-portal-admin' ) ),
			'7days'  => array( 'start' => '7daysAgo', 'end' => 'today', 'label' => __( 'Últimos 7 dias', 'captec-portal-admin' ) ),
			'30days' => array( 'start' => '30daysAgo', 'end' => 'today', 'label' => __( 'Últimos 30 dias', 'captec-portal-admin' ) ),
			'month'  => array( 'start' => wp_date( 'Y-m-01' ), 'end' => $today, 'label' => __( 'Este mês', 'captec-portal-admin' ) ),
			'year'   => array( 'start' => wp_date( 'Y-01-01' ), 'end' => $today, 'label' => __( 'Este ano', 'captec-portal-admin' ) ),
		);
		if ( 'custom' === $period ) {
			$start = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $custom_start ) ? $custom_start : '';
			$end   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', $custom_end ) ? $custom_end : '';
			if ( ! $start || ! $end || $start > $end ) {
				return new WP_Error( 'captec_analytics_dates', __( 'Informe um intervalo personalizado válido.', 'captec-portal-admin' ) );
			}
			return array( 'start' => $start, 'end' => $end, 'label' => sprintf( __( '%1$s até %2$s', 'captec-portal-admin' ), wp_date( 'd/m/Y', strtotime( $start ) ), wp_date( 'd/m/Y', strtotime( $end ) ) ) );
		}
		return isset( $map[ $period ] ) ? $map[ $period ] : $map['year'];
	}

	private function analytics_report( $force = false, $range = null ) {
		$range = is_array( $range ) ? $range : $this->analytics_date_range( 'year' );
		if ( is_wp_error( $range ) ) {
			return $range;
		}
		$settings = $this->analytics_public_settings();
		if ( empty( $settings['configured'] ) ) {
			return new WP_Error( 'captec_ga4_not_configured', __( 'Conecte uma propriedade Google Analytics 4 para liberar a análise do portal.', 'captec-portal-admin' ) );
		}
		$cache_key = 'captec_ga4_report_' . md5( $settings['property_id'] . '|' . $range['start'] . '|' . $range['end'] );
		if ( ! $force ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}
		$today = wp_date( 'Y-m-d' );
		$month = wp_date( 'Y-m-01' );
		$year  = wp_date( 'Y-01-01' );
		$overview = array(
			'year'  => $this->ga4_total( 'sessions', $year, $today ),
			'month' => $this->ga4_total( 'sessions', $month, $today ),
			'day'   => $this->ga4_total( 'sessions', $today, $today ),
		);
		foreach ( $overview as $value ) {
			if ( is_wp_error( $value ) ) {
				return $value;
			}
		}
		$hours_report = $this->ga4_run_report( array( 'hour' ), array( 'sessions' ), $range['start'], $range['end'], 24, array( array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ) ) );
		if ( is_wp_error( $hours_report ) ) {
			return $hours_report;
		}
		$hour_rows = $this->ga4_rows( $hours_report, array( 'hour' ), array( 'sessions' ) );
		$peak_hour = ! empty( $hour_rows[0] ) ? sprintf( '%02d:00', (int) $hour_rows[0]['hour'] ) : '—';

		$pages_report = $this->ga4_run_report( array( 'pagePath' ), array( 'screenPageViews', 'userEngagementDuration' ), $range['start'], $range['end'], 15, array( array( 'metric' => array( 'metricName' => 'screenPageViews' ), 'desc' => true ) ) );
		if ( is_wp_error( $pages_report ) ) {
			return $pages_report;
		}
		$pages = $this->ga4_rows( $pages_report, array( 'pagePath' ), array( 'screenPageViews', 'userEngagementDuration' ) );
		foreach ( $pages as &$page ) {
			$page['average_seconds'] = ! empty( $page['screenPageViews'] ) ? (int) round( $page['userEngagementDuration'] / $page['screenPageViews'] ) : 0;
		}
		unset( $page );

		$br_filter = array( 'filter' => array( 'fieldName' => 'countryId', 'stringFilter' => array( 'matchType' => 'EXACT', 'value' => 'BR', 'caseSensitive' => false ) ) );
		$states_report = $this->ga4_run_report( array( 'region' ), array( 'sessions' ), $range['start'], $range['end'], 100, array( array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ) ), $br_filter );
		if ( is_wp_error( $states_report ) ) {
			return $states_report;
		}
		$states = $this->ga4_rows( $states_report, array( 'region' ), array( 'sessions' ) );
		$regions = array();
		foreach ( $states as $state ) {
			$macro = $this->brazil_macro_region( $state['region'] );
			if ( ! isset( $regions[ $macro ] ) ) {
				$regions[ $macro ] = 0;
			}
			$regions[ $macro ] += (int) $state['sessions'];
		}
		$regions_formatted = array();
		foreach ( $regions as $name => $sessions ) {
			$regions_formatted[] = array( 'region' => $name, 'sessions' => $sessions );
		}
		usort( $regions_formatted, static function( $a, $b ) { return $b['sessions'] <=> $a['sessions']; } );

		$cities_report = $this->ga4_run_report( array( 'city' ), array( 'sessions' ), $range['start'], $range['end'], 15, array( array( 'metric' => array( 'metricName' => 'sessions' ), 'desc' => true ) ), $br_filter );
		if ( is_wp_error( $cities_report ) ) {
			return $cities_report;
		}
		$cities = $this->ga4_rows( $cities_report, array( 'city' ), array( 'sessions' ) );

		$data = array(
			'overview'  => $overview,
			'peak_hour' => $peak_hour,
			'pages'     => $pages,
			'regions'   => $regions_formatted,
			'states'    => array_slice( $states, 0, 15 ),
			'cities'    => $cities,
			'range'     => $range,
			'updated_at'=> current_time( 'c' ),
		);
		set_transient( $cache_key, $data, HOUR_IN_SECONDS );
		update_option( 'captec_ga4_last_updated', $data['updated_at'], false );
		return $data;
	}

	public function ajax_save_analytics() {
		$this->guard_ajax();
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '{}';
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( 'Dados inválidos.', 'captec-portal-admin' ) ), 400 );
		}
		update_option( 'captec_ga4_property_id', isset( $data['property_id'] ) ? preg_replace( '/\D+/', '', (string) $data['property_id'] ) : '' );
		if ( isset( $data['service_account_json'] ) && '' !== trim( (string) $data['service_account_json'] ) ) {
			$service = json_decode( $data['service_account_json'], true );
			if ( ! is_array( $service ) || empty( $service['client_email'] ) || empty( $service['private_key'] ) ) {
				wp_send_json_error( array( 'message' => __( 'O JSON da conta de serviço não parece válido. Verifique o arquivo exportado pelo Google Cloud.', 'captec-portal-admin' ) ), 400 );
			}
			update_option( 'captec_ga4_service_account', wp_json_encode( $service ), false );
		}
		delete_transient( 'captec_ga4_access_token' );
		delete_transient( 'captec_ga4_report' );
		$this->log_activity( 'save_analytics', __( 'Configuração da análise do portal atualizada.', 'captec-portal-admin' ), 'analytics' );
		wp_send_json_success( array( 'message' => __( 'Configuração de análise salva.', 'captec-portal-admin' ), 'analytics' => $this->analytics_public_settings() ) );
	}

	public function ajax_analytics() {
		$this->guard_ajax();
		$force  = ! empty( $_POST['force'] );
		$period = isset( $_POST['period'] ) ? wp_unslash( $_POST['period'] ) : 'year';
		$start  = isset( $_POST['start'] ) ? sanitize_text_field( wp_unslash( $_POST['start'] ) ) : '';
		$end    = isset( $_POST['end'] ) ? sanitize_text_field( wp_unslash( $_POST['end'] ) ) : '';
		$range  = $this->analytics_date_range( $period, $start, $end );
		if ( is_wp_error( $range ) ) {
			wp_send_json_error( array( 'message' => $range->get_error_message(), 'analytics' => $this->analytics_public_settings() ), 400 );
		}
		$report = $this->analytics_report( $force, $range );
		if ( is_wp_error( $report ) ) {
			wp_send_json_error( array( 'message' => $report->get_error_message(), 'analytics' => $this->analytics_public_settings() ), 400 );
		}
		$this->log_activity( 'view_analytics', __( 'Análise do portal consultada.', 'captec-portal-admin' ), 'analytics', 0, array( 'period' => $period ) );
		wp_send_json_success( array( 'report' => $report, 'analytics' => $this->analytics_public_settings() ) );
	}

	private function suggested_topic_pool() {
		return array(
			array(
				'id' => 'anp-897-produtos-2026', 'title' => 'Produtos asfálticos e a Resolução ANP nº 897/2022: pontos para revisar em 2026', 'category' => 'Regulação', 'date' => 'Referência vigente',
				'summary' => 'Um guia editorial sobre classificações de CAP, emulsões e a importância de validar especificações antes da cotação.',
				'content' => '<p>Ao preparar uma cotação ou conteúdo técnico sobre materiais asfálticos, é importante confirmar a especificação indicada no projeto e consultar os requisitos regulatórios aplicáveis.</p><h2>O que a referência reúne</h2><p>A Resolução ANP nº 897/2022 apresenta classificações e especificações para produtos asfálticos e emulsões para pavimentação, incluindo categorias como RR-1C, RR-2C, RL-1C e EAI.</p><h2>Boas práticas para a solicitação</h2><ul><li>Informar produto, quantidade, local de entrega e condição da obra.</li><li>Conferir a especificação indicada no projeto.</li><li>Solicitar ficha técnica atualizada quando aplicável.</li><li>Validar a solução com a equipe técnica responsável pela obra.</li></ul><p><strong>Referência:</strong> <a href="https://portal.in.gov.br/web/dou/-/resolucao-anp-n-897-de-18-de-novembro-de-2022-445759308" target="_blank" rel="noopener noreferrer">Resolução ANP nº 897/2022 — Diário Oficial da União</a>.</p><p><em>Este conteúdo é informativo e não substitui projeto, especificação vigente ou avaliação técnica responsável.</em></p>',
			),
			array(
				'id' => 'dnit-385-2026', 'title' => 'DNIT 385/2026: o que observar em serviços com concreto asfáltico', 'category' => 'Normas', 'date' => 'Julho de 2026',
				'summary' => 'Pauta sobre a revisão da especificação de serviço para pavimentação com concreto asfáltico com ligante.',
				'content' => '<p>A Norma DNIT 385/2026 atualiza a referência de especificação de serviço para pavimentação com concreto asfáltico com ligante. Para equipes de obra e compras, a principal recomendação é sempre alinhar a demanda à documentação técnica do empreendimento.</p><h2>Por que acompanhar normas atualizadas</h2><p>Normas e especificações orientam critérios de materiais, execução, controle e recebimento. A leitura do documento aplicável ajuda a organizar a comunicação entre projeto, obra, fornecedor e fiscalização.</p><h2>Checklist antes da compra</h2><ul><li>Confirmar a camada e a solução previstas no projeto.</li><li>Verificar a especificação e a documentação solicitada.</li><li>Definir quantidade, programação e local de entrega.</li><li>Registrar os critérios de recebimento estabelecidos para a obra.</li></ul><p><strong>Fonte oficial:</strong> <a href="https://www.gov.br/dnit/pt-br/assuntos/planejamento-e-pesquisa/ipr/coletanea-de-normas/coletanea-de-normas/especificacao-de-servico-es/dnit_385_2026_es.pdf" target="_blank" rel="noopener noreferrer">Norma DNIT 385/2026 — ES</a>.</p>',
			),
			array(
				'id' => 'dnit-035-2026', 'title' => 'Microrrevestimento asfáltico a frio: referência DNIT 035/2026', 'category' => 'Pavimentação', 'date' => '2026',
				'summary' => 'Conteúdo sobre a norma de microrrevestimento a frio e a necessidade de observar projeto, dosagem e condições de execução.',
				'content' => '<p>O microrrevestimento asfáltico a frio é um tema recorrente na conservação de pavimentos. A referência DNIT 035/2026 aborda a especificação de serviço e reforça a importância de projeto de dosagem, preparo da plataforma e controle de execução.</p><h2>O que deve ser alinhado</h2><ul><li>Condições do pavimento existente.</li><li>Projeto de dosagem e material especificado.</li><li>Condições climáticas e programação da aplicação.</li><li>Controles de recebimento e execução previstos.</li></ul><p><strong>Fonte oficial:</strong> <a href="https://www.gov.br/dnit/pt-br/assuntos/planejamento-e-pesquisa/ipr/coletanea-de-normas/coletanea-de-normas/especificacao-de-servico-es/dnit_035_2026_es.pdf" target="_blank" rel="noopener noreferrer">Norma DNIT 035/2026 — ES</a>.</p><p><em>A indicação de produto deve seguir a especificação do projeto e a avaliação técnica da obra.</em></p>',
			),
			array(
				'id' => 'manutencao-seguranca-2026', 'title' => 'Manutenção rodoviária e segurança viária: por que dados de pavimento importam', 'category' => 'Infraestrutura', 'date' => 'Maio de 2026',
				'summary' => 'Pauta baseada em nota técnica do Ministério dos Transportes sobre manutenção de rodovias e segurança viária.',
				'content' => '<p>A manutenção da infraestrutura rodoviária está diretamente ligada à qualidade do pavimento, à segurança e à previsibilidade das operações. Uma nota técnica do Ministério dos Transportes publicada em 2026 reúne dados e evidências sobre esse tema.</p><h2>Como transformar informação em planejamento</h2><ul><li>Acompanhar o estado do pavimento e a necessidade de intervenção.</li><li>Planejar a programação de materiais de acordo com o cronograma da obra.</li><li>Registrar condições de execução e recebimento.</li><li>Integrar decisões de conservação, logística e segurança viária.</li></ul><p><strong>Fonte oficial:</strong> <a href="https://www.gov.br/transportes/pt-br/assuntos/noticias/2026/arquivos/NotaTcnican_052026.pdf" target="_blank" rel="noopener noreferrer">Manutenção das rodovias e segurança viária — Ministério dos Transportes</a>.</p>',
			),
			array(
				'id' => 'cap-emulsao-guia', 'title' => 'CAP e emulsão asfáltica: como organizar uma solicitação comercial', 'category' => 'Produtos', 'date' => 'Atualizada em 2026',
				'summary' => 'Roteiro objetivo para identificar informações que ajudam a análise inicial de uma demanda por CAP ou emulsão.',
				'content' => '<p>CAP e emulsões são categorias diferentes de produtos asfálticos. Em vez de escolher apenas pelo nome, a solicitação deve começar pela especificação da obra, pelo tipo de aplicação e pelo planejamento de entrega.</p><h2>Informações que ajudam na cotação</h2><ul><li>Produto previsto na especificação.</li><li>Quantidade estimada e unidade de medida.</li><li>Município e condição de entrega.</li><li>Data ou janela de programação.</li><li>Documentos técnicos disponíveis.</li></ul><h2>Importante</h2><p>A definição final do material deve observar o projeto e as referências técnicas aplicáveis. A ANP mantém informações públicas sobre asfalto, distribuição e requisitos de qualidade.</p><p><strong>Fonte:</strong> <a href="https://www.gov.br/anp/pt-br/assuntos/producao-de-derivados-de-petroleo-e-processamento-de-gas-natural/producao-de-derivados-de-petroleo-e-processamento-de-gas-natural/asfalto" target="_blank" rel="noopener noreferrer">ANP — Asfalto</a>.</p>',
			),
			array(
				'id' => 'pintura-ligacao', 'title' => 'Pintura de ligação: perguntas que devem ser respondidas antes da execução', 'category' => 'Aplicações', 'date' => 'Atualizada em 2026',
				'summary' => 'Checklist editorial para discutir pintura de ligação com foco em projeto, superfície, aplicação e controle.',
				'content' => '<p>A pintura de ligação integra etapas de pavimentação e deve seguir o material e a taxa previstos em projeto. Antes de iniciar a operação, a equipe precisa confirmar as condições da superfície e o procedimento de aplicação.</p><h2>Perguntas essenciais</h2><ul><li>Qual material está indicado no projeto?</li><li>Como está a limpeza e a condição da superfície?</li><li>Qual taxa de aplicação foi definida?</li><li>Quais controles e registros serão adotados?</li></ul><p>Documentos de especificação devem ser consultados na versão vigente e aplicados conforme a responsabilidade técnica da obra.</p>',
			),
			array(
				'id' => 'logistica-asfaltos', 'title' => 'Logística de produtos asfálticos: dados que evitam atrasos na programação', 'category' => 'Logística', 'date' => 'Atualizada em 2026',
				'summary' => 'Pauta prática sobre as informações necessárias para organizar uma entrega com mais previsibilidade.',
				'content' => '<p>A programação logística começa com informação completa. Produto, quantidade, local de entrega, acesso, janela de recebimento e contato em obra são dados importantes para reduzir retrabalhos.</p><h2>Checklist de programação</h2><ul><li>Produto e especificação confirmados.</li><li>Quantidade e unidade de medida registradas.</li><li>Endereço e condições de acesso conferidos.</li><li>Contato responsável pelo recebimento.</li><li>Janela de entrega e restrições operacionais alinhadas.</li></ul><p>Condições específicas de transporte e recebimento devem ser tratadas na negociação comercial e conforme as exigências aplicáveis.</p>',
			),
			array(
				'id' => 'mapas-geotransportes', 'title' => 'Como dados geográficos ajudam no planejamento de infraestrutura', 'category' => 'Planejamento', 'date' => 'Referência 2025–2026',
				'summary' => 'Conteúdo sobre o uso de mapas e bases georreferenciadas públicas no planejamento de infraestrutura.',
				'content' => '<p>Mapas e bases georreferenciadas ajudam equipes de infraestrutura a visualizar redes de transporte, acessos e contexto territorial. O Ministério dos Transportes disponibiliza referências e bases para consulta pública.</p><h2>Uso responsável dos dados</h2><ul><li>Confirmar a data de atualização da base.</li><li>Usar dados públicos como apoio, não como substituição de levantamento de campo.</li><li>Confrontar informações geográficas com o projeto e as condições reais de acesso.</li></ul><p><strong>Fonte:</strong> <a href="https://www.gov.br/transportes/pt-br/assuntos/dados-de-transportes/bit/bit-mapas" target="_blank" rel="noopener noreferrer">Mapas — Ministério dos Transportes</a>.</p>',
			),
			array(
				'id' => 'ficha-tecnica', 'title' => 'Ficha técnica de produto asfáltico: o que conferir antes de anexar à cotação', 'category' => 'Qualidade', 'date' => 'Atualizada em 2026',
				'summary' => 'Uma pauta para orientar a organização de documentos técnicos no processo comercial.',
				'content' => '<p>A ficha técnica organiza informações importantes para a conversa comercial e técnica. Antes de anexar um documento à cotação, confirme se ele corresponde ao produto, à versão vigente e à necessidade da obra.</p><h2>Itens de verificação</h2><ul><li>Nome e classificação do produto.</li><li>Versão e data do documento.</li><li>Compatibilidade com a especificação solicitada.</li><li>Responsável técnico e fonte do arquivo.</li></ul><p>Em caso de dúvida, solicite a validação do Administrador do site ou da área técnica responsável antes da publicação.</p>',
			),
			array(
				'id' => 'controle-recebimento', 'title' => 'Recebimento de materiais: como preparar a comunicação entre obra e fornecimento', 'category' => 'Operação', 'date' => 'Atualizada em 2026',
				'summary' => 'Pauta sobre alinhamento de dados comerciais e operacionais antes do recebimento de materiais.',
				'content' => '<p>O recebimento de materiais exige comunicação clara entre pedido, logística e frente de obra. Organizar previamente os dados de entrega ajuda a equipe a conferir documentos, programar recursos e registrar ocorrências.</p><h2>Antes da chegada</h2><ul><li>Confirmar pedido, produto e quantidade.</li><li>Informar acesso, responsável e horário de recebimento.</li><li>Preparar o procedimento de conferência definido para a obra.</li><li>Registrar desvios para análise da equipe responsável.</li></ul><p>Os critérios técnicos e de segurança devem seguir a documentação aplicável e a orientação da obra.</p>',
			),
		);
	}

	private function suggested_topics() {
		$used = array_map( 'sanitize_key', (array) get_option( 'captec_portal_used_topics', array() ) );
		$items = array();
		foreach ( $this->suggested_topic_pool() as $topic ) {
			if ( in_array( $topic['id'], $used, true ) ) {
				continue;
			}
			$items[] = array( 'id' => $topic['id'], 'title' => $topic['title'], 'category' => $topic['category'], 'date' => $topic['date'], 'summary' => $topic['summary'], 'image_url' => $this->topic_image_url( $topic['id'] ) );
			if ( 5 === count( $items ) ) {
				break;
			}
		}
		return $items;
	}

	public function ajax_generate_article() {
		$this->guard_ajax();
		$topic_id = isset( $_POST['topic_id'] ) ? sanitize_key( wp_unslash( $_POST['topic_id'] ) ) : '';
		$topic = null;
		foreach ( $this->suggested_topic_pool() as $item ) {
			if ( $topic_id === $item['id'] ) {
				$topic = $item;
				break;
			}
		}
		if ( ! $topic ) {
			wp_send_json_error( array( 'message' => __( 'Pauta não encontrada. Atualize a página e tente novamente.', 'captec-portal-admin' ) ), 404 );
		}
		$used = array_map( 'sanitize_key', (array) get_option( 'captec_portal_used_topics', array() ) );
		if ( in_array( $topic_id, $used, true ) ) {
			wp_send_json_error( array( 'message' => __( 'Esta pauta já foi carregada anteriormente.', 'captec-portal-admin' ) ), 409 );
		}
		$post_id = wp_insert_post( array(
			'post_type'    => 'post',
			'post_status'  => 'draft',
			'post_title'   => $topic['title'],
			'post_excerpt' => $topic['summary'],
			'post_content' => wp_kses_post( $topic['content'] ),
			'post_author'  => get_current_user_id(),
		), true );
		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => $post_id->get_error_message() ), 500 );
		}
		$category_id = $this->ensure_article_category( $topic['category'] );
		if ( $category_id ) {
			wp_set_post_categories( $post_id, array( $category_id ), false );
		}
		$this->attach_topic_image( $post_id, $topic_id );
		$used[] = $topic_id;
		update_option( 'captec_portal_used_topics', array_values( array_unique( $used ) ), false );
		$this->log_activity( 'generate_article', sprintf( __( 'Artigo gerado a partir da pauta: %s', 'captec-portal-admin' ), $topic['title'] ), 'article', $post_id, array( 'topic_id' => $topic_id ) );
		wp_send_json_success( array(
			'message' => __( 'Artigo criado como rascunho pronto para revisão e publicação.', 'captec-portal-admin' ),
			'item'    => $this->serialize_item( $post_id, 'article' ),
			'topics'  => $this->suggested_topics(),
			'categories' => $this->article_categories(),
		) );
	}

	public function ajax_log_navigation() {
		$this->guard_ajax();
		$view = isset( $_POST['view'] ) ? sanitize_key( wp_unslash( $_POST['view'] ) ) : '';
		$labels = array(
			'overview' => 'Visão geral', 'home' => 'Quem somos', 'pagecontent' => 'Textos das páginas', 'preview' => 'Pré-visualizar portal', 'products' => 'Produtos', 'applications' => 'Aplicações', 'locations' => 'Matriz e filiais', 'pages' => 'Páginas e menu', 'content' => 'Conteúdos', 'quotes' => 'Cotações', 'brand' => 'Marca e contatos', 'buttons' => 'Botões do site', 'footer' => 'Rodapé', 'appearance' => 'Aparências', 'coverage' => 'Dados e cobertura', 'analytics' => 'Análise do portal', 'activity' => 'Log de atividades', 'features' => 'Funcionalidades', 'integrations' => 'Integrações e LGPD', 'assistant' => 'Agente IA',
		);
		if ( ! isset( $labels[ $view ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Módulo não reconhecido.', 'captec-portal-admin' ) ), 400 );
		}
		$this->log_activity( 'view_' . $view, sprintf( __( 'Acessou o módulo: %s', 'captec-portal-admin' ), $labels[ $view ] ), 'navigation' );
		wp_send_json_success();
	}

	public function ajax_activity_logs() {
		$this->guard_ajax();
		$days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
		$this->log_activity( 'view_activity_log', __( 'Consultou o Log de atividades.', 'captec-portal-admin' ), 'activity' );
		wp_send_json_success( array( 'logs' => $this->activity_logs( $days, 200 ), 'last_error' => get_option( 'captec_activity_log_last_error', '' ) ) );
	}

	private function boot_payload() {
		return array(
			'settings'       => $this->settings(),
			'draft_settings_count' => count( $this->draft_settings() ),
			'dashboard'      => $this->dashboard(),
			'products'       => $this->list_items( 'product' ),
			'applications'   => $this->list_items( 'application' ),
			'locations'      => $this->list_items( 'location' ),
			'buttons'        => $this->list_items( 'button' ),
			'footer_items'   => $this->list_items( 'footer_item' ),
			'stats'          => $this->list_items( 'stat' ),
			'pages'          => $this->list_items( 'page', 50 ),
			'features'       => $this->features(),
			'analytics'       => $this->analytics_public_settings(),
			'ai'             => $this->ai_public_settings(),
			'articles'       => $this->list_items( 'article', 30 ),
			'categories'     => $this->article_categories(),
			'suggested_topics'=> $this->suggested_topics(),
			'quotes'         => $this->list_items( 'quote', 60 ),
			'current_user'   => array(
				'name'   => wp_get_current_user()->display_name,
				'initial'=> strtoupper( substr( wp_get_current_user()->display_name ?: 'C', 0, 1 ) ),
			),
			'catalog_ready' => post_type_exists( 'captec_product' ) && post_type_exists( 'captec_application' ) && post_type_exists( 'captec_location' ),
			'site_url'      => home_url( '/' ),
			'admin_url'     => admin_url(),
		);
	}

	public function maybe_render_maintenance() {
		if ( ! get_option( 'captec_maintenance_enabled', false ) || is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		if ( is_user_logged_in() && $this->can_manage() ) {
			return;
		}
		status_header( 503 );
		header( 'Retry-After: 3600' );
		$message = wp_kses_post( get_option( 'captec_maintenance_message', __( 'Estamos realizando uma manutenção programada. Voltaremos em breve.', 'captec-portal-admin' ) ) );
		$logo_id = absint( get_theme_mod( 'custom_logo', 0 ) );
		$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium_large' ) : '';
		$brand = $logo_url ? '<img class="brand-logo" src="' . esc_url( $logo_url ) . '" alt="CAPTEC Asfaltos">' : '<p class="tag">CAPTEC<br><small>ASFALTOS</small></p>';
		nocache_headers();
		echo '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Manutenção programada</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#111;color:#fff;font-family:Arial,sans-serif}.box{max-width:600px;padding:48px 28px;text-align:center}.tag{margin:0;color:#fff;font-size:2rem;font-weight:900;letter-spacing:.12em;line-height:.92}.tag small{display:block;margin-top:8px;color:#f2a300;font-size:.35em;letter-spacing:.31em}.brand-logo{display:block;max-width:min(310px,80vw);max-height:105px;margin:0 auto 28px;object-fit:contain}.mark{font-size:2rem;font-weight:900;letter-spacing:.01em}.line{width:52px;height:4px;margin:22px auto;background:#f2a300}.copy{color:#d0d0d0;line-height:1.6}</style></head><body><main class="box">' . $brand . '<div class="mark">Site em manutenção</div><div class="line"></div><div class="copy">' . $message . '</div></main></body></html>';
		exit;
	}

	public function ajax_setup_pages() {
		$this->guard_ajax();
		$pages = $this->setup_portal_pages();
		$this->log_activity( 'setup_pages', __( 'Estrutura de páginas e menu criada ou atualizada.', 'captec-portal-admin' ), 'pages' );
		wp_send_json_success( array(
			'message'   => __( 'Estrutura criada: cada item do menu agora aponta para uma página WordPress própria.', 'captec-portal-admin' ),
			'pages'     => $this->list_items( 'page', 50 ),
			'dashboard' => $this->dashboard(),
		) );
	}

	public function ajax_save_features() {
		$this->guard_ajax();
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '{}';
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( 'Dados inválidos.', 'captec-portal-admin' ) ), 400 );
		}
		$allowed = array( 'hero_video', 'products', 'applications', 'differentials', 'process', 'stats', 'map', 'locations', 'blog', 'quote', 'whatsapp' );
		if ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
			foreach ( $data['items'] as $key => $enabled ) {
				$key = sanitize_key( $key );
				if ( in_array( $key, $allowed, true ) ) {
					set_theme_mod( 'captec_feature_' . $key, $enabled ? '1' : '0' );
				}
			}
		}
		if ( array_key_exists( 'maintenance', $data ) ) {
			update_option( 'captec_maintenance_enabled', (bool) $data['maintenance'] );
		}
		if ( isset( $data['message'] ) ) {
			update_option( 'captec_maintenance_message', sanitize_textarea_field( $data['message'] ) );
		}
		$this->log_activity( 'save_features', __( 'Funcionalidades do portal atualizadas.', 'captec-portal-admin' ), 'features', 0, array( 'maintenance' => ! empty( $data['maintenance'] ) ) );
		wp_send_json_success( array( 'message' => __( 'Funcionalidades atualizadas.', 'captec-portal-admin' ), 'features' => $this->features() ) );
	}

	public function ajax_ai_settings() {
		$this->guard_ajax();
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '{}';
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( 'Dados inválidos.', 'captec-portal-admin' ) ), 400 );
		}
		update_option( 'captec_ai_name', isset( $data['name'] ) ? sanitize_text_field( $data['name'] ) : 'Nina CAPTEC' );
		update_option( 'captec_ai_greeting', isset( $data['greeting'] ) ? sanitize_textarea_field( $data['greeting'] ) : "Oi! Meu nome é {nome}, seu assistente virtual!\n\nComo posso te ajudar?" );
		update_option( 'captec_ai_avatar_id', isset( $data['avatar_id'] ) ? absint( $data['avatar_id'] ) : 0 );
		// Remove configurações externas legadas: o agente é local e orientado ao portal.
		delete_option( 'captec_ai_provider' );
		delete_option( 'captec_ai_endpoint' );
		delete_option( 'captec_ai_model' );
		delete_option( 'captec_ai_api_key' );
		$this->log_activity( 'save_ai_layout', __( 'Layout do agente IA atualizado.', 'captec-portal-admin' ), 'assistant' );
		wp_send_json_success( array( 'message' => __( 'Layout do agente salvo.', 'captec-portal-admin' ), 'ai' => $this->ai_public_settings() ) );
	}

	private function ai_guidance( $normalized ) {
		$guides = function_exists( 'captec_portal_agent_knowledge' ) ? captec_portal_agent_knowledge() : array();
		foreach ( $guides as $guide ) {
			if ( empty( $guide['keywords'] ) || empty( $guide['guidance'] ) ) {
				continue;
			}
			foreach ( $guide['keywords'] as $keyword ) {
				if ( false !== strpos( $normalized, $keyword ) ) {
					return $guide['guidance'];
				}
			}
		}
		return '';
	}

	private function ai_local_proposal( $command ) {
		$normalized = strtolower( remove_accents( $command ) );
		if ( false !== strpos( $normalized, 'manutencao' ) ) {
			$enabled = false === strpos( $normalized, 'desativ' ) && false === strpos( $normalized, 'deslig' );
			return array( 'type' => 'maintenance', 'action' => array( 'enabled' => $enabled ), 'title' => $enabled ? __( 'Ativar modo de manutenção', 'captec-portal-admin' ) : __( 'Desativar modo de manutenção', 'captec-portal-admin' ), 'summary' => $enabled ? __( 'O site público exibirá uma mensagem de manutenção. Administradores continuarão com acesso.', 'captec-portal-admin' ) : __( 'O site público voltará a ficar disponível imediatamente.', 'captec-portal-admin' ) );
		}
		$feature_map = array( 'produtos' => 'products', 'aplicacoes' => 'applications', 'diferenciais' => 'differentials', 'processo' => 'process', 'indicadores' => 'stats', 'mapa' => 'map', 'unidades' => 'locations', 'filiais' => 'locations', 'conteudos' => 'blog', 'blog' => 'blog', 'cotacao' => 'quote', 'whatsapp' => 'whatsapp', 'video' => 'hero_video' );
		if ( false !== strpos( $normalized, 'ativar' ) || false !== strpos( $normalized, 'desativar' ) || false !== strpos( $normalized, 'desligar' ) ) {
			foreach ( $feature_map as $label => $feature ) {
				if ( false !== strpos( $normalized, $label ) ) {
					$enabled = false === strpos( $normalized, 'desativ' ) && false === strpos( $normalized, 'deslig' );
					return array( 'type' => 'feature_toggle', 'action' => array( 'feature' => $feature, 'enabled' => $enabled ), 'title' => sprintf( $enabled ? __( 'Ativar funcionalidade: %s', 'captec-portal-admin' ) : __( 'Inativar funcionalidade: %s', 'captec-portal-admin' ), $label ), 'summary' => __( 'Esta é uma prévia. A funcionalidade só será alterada depois da sua autorização.', 'captec-portal-admin' ) );
				}
			}
		}
		if ( preg_match( '/criar (?:um )?produto(?: chamado| com nome)?\s+(.+)/u', $command, $matches ) ) {
			$title = trim( $matches[1], " .,!?:;\"'" );
			if ( $title ) {
				return array( 'type' => 'create_product', 'action' => array( 'title' => $title ), 'title' => sprintf( __( 'Criar produto “%s”', 'captec-portal-admin' ), $title ), 'summary' => __( 'Será criado como rascunho para revisão antes da publicação.', 'captec-portal-admin' ) );
			}
		}
		if ( preg_match( '/criar (?:uma )?p(?:a|á)gina(?: chamada| com nome)?\s+(.+)/iu', $command, $matches ) ) {
			$title = trim( $matches[1], " .,!?:;\"'" );
			if ( $title ) {
				return array( 'type' => 'create_page', 'action' => array( 'title' => $title ), 'title' => sprintf( __( 'Criar página “%s”', 'captec-portal-admin' ), $title ), 'summary' => __( 'Será criada como rascunho para revisão antes da publicação.', 'captec-portal-admin' ) );
			}
		}
		if ( false !== strpos( $normalized, 'criar estrutura' ) || false !== strpos( $normalized, 'criar paginas do portal' ) ) {
			return array( 'type' => 'setup_pages', 'action' => array(), 'title' => __( 'Criar estrutura de páginas do portal', 'captec-portal-admin' ), 'summary' => __( 'Quem somos reunirá o institucional, Aplicações, Diferenciais e Processo. Serão criadas as páginas Quem somos, Produtos, Unidades, Cobertura, Conteúdos, Trabalhe conosco e Cotação, além do menu principal.', 'captec-portal-admin' ) );
		}
		$guidance = $this->ai_guidance( $normalized );
		if ( $guidance ) {
			return array( 'type' => 'guidance', 'action' => array(), 'title' => __( 'Orientação do agente', 'captec-portal-admin' ), 'summary' => $guidance );
		}
		return array( 'type' => 'guidance', 'action' => array(), 'title' => __( 'Orientação indisponível', 'captec-portal-admin' ), 'summary' => __( 'Não compreendi esta solicitação.
Entre em contato com o Administrador do site para receber orientação.', 'captec-portal-admin' ) );
	}

	public function ajax_ai_orient() {
		$this->guard_ajax();
		$question = isset( $_POST['question'] ) ? sanitize_textarea_field( wp_unslash( $_POST['question'] ) ) : '';
		if ( ! $question ) {
			wp_send_json_error( array( 'message' => __( 'Descreva sua dúvida para receber uma orientação.', 'captec-portal-admin' ) ), 400 );
		}
		$guidance = $this->ai_guidance( strtolower( remove_accents( $question ) ) );
		if ( ! $guidance ) {
			$guidance = __( 'Não compreendi esta solicitação.
Entre em contato com o Administrador do site para receber orientação.', 'captec-portal-admin' );
		}
		$this->log_activity( 'ai_guidance', __( 'Agente IA forneceu uma orientação.', 'captec-portal-admin' ), 'assistant' );
		wp_send_json_success( array( 'message' => $guidance ) );
	}

	public function ajax_ai_propose() {
		$this->guard_ajax();
		$command = isset( $_POST['command'] ) ? sanitize_textarea_field( wp_unslash( $_POST['command'] ) ) : '';
		if ( ! $command ) {
			wp_send_json_error( array( 'message' => __( 'Descreva uma tarefa para que o agente possa preparar uma prévia.', 'captec-portal-admin' ) ), 400 );
		}
		$proposal = $this->ai_local_proposal( $command );
		$proposal['command'] = $command;
		$proposal['requires_confirmation'] = 'guidance' !== $proposal['type'];
		$proposal['id'] = wp_generate_uuid4();
		set_transient( 'captec_ai_proposal_' . get_current_user_id() . '_' . $proposal['id'], $proposal, 15 * MINUTE_IN_SECONDS );
		$this->log_activity( 'ai_preview', sprintf( __( 'Agente IA gerou prévia: %s', 'captec-portal-admin' ), $proposal['title'] ), 'assistant', 0, array( 'type' => $proposal['type'] ) );
		wp_send_json_success( array( 'proposal' => $proposal ) );
	}

	public function ajax_ai_execute() {
		$this->guard_ajax();
		$id = isset( $_POST['proposal_id'] ) ? sanitize_text_field( wp_unslash( $_POST['proposal_id'] ) ) : '';
		$proposal = $id ? get_transient( 'captec_ai_proposal_' . get_current_user_id() . '_' . $id ) : false;
		if ( ! is_array( $proposal ) || empty( $proposal['type'] ) ) {
			wp_send_json_error( array( 'message' => __( 'A prévia expirou ou não foi encontrada. Solicite uma nova prévia.', 'captec-portal-admin' ) ), 404 );
		}
		$result = array();
		switch ( $proposal['type'] ) {
			case 'maintenance':
				update_option( 'captec_maintenance_enabled', ! empty( $proposal['action']['enabled'] ) );
				$result['message'] = ! empty( $proposal['action']['enabled'] ) ? __( 'Modo de manutenção ativado.', 'captec-portal-admin' ) : __( 'Modo de manutenção desativado.', 'captec-portal-admin' );
				$result['features'] = $this->features();
				break;
			case 'feature_toggle':
				$feature = isset( $proposal['action']['feature'] ) ? sanitize_key( $proposal['action']['feature'] ) : '';
				$allowed = array( 'hero_video', 'products', 'applications', 'differentials', 'process', 'stats', 'map', 'locations', 'blog', 'quote', 'whatsapp' );
				if ( ! in_array( $feature, $allowed, true ) ) {
					wp_send_json_error( array( 'message' => __( 'A funcionalidade proposta não é reconhecida.', 'captec-portal-admin' ) ), 400 );
				}
				set_theme_mod( 'captec_feature_' . $feature, ! empty( $proposal['action']['enabled'] ) ? '1' : '0' );
				$result['message'] = __( 'Funcionalidade atualizada após sua autorização.', 'captec-portal-admin' );
				$result['features'] = $this->features();
				break;
			case 'create_product':
				$post_id = wp_insert_post( array( 'post_type' => 'captec_product', 'post_status' => 'draft', 'post_title' => sanitize_text_field( $proposal['action']['title'] ) ), true );
				if ( is_wp_error( $post_id ) ) {
					wp_send_json_error( array( 'message' => $post_id->get_error_message() ), 500 );
				}
				$result['message'] = __( 'Produto criado como rascunho para sua revisão.', 'captec-portal-admin' );
				$result['item'] = $this->serialize_item( $post_id, 'product' );
				break;
			case 'create_page':
				$post_id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'draft', 'post_title' => sanitize_text_field( $proposal['action']['title'] ) ), true );
				if ( is_wp_error( $post_id ) ) {
					wp_send_json_error( array( 'message' => $post_id->get_error_message() ), 500 );
				}
				$result['message'] = __( 'Página criada como rascunho para sua revisão.', 'captec-portal-admin' );
				$result['item'] = $this->serialize_item( $post_id, 'page' );
				break;
			case 'setup_pages':
				$this->setup_portal_pages();
				$result['message'] = __( 'Estrutura de páginas criada e menu principal configurado.', 'captec-portal-admin' );
				$result['pages'] = $this->list_items( 'page', 50 );
				break;
			default:
				wp_send_json_error( array( 'message' => __( 'Esta orientação não possui uma execução automática.', 'captec-portal-admin' ) ), 400 );
		}
		delete_transient( 'captec_ai_proposal_' . get_current_user_id() . '_' . $id );
		$this->log_activity( 'ai_execute', sprintf( __( 'Agente IA executou: %s', 'captec-portal-admin' ), $proposal['title'] ), 'assistant', 0, array( 'type' => $proposal['type'] ) );
		$result['dashboard'] = $this->dashboard();
		wp_send_json_success( $result );
	}

	public function ajax_traffic_report() {
		$this->guard_ajax();
		if ( ! class_exists( 'CAPTEC_Traffic_Analytics' ) ) {
			wp_send_json_error( array( 'message' => __( 'O plugin Tráfego CAPTEC não está ativo. Instale ou ative o plugin para visualizar dados locais.', 'captec-portal-admin' ) ), 400 );
		}
		$period = isset( $_POST['period'] ) ? sanitize_key( wp_unslash( $_POST['period'] ) ) : '30days';
		$start  = isset( $_POST['start'] ) ? sanitize_text_field( wp_unslash( $_POST['start'] ) ) : '';
		$end    = isset( $_POST['end'] ) ? sanitize_text_field( wp_unslash( $_POST['end'] ) ) : '';
		$traffic = CAPTEC_Traffic_Analytics::instance();
		$report = $traffic->get_portal_report( $period, $start, $end );
		$health = $traffic->health();
		$this->log_activity( 'view_traffic', __( 'Dashboard de tráfego local consultado.', 'captec-portal-admin' ), 'traffic', 0, array( 'period' => $period ) );
		wp_send_json_success( array( 'report' => $report, 'health' => $health ) );
	}

	public function ajax_bootstrap() {
		$this->guard_ajax();
		wp_send_json_success( $this->boot_payload() );
	}

	public function ajax_save_settings() {
		$this->guard_ajax();
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '{}';
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( 'Dados inválidos.', 'captec-portal-admin' ) ), 400 );
		}
		$schema = $this->setting_schema();
		$draft  = $this->draft_settings();
		foreach ( $data as $key => $value ) {
			if ( ! isset( $schema[ $key ] ) ) {
				continue;
			}
			$definition = $schema[ $key ];
			if ( 'option_text' === $definition['kind'] ) {
				$draft[ $key ] = sanitize_text_field( (string) $value );
			} elseif ( 'logo' === $definition['kind'] ) {
				$draft[ $key ] = absint( $value );
			} else {
				$draft[ $key ] = $this->sanitize_setting( $value, $definition['kind'] );
			}
		}
		update_option( 'captec_portal_draft_settings', $draft, false );
		$this->log_activity( 'save_settings_draft', __( 'Rascunho de configurações salvo para prévia.', 'captec-portal-admin' ), 'settings', 0, array( 'fields' => array_keys( $data ) ) );
		wp_send_json_success( array(
			'message'  => __( 'Rascunho salvo. Abra Pré-visualizar portal para revisar antes de publicar.', 'captec-portal-admin' ),
			'settings' => $this->settings(),
			'dashboard'=> $this->dashboard(),
			'draft_settings_count' => count( $draft ),
		) );
	}

	public function ajax_publish_settings() {
		$this->guard_ajax();
		$draft = $this->draft_settings();
		if ( ! $draft ) {
			wp_send_json_success( array( 'message' => __( 'Não há configurações pendentes para publicar.', 'captec-portal-admin' ), 'settings' => $this->settings(), 'draft_settings_count' => 0 ) );
		}
		$schema = $this->setting_schema();
		foreach ( $draft as $key => $value ) {
			if ( ! isset( $schema[ $key ] ) ) {
				continue;
			}
			$kind = $schema[ $key ]['kind'];
			if ( 'option_text' === $kind ) {
				update_option( 'site_title' === $key ? 'blogname' : 'blogdescription', sanitize_text_field( (string) $value ) );
			} elseif ( 'logo' === $kind ) {
				set_theme_mod( 'custom_logo', absint( $value ) );
			} else {
				set_theme_mod( $key, $this->sanitize_setting( $value, $kind ) );
			}
		}
		delete_option( 'captec_portal_draft_settings' );
		$this->log_activity( 'publish_settings', __( 'Rascunho de configurações publicado.', 'captec-portal-admin' ), 'settings' );
		wp_send_json_success( array(
			'message'  => __( 'Configurações publicadas no portal.', 'captec-portal-admin' ),
			'settings' => $this->settings(),
			'dashboard'=> $this->dashboard(),
			'draft_settings_count' => 0,
		) );
	}

	public function ajax_toggle_item_status() {
		$this->guard_ajax();
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$type = isset( $_POST['content_type'] ) ? sanitize_key( wp_unslash( $_POST['content_type'] ) ) : '';
		$post_type = $this->post_type_for( $type );
		$allowed = array( 'product', 'application', 'location', 'article', 'page', 'button', 'footer_item', 'stat' );
		if ( ! $id || ! in_array( $type, $allowed, true ) || ! $post_type || get_post_type( $id ) !== $post_type ) {
			wp_send_json_error( array( 'message' => __( 'Item inválido para alterar o status.', 'captec-portal-admin' ) ), 400 );
		}
		$current = get_post_status( $id );
		$target = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : ( 'publish' === $current ? 'draft' : 'publish' );
		if ( ! in_array( $target, array( 'publish', 'draft' ), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Status não reconhecido.', 'captec-portal-admin' ) ), 400 );
		}
		$result = wp_update_post( array( 'ID' => $id, 'post_status' => $target ), true );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 500 );
		}
		if ( 'button' === $type ) {
			$slot = sanitize_key( get_post_meta( $id, '_captec_button_slot', true ) );
			$hidden = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_hidden_buttons', array() ) ) ) ) );
			if ( 'publish' === $target ) {
				$hidden = array_values( array_diff( $hidden, array( $slot ) ) );
			} elseif ( $slot && ! in_array( $slot, $hidden, true ) ) {
				$hidden[] = $slot;
			}
			update_option( 'captec_hidden_buttons', $hidden, false );
		}
		if ( 'footer_item' === $type ) {
			$section = sanitize_key( get_post_meta( $id, '_captec_footer_section', true ) );
			$sections = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_footer_configured_sections', array() ) ) ) ) );
			if ( $section && ! in_array( $section, $sections, true ) ) {
				$sections[] = $section;
				update_option( 'captec_footer_configured_sections', $sections, false );
			}
		}
		if ( 'stat' === $type ) {
			update_option( 'captec_stats_configured', 1, false );
		}
		$this->log_activity( 'toggle_' . $type . '_status', sprintf( __( '%1$s alterado para %2$s.', 'captec-portal-admin' ), $type, 'publish' === $target ? __( 'publicado', 'captec-portal-admin' ) : __( 'rascunho', 'captec-portal-admin' ) ), $type, $id );
		wp_send_json_success( array( 'message' => __( 'Status atualizado.', 'captec-portal-admin' ), 'item' => $this->serialize_item( $id, $type ), 'dashboard' => $this->dashboard() ) );
	}

	public function ajax_save_item() {
		$this->guard_ajax();
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '{}';
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || empty( $data['type'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Dados do item inválidos.', 'captec-portal-admin' ) ), 400 );
		}
		$type      = sanitize_key( $data['type'] );
		$post_type = $this->post_type_for( $type );
		if ( ! in_array( $type, array( 'product', 'application', 'location', 'article', 'page', 'button', 'footer_item', 'stat' ), true ) || ! $post_type || ! post_type_exists( $post_type ) ) {
			wp_send_json_error( array( 'message' => __( 'Este tipo de conteúdo não está disponível.', 'captec-portal-admin' ) ), 400 );
		}

		$id = isset( $data['id'] ) ? absint( $data['id'] ) : 0;
		$previous_button_slot = ( $id && 'button' === $type ) ? sanitize_key( get_post_meta( $id, '_captec_button_slot', true ) ) : '';
		if ( $id && get_post_type( $id ) !== $post_type ) {
			wp_send_json_error( array( 'message' => __( 'O item informado não corresponde ao tipo de conteúdo.', 'captec-portal-admin' ) ), 400 );
		}
		$title = isset( $data['title'] ) ? sanitize_text_field( $data['title'] ) : '';
		if ( ! $title ) {
			wp_send_json_error( array( 'message' => __( 'Informe um título para continuar.', 'captec-portal-admin' ) ), 400 );
		}
		$status = isset( $data['status'] ) && in_array( $data['status'], array( 'publish', 'draft' ), true ) ? $data['status'] : 'publish';
		if ( 'button' === $type ) {
			$slot = isset( $data['slot'] ) ? sanitize_key( $data['slot'] ) : '';
			$slots = $this->button_slots();
			if ( ! $slot || ! isset( $slots[ $slot ] ) ) {
				wp_send_json_error( array( 'message' => __( 'Escolha a área do site onde o botão será exibido.', 'captec-portal-admin' ) ), 400 );
			}
			$duplicates = get_posts( array( 'post_type' => 'captec_button', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => -1, 'meta_key' => '_captec_button_slot', 'meta_value' => $slot, 'fields' => 'ids' ) );
			foreach ( $duplicates as $duplicate_id ) {
				if ( ! $id || (int) $duplicate_id !== (int) $id ) {
					wp_send_json_error( array( 'message' => __( 'Já existe um botão configurado nesta área. Edite-o ou exclua-o antes de criar outro.', 'captec-portal-admin' ) ), 409 );
				}
			}
		}
		if ( 'footer_item' === $type ) {
			$section = isset( $data['section'] ) ? sanitize_key( $data['section'] ) : '';
			$sections = $this->footer_sections();
			if ( ! $section || ! isset( $sections[ $section ] ) ) {
				wp_send_json_error( array( 'message' => __( 'Escolha uma área válida do rodapé.', 'captec-portal-admin' ) ), 400 );
			}
		}
		$content = isset( $data['content'] ) ? wp_kses_post( $data['content'] ) : '';
		if ( 'product' === $type && isset( $data['description'] ) ) {
			$content = sanitize_textarea_field( $data['description'] );
		}
		$postarr = array(
			'ID'           => $id,
			'post_type'    => $post_type,
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => $status,
			'menu_order'   => isset( $data['order'] ) ? absint( $data['order'] ) : 0,
			'post_excerpt' => 'article' === $type && isset( $data['excerpt'] ) ? sanitize_textarea_field( $data['excerpt'] ) : '',
		);
		if ( 'page' === $type && ! empty( $data['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( $data['slug'] );
		}
		if ( ! $id ) {
			$postarr['post_author'] = get_current_user_id();
		}
		$post_id = $id ? wp_update_post( $postarr, true ) : wp_insert_post( $postarr, true );
		if ( is_wp_error( $post_id ) || ! $post_id ) {
			wp_send_json_error( array( 'message' => is_wp_error( $post_id ) ? $post_id->get_error_message() : __( 'Não foi possível salvar o item.', 'captec-portal-admin' ) ), 500 );
		}
		if ( 'page' === $type && 'inicio' === get_post_field( 'post_name', $post_id ) ) {
			$this->sync_portal_page_content( $post_id, 'inicio' );
		}

		$image_id = isset( $data['image_id'] ) ? absint( $data['image_id'] ) : 0;
		if ( $image_id ) {
			set_post_thumbnail( $post_id, $image_id );
		} elseif ( isset( $data['clear_image'] ) && $data['clear_image'] ) {
			delete_post_thumbnail( $post_id );
		}
		if ( 'product' === $type ) {
			update_post_meta( $post_id, '_captec_product_type', isset( $data['product_type'] ) ? sanitize_text_field( $data['product_type'] ) : '' );
			update_post_meta( $post_id, '_captec_product_description', isset( $data['description'] ) ? sanitize_textarea_field( $data['description'] ) : '' );
			update_post_meta( $post_id, '_captec_product_applications', isset( $data['applications'] ) ? sanitize_textarea_field( $data['applications'] ) : '' );
			update_post_meta( $post_id, '_captec_product_file', isset( $data['file_url'] ) ? esc_url_raw( $data['file_url'] ) : '' );
		}
		if ( 'application' === $type ) {
			update_post_meta( $post_id, '_captec_application_subtitle', isset( $data['subtitle'] ) ? sanitize_text_field( $data['subtitle'] ) : '' );
		}
		if ( 'button' === $type ) {
			$slot = sanitize_key( $data['slot'] );
			$action = isset( $data['action'] ) && in_array( $data['action'], array( 'quote', 'whatsapp', 'career_email', 'url' ), true ) ? $data['action'] : 'url';
			$style = isset( $data['style'] ) && in_array( $data['style'], array( 'yellow', 'dark', 'ghost', 'line' ), true ) ? $data['style'] : 'yellow';
			$target = isset( $data['target'] ) && 'new' === $data['target'] ? 'new' : 'same';
			$position = isset( $data['position'] ) && in_array( $data['position'], array( 'left', 'center', 'right', 'default' ), true ) ? $data['position'] : 'default';
			update_post_meta( $post_id, '_captec_button_slot', $slot );
			update_post_meta( $post_id, '_captec_button_label', isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : $title );
			update_post_meta( $post_id, '_captec_button_action', $action );
			update_post_meta( $post_id, '_captec_button_url', isset( $data['url'] ) ? esc_url_raw( $data['url'] ) : '' );
			update_post_meta( $post_id, '_captec_button_style', $style );
			update_post_meta( $post_id, '_captec_button_target', $target );
			update_post_meta( $post_id, '_captec_button_position', $position );
			$hidden = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_hidden_buttons', array() ) ) ) ) );
			if ( $previous_button_slot && $previous_button_slot !== $slot && ! in_array( $previous_button_slot, $hidden, true ) ) {
				$hidden[] = $previous_button_slot;
			}
			if ( 'publish' === $status ) {
				$hidden = array_values( array_diff( $hidden, array( $slot ) ) );
			} elseif ( $slot && ! in_array( $slot, $hidden, true ) ) {
				$hidden[] = $slot;
			}
			update_option( 'captec_hidden_buttons', $hidden, false );
		}
		if ( 'footer_item' === $type ) {
			$section = sanitize_key( $data['section'] );
			$kind = isset( $data['kind'] ) && 'text' === $data['kind'] ? 'text' : 'link';
			$action = isset( $data['action'] ) && in_array( $data['action'], array( 'home', 'quote', 'whatsapp', 'phone', 'email', 'privacy', 'cookies', 'maps', 'url' ), true ) ? $data['action'] : 'url';
			$target = isset( $data['target'] ) && 'new' === $data['target'] ? 'new' : 'same';
			update_post_meta( $post_id, '_captec_footer_section', $section );
			update_post_meta( $post_id, '_captec_footer_label', isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : $title );
			update_post_meta( $post_id, '_captec_footer_kind', $kind );
			update_post_meta( $post_id, '_captec_footer_action', $action );
			update_post_meta( $post_id, '_captec_footer_url', isset( $data['url'] ) ? esc_url_raw( $data['url'] ) : '' );
			update_post_meta( $post_id, '_captec_footer_target', $target );
			$sections = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_footer_configured_sections', array() ) ) ) ) );
			if ( ! in_array( $section, $sections, true ) ) {
				$sections[] = $section;
			}
			update_option( 'captec_footer_configured_sections', $sections, false );
		}
		if ( 'stat' === $type ) {
			update_post_meta( $post_id, '_captec_stat_label', isset( $data['label'] ) ? sanitize_text_field( $data['label'] ) : $title );
			update_post_meta( $post_id, '_captec_stat_value', isset( $data['value'] ) ? sanitize_text_field( $data['value'] ) : '' );
			update_option( 'captec_stats_configured', 1, false );
		}
		if ( 'location' === $type ) {
			$location_fields = array( 'kind', 'company_name', 'cnpj', 'street', 'number', 'complement', 'neighborhood', 'city', 'state', 'cep', 'phone', 'email', 'map_url' );
			foreach ( $location_fields as $field ) {
				$value = isset( $data[ $field ] ) ? $data[ $field ] : '';
				if ( 'map_url' === $field ) {
					$value = esc_url_raw( $value );
				} elseif ( 'email' === $field ) {
					$value = sanitize_email( $value );
				} elseif ( 'state' === $field ) {
					$value = strtoupper( preg_replace( '/[^A-Za-z]/', '', sanitize_text_field( $value ) ) );
				} elseif ( 'kind' === $field ) {
					$value = in_array( $value, array( 'headquarters', 'branch' ), true ) ? $value : 'branch';
				} else {
					$value = sanitize_text_field( $value );
				}
				update_post_meta( $post_id, '_captec_location_' . $field, $value );
			}
		}
		if ( 'article' === $type ) {
			$category_id = isset( $data['category_id'] ) ? absint( $data['category_id'] ) : 0;
			if ( ! empty( $data['category_name'] ) ) {
				$category_id = $this->ensure_article_category( $data['category_name'] );
			} elseif ( isset( $data['category_id'] ) && ! $category_id ) {
				$category_id = absint( get_option( 'default_category', 0 ) );
			}
			if ( $category_id ) {
				wp_set_post_categories( $post_id, array( $category_id ), false );
			}
		}

		$this->log_activity( $id ? 'update_' . $type : 'create_' . $type, sprintf( $id ? __( '%1$s atualizado: %2$s', 'captec-portal-admin' ) : __( '%1$s criado: %2$s', 'captec-portal-admin' ), $type, $title ), $type, $post_id );

		wp_send_json_success( array(
			'message' => __( 'Item salvo com sucesso.', 'captec-portal-admin' ),
			'item'    => $this->serialize_item( $post_id, $type ),
			'categories' => 'article' === $type ? $this->article_categories() : array(),
			'dashboard' => $this->dashboard(),
		) );
	}

	public function ajax_delete_item() {
		$this->guard_ajax();
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$type = isset( $_POST['content_type'] ) ? sanitize_key( wp_unslash( $_POST['content_type'] ) ) : '';
		$post_type = $this->post_type_for( $type );
		if ( ! $id || ! in_array( $type, array( 'product', 'application', 'location', 'article', 'page', 'button', 'footer_item', 'stat' ), true ) || get_post_type( $id ) !== $post_type ) {
			wp_send_json_error( array( 'message' => __( 'Item inválido para exclusão.', 'captec-portal-admin' ) ), 400 );
		}
		if ( 'button' === $type ) {
			$slot = sanitize_key( get_post_meta( $id, '_captec_button_slot', true ) );
			$hidden = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_hidden_buttons', array() ) ) ) ) );
			if ( $slot && ! in_array( $slot, $hidden, true ) ) {
				$hidden[] = $slot;
				update_option( 'captec_hidden_buttons', $hidden, false );
			}
		}
		if ( 'footer_item' === $type ) {
			$section = sanitize_key( get_post_meta( $id, '_captec_footer_section', true ) );
			$sections = array_values( array_unique( array_filter( array_map( 'sanitize_key', (array) get_option( 'captec_footer_configured_sections', array() ) ) ) ) );
			if ( $section && ! in_array( $section, $sections, true ) ) {
				$sections[] = $section;
				update_option( 'captec_footer_configured_sections', $sections, false );
			}
		}
		if ( 'stat' === $type ) {
			update_option( 'captec_stats_configured', 1, false );
		}
		if ( ! wp_trash_post( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'Não foi possível mover o item para a lixeira.', 'captec-portal-admin' ) ), 500 );
		}
		$this->log_activity( 'delete_' . $type, sprintf( __( '%s movido para a lixeira.', 'captec-portal-admin' ), $type ), $type, $id );
		wp_send_json_success( array( 'message' => __( 'Item movido para a lixeira.', 'captec-portal-admin' ), 'id' => $id, 'dashboard' => $this->dashboard() ) );
	}

	public function ajax_save_quote() {
		$this->guard_ajax();
		$raw  = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '{}';
		$data = json_decode( $raw, true );
		$id   = is_array( $data ) && isset( $data['id'] ) ? absint( $data['id'] ) : 0;
		if ( ! $id || 'captec_quote' !== get_post_type( $id ) ) {
			wp_send_json_error( array( 'message' => __( 'Cotação não encontrada.', 'captec-portal-admin' ) ), 404 );
		}
		$allowed = array( 'new', 'in_progress', 'won', 'archived' );
		$status  = isset( $data['workflow_status'] ) && in_array( $data['workflow_status'], $allowed, true ) ? $data['workflow_status'] : 'new';
		update_post_meta( $id, '_captec_quote_status', $status );
		update_post_meta( $id, '_captec_quote_internal_note', isset( $data['internal_note'] ) ? sanitize_textarea_field( $data['internal_note'] ) : '' );
		$this->log_activity( 'update_quote', __( 'Status de cotação atualizado.', 'captec-portal-admin' ), 'quote', $id, array( 'status' => $status ) );
		wp_send_json_success( array( 'message' => __( 'Cotação atualizada.', 'captec-portal-admin' ), 'item' => $this->serialize_item( $id, 'quote' ) ) );
	}

	private function default_products() {
		return array(
			array( 'title' => 'CAP 30/45', 'type' => 'Cimento asfáltico', 'description' => 'Cimento asfáltico de petróleo para projetos com especificação CAP 30/45.', 'applications' => 'Aplicações definidas em projeto e especificação técnica.' ),
			array( 'title' => 'CAP 50/70', 'type' => 'Cimento asfáltico', 'description' => 'Cimento asfáltico de petróleo para projetos com especificação CAP 50/70.', 'applications' => 'Aplicações definidas em projeto e especificação técnica.' ),
			array( 'title' => 'RR-1C', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica catiônica de ruptura rápida, conforme a demanda da obra.', 'applications' => 'Aplicações definidas no projeto de pavimentação.' ),
			array( 'title' => 'RR-2C', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica catiônica de ruptura rápida para aplicações previstas em especificação.', 'applications' => 'Aplicações definidas no projeto de pavimentação.' ),
			array( 'title' => 'RL-1C', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica catiônica de ruptura lenta, conforme a demanda técnica da obra.', 'applications' => 'Aplicações previstas em especificação.' ),
			array( 'title' => 'EAI', 'type' => 'Emulsão asfáltica', 'description' => 'Emulsão asfáltica para imprimação, conforme a solução técnica definida para a obra.', 'applications' => 'Preparação de base, conforme especificação.' ),
			array( 'title' => 'Asfaltos Modificados', 'type' => 'Soluções especiais', 'description' => 'Soluções para requisitos específicos de desempenho e projeto.', 'applications' => 'Projetos com necessidades técnicas particulares.' ),
		);
	}

	private function default_locations() {
		return array(
			array( 'title' => 'Matriz — Duque de Caxias/RJ', 'kind' => 'headquarters', 'company_name' => 'CAPTEC ASFALTOS LTDA', 'cnpj' => '63.476.653/0001-61', 'street' => 'R. Mascarenhas de Morais', 'number' => '2105', 'complement' => 'Quadra 24F, Lote 34', 'neighborhood' => 'Figueira', 'city' => 'Duque de Caxias', 'state' => 'RJ', 'cep' => '25.231-050', 'phone' => '(92) 9556-2152', 'email' => 'captec.asfalto@hotmail.com' ),
			array( 'title' => 'Filial — Salvador/BA', 'kind' => 'branch', 'company_name' => 'CAPTEC ASFALTOS LTDA', 'cnpj' => '63.476.653/0002-42', 'street' => 'R. da Mauritânia', 'number' => '40', 'complement' => 'Galpão 0002', 'neighborhood' => 'Granjas Rurais Presidente Vargas', 'city' => 'Salvador', 'state' => 'BA', 'cep' => '41.230-040', 'phone' => '(92) 9556-2152', 'email' => 'captec.asfalto@hotmail.com' ),
			array( 'title' => 'Filial — Manaus/AM', 'kind' => 'branch', 'company_name' => 'CAPTEC ASFALTOS LTDA', 'cnpj' => '63.476.653/0003-23', 'street' => 'BC Jurema', 'number' => '50', 'complement' => '', 'neighborhood' => 'Vila Buriti', 'city' => 'Manaus', 'state' => 'AM', 'cep' => '69.072-010', 'phone' => '(92) 9472-3574', 'email' => 'captec.asfalto@hotmail.com' ),
		);
	}

	private function default_applications() {
		return array(
			array( 'title' => 'Rodovias', 'subtitle' => 'Infraestrutura viária' ),
			array( 'title' => 'Pavimentação Urbana', 'subtitle' => 'Cidades em movimento' ),
			array( 'title' => 'Condomínios', 'subtitle' => 'Acessos e vias internas' ),
			array( 'title' => 'Portos', 'subtitle' => 'Áreas logísticas' ),
			array( 'title' => 'Aeroportos', 'subtitle' => 'Operações aeroportuárias' ),
			array( 'title' => 'Concessionárias', 'subtitle' => 'Manutenção viária' ),
			array( 'title' => 'Prefeituras', 'subtitle' => 'Infraestrutura urbana' ),
			array( 'title' => 'Obras Industriais', 'subtitle' => 'Pátios e acessos' ),
		);
	}

	private function seed_catalog() {
		if ( ! post_type_exists( 'captec_product' ) || ! post_type_exists( 'captec_application' ) || ! post_type_exists( 'captec_location' ) ) {
			return new WP_Error( 'captec_missing_types', __( 'Ative a versão atual do tema CAPTEC Asfaltos antes de criar a estrutura pelo painel.', 'captec-portal-admin' ) );
		}
		$created = array( 'products' => 0, 'applications' => 0, 'locations' => 0 );
		if ( ! $this->count_posts( 'captec_product', 'publish' ) && ! $this->count_posts( 'captec_product', 'draft' ) ) {
			foreach ( $this->default_products() as $order => $item ) {
				$id = wp_insert_post( array( 'post_type' => 'captec_product', 'post_status' => 'publish', 'post_title' => $item['title'], 'post_content' => $item['description'], 'menu_order' => $order ), true );
				if ( ! is_wp_error( $id ) ) {
					update_post_meta( $id, '_captec_product_type', $item['type'] );
					update_post_meta( $id, '_captec_product_description', $item['description'] );
					update_post_meta( $id, '_captec_product_applications', $item['applications'] );
					++$created['products'];
				}
			}
		}
		if ( ! $this->count_posts( 'captec_application', 'publish' ) && ! $this->count_posts( 'captec_application', 'draft' ) ) {
			foreach ( $this->default_applications() as $order => $item ) {
				$id = wp_insert_post( array( 'post_type' => 'captec_application', 'post_status' => 'publish', 'post_title' => $item['title'], 'menu_order' => $order ), true );
				if ( ! is_wp_error( $id ) ) {
					update_post_meta( $id, '_captec_application_subtitle', $item['subtitle'] );
					++$created['applications'];
				}
			}
		}
		if ( ! $this->count_posts( 'captec_location', 'publish' ) && ! $this->count_posts( 'captec_location', 'draft' ) ) {
			foreach ( $this->default_locations() as $order => $item ) {
				$id = wp_insert_post( array( 'post_type' => 'captec_location', 'post_status' => 'publish', 'post_title' => $item['title'], 'menu_order' => $order ), true );
				if ( ! is_wp_error( $id ) ) {
					foreach ( $item as $key => $value ) {
						if ( 'title' !== $key ) {
							update_post_meta( $id, '_captec_location_' . $key, $value );
						}
					}
					++$created['locations'];
				}
			}
		}
		update_option( 'captec_portal_seed_catalog', '0', false );
		return $created;
	}

	public function maybe_seed_catalog() {
		if ( '1' !== get_option( 'captec_portal_seed_catalog', '0' ) ) {
			return;
		}
		$this->seed_catalog();
	}

	public function ajax_seed_catalog() {
		$this->guard_ajax();
		$result = $this->seed_catalog();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}
		$this->log_activity( 'seed_catalog', __( 'Catálogo inicial, aplicações e unidades preparados.', 'captec-portal-admin' ), 'catalog' );
		wp_send_json_success( array(
			'message'      => sprintf( __( 'Estrutura preparada: %1$d produtos, %2$d aplicações e %3$d unidades criadas.', 'captec-portal-admin' ), $result['products'], $result['applications'], $result['locations'] ),
			'products'     => $this->list_items( 'product' ),
			'applications' => $this->list_items( 'application' ),
			'locations'    => $this->list_items( 'location' ),
			'dashboard'    => $this->dashboard(),
		) );
	}
}

register_activation_hook( __FILE__, array( 'CAPTEC_Portal_Admin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CAPTEC_Portal_Admin', 'deactivate' ) );
CAPTEC_Portal_Admin::instance();

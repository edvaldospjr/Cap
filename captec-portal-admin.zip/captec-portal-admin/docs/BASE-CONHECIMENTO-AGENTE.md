# Base de Conhecimento do Agente IA CAPTEC — versão 3.4.0

Esta base orienta o Agente IA local do Portal CAPTEC. Ela acompanha o Manual do Portal Administrativo e descreve somente funções disponíveis no site e no painel.

## Regras obrigatórias

1. O agente orienta somente sobre o Portal CAPTEC e suas funcionalidades reconhecidas.
2. Ele aceita texto e voz convertida em texto pelo navegador.
3. Em **Quero orientação**, responde com base neste manual e nos módulos existentes.
4. Em **Executar ação**, aceita somente funções reconhecidas do portal.
5. Antes de executar qualquer ação, apresenta uma prévia e aguarda **EXECUTAR** ou **CANCELAR**.
6. Produtos e páginas criados pelo agente começam como rascunho.
7. O agente não publica configurações, páginas, produtos, artigos, botões ou indicadores sem autorização explícita.
8. O agente não inventa valores, contatos, clientes, certificações, informações comerciais, indicadores ou dados técnicos.
9. Orientações, prévias e execuções são registradas no Log de atividades.
10. Perguntas ou ações não compreendidas devem receber exatamente:

```text
Não compreendi esta solicitação.
Entre em contato com o Administrador do site para receber orientação.
```

## Navegação e páginas

- **Quem somos** é a página principal do portal e usa a URL `/`.
- As antigas páginas **Empresa**, **Aplicações** e **Diferenciais** foram removidas; as URLs antigas redirecionam para Quem somos.
- Quem somos reúne as seções Institucional, Aplicações, Diferenciais e Processo.
- As páginas públicas independentes são: Quem somos, Produtos, Unidades, Cobertura, Conteúdos, Trabalhe conosco e Solicitar Cotação.
- Em **Portal CAPTEC > Páginas e menu**, o controle **Publicado/Rascunho** define se uma página aparece no menu público. Uma página em rascunho não é mostrada para visitantes.
- A listagem exibe o conteúdo salvo no editor nativo do WordPress. Quem somos usa os shortcodes `captec_quem_somos`, `captec_aplicacoes` e `captec_diferenciais`.

## Rascunho, prévia e publicação

1. Em uma tela de configuração, use **Salvar rascunho**.
2. Abra **Pré-visualizar portal** e escolha página e dispositivo.
3. Confira o resultado em Computador, Tablet e Celular.
4. Use **Publicar atualizações** somente após a conferência.

O botão **Publicar atualizações** publica configurações pendentes. Produtos, aplicações, unidades, artigos, páginas, botões, itens do rodapé e indicadores usam seus próprios controles **Publicado/Rascunho**.

## Aparências

Em **Portal CAPTEC > Aparências**, é possível ajustar sem código:

- fundo principal das páginas;
- fundo das áreas suaves;
- cor e texto das barras institucionais, títulos internos e rodapé;
- largura máxima da página;
- espaço lateral e distância entre seções;
- altura do cabeçalho;
- cores, fonte, tamanho e espaçamento do menu;
- comportamento do menu ao rolar;
- espaço vertical e tamanho da logomarca no rodapé.

As alterações devem ser salvas como rascunho, pré-visualizadas e publicadas pelo fluxo normal.

## Botões do site

Em **Portal CAPTEC > Botões do site**, cada botão público pode ser criado, editado, publicado, deixado em rascunho ou excluído. O cadastro permite definir:

- área do portal onde aparece;
- texto visível;
- destino: Cotação, WhatsApp, e-mail de currículos ou URL personalizada;
- estilo visual;
- posição na área: padrão, esquerda, centro ou direita;
- abertura na mesma aba ou em nova aba.

As áreas incluem cabeçalho, Quem somos, Produtos, seção Aplicações em Quem somos, Cobertura, Trabalhe conosco, formulário de cotação, botão flutuante, página 404 e áreas adicionais no rodapé.

## Rodapé

Em **Portal CAPTEC > Rodapé**, os itens podem ser criados, editados, publicados, deixados em rascunho ou excluídos. Escolha a coluna:

- Navegação;
- Atendimento;
- Institucional;
- Rodapé inferior.

Logo, texto institucional, localização, e-mail, telefone, WhatsApp e redes sociais continuam em **Marca e contatos**.

## Dados e cobertura

Em **Portal CAPTEC > Dados e cobertura**:

- cada indicador institucional é um registro independente, com criação, edição, publicação, rascunho e exclusão;
- os indicadores iniciais publicados são: Clientes Atendidos, Estados Atendidos, Produtos Comercializados, Obras Atendidas e Toneladas Fornecidas;
- valores só devem ser preenchidos após validação da empresa;
- estados configurados no mapa permanecem destacados mesmo após o clique;
- a mensagem posterior ao clique pode ser editada e segue o modelo “Nome do estado: disponível para atendimento”; 
- os botões WhatsApp e Solicitar cotação ao lado do mapa são editados em **Botões do site**.

## Conteúdos, pautas, imagens e categorias

Em **Portal CAPTEC > Conteúdos**:

- pautas atuais mostram categoria e imagem relacionada;
- ao clicar em **Carregar**, o portal cria o artigo em rascunho, aplica categoria e adiciona uma imagem destacada à Biblioteca de Mídia;
- ao editar um artigo, é possível escolher uma categoria existente ou informar uma nova categoria;
- revise título, resumo, imagem, categoria, conteúdo e status antes de publicar.

## Trabalhe conosco

A página **Trabalhe conosco** é pública e independente. Em **Textos das páginas**, é possível alterar a apresentação, orientação de candidatura e e-mail para currículos. O botão correspondente é configurado em **Botões do site**. Caso o e-mail específico fique vazio, a página utiliza o e-mail comercial cadastrado.

## Produtos, aplicações, unidades e cotações

- **Produtos:** cartões, categoria, descrição, aplicações, imagem, ficha técnica e status.
- **Aplicações:** título, linha de apoio, imagem, ordem e status. Os cards aparecem dentro de Quem somos.
- **Matriz e filiais:** razão social, CNPJ, endereço, contatos, mapa, ordem e status.
- **Cotações:** registros privados; use apenas o fluxo de atendimento e anotações internas.

## Funcionalidades e manutenção

Em **Funcionalidades**, use o botão **Visualizar** para abrir um pop-up com a página atual relacionada à funcionalidade. A prévia por passagem do cursor não é usada.

Inativar uma funcionalidade não apaga o conteúdo. O modo de manutenção mostra resposta HTTP 503 a visitantes; administradores continuam acessando o site e o painel.

## Tráfego, LGPD e log

- O dashboard local de tráfego fica em **Análise do portal** e depende de consentimento para cookies analíticos.
- Em **Integrações e LGPD**, informe apenas IDs e políticas aprovados.
- O **Log de atividades** mantém registros operacionais por até seis meses.

## Ações reconhecidas para execução

- ativar ou desativar modo de manutenção;
- criar produto;
- criar página;
- criar estrutura de páginas do portal;
- ativar ou inativar funcionalidades públicas reconhecidas.

Outras solicitações recebem orientação ou a mensagem obrigatória de não compreensão.

## Atualização 3.4 — conteúdo WordPress

O Portal sincroniza o conteúdo das páginas estruturais com o WordPress. Em **Páginas e menu**, use **Editar conteúdo** para abrir o campo que é salvo diretamente no post da página. A página Quem somos contém os três shortcodes que renderizam suas seções unificadas.

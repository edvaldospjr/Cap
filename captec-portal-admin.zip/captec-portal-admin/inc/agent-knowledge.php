<?php
/** Base de conhecimento operacional derivada do Manual do Portal CAPTEC. */

defined( 'ABSPATH' ) || exit;

function captec_portal_agent_knowledge() {
	return array(
		array(
			'keywords' => array( 'aparencias', 'aparencia', 'cor da pagina', 'cor das paginas', 'fundo', 'barras', 'largura da pagina', 'tamanho da pagina', 'espacamento', 'espaco da pagina', 'cabecalho', 'altura do cabecalho', 'fonte do menu', 'cor do menu', 'menu' ),
			'guidance' => __( 'Para ajustar fundo, barras, largura, espaços, cabeçalho, menu ou rodapé, abra Portal CAPTEC > Aparências. Salve como rascunho, confira a prévia e use Publicar atualizações depois da revisão.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'botao', 'botoes', 'cta', 'link de acao', 'posicao do botao', 'posicionar botao', 'alinhamento do botao' ),
			'guidance' => __( 'Para criar, editar, publicar, deixar em rascunho ou excluir um botão, abra Portal CAPTEC > Botões do site. Escolha a área, o texto, o destino, o estilo e a posição: padrão, esquerda, centro ou direita.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'rodape', 'links do rodape', 'informacoes do rodape', 'texto do rodape' ),
			'guidance' => __( 'Para alterar links e informações do rodapé, abra Portal CAPTEC > Rodapé. Cada item pode ser criado, editado, publicado, deixado em rascunho ou movido para a lixeira. Cores, tamanho e espaço do rodapé ficam em Aparências.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'indicador', 'indicadores', 'numero institucional', 'numeros institucionais' ),
			'guidance' => __( 'Para criar, editar ou excluir indicadores institucionais, abra Portal CAPTEC > Dados e cobertura. Os indicadores Clientes Atendidos, Estados Atendidos, Produtos Comercializados, Obras Atendidas e Toneladas Fornecidas ficam cadastrados e publicados. Preencha valores somente após validação da empresa.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'mapa', 'cobertura', 'estado', 'estados', 'disponivel para atendimento', 'mensagem de disponibilidade' ),
			'guidance' => __( 'Para configurar estados, a mensagem de disponibilidade ou revisar o mapa ampliado, abra Portal CAPTEC > Dados e cobertura. Estados definidos permanecem destacados após o clique. Os botões WhatsApp e Solicitar cotação do mapa são editados em Botões do site.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'pagina', 'paginas', 'navegacao', 'navegacao do site', 'menu principal', 'quem somos', 'empresa' ),
			'guidance' => __( 'Para organizar páginas, menu ou conteúdo de página, abra Portal CAPTEC > Páginas e menu. Quem somos reúne o institucional, Aplicações, Diferenciais e Processo; as páginas separadas Aplicações e Diferenciais foram removidas. A lista mostra o conteúdo salvo no WordPress e Editar conteúdo permite alterá-lo. Use Publicado/Rascunho para mostrar ou remover uma página do menu público.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'trabalhe conosco', 'curriculo', 'vaga', 'candidatura' ),
			'guidance' => __( 'Para ajustar Trabalhe conosco, abra Portal CAPTEC > Textos das páginas. O botão de currículo é editado em Botões do site. Salve como rascunho, confira a prévia e publique depois da revisão.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'pauta', 'pautas', 'carregar artigo', 'gerar artigo', 'categoria', 'imagem da pauta', 'imagem do artigo' ),
			'guidance' => __( 'Em Portal CAPTEC > Conteúdos, as pautas atuais mostram categoria e imagem relacionada. Ao carregar, o sistema cria um artigo em rascunho com categoria e imagem destacada. Ao editar o artigo, escolha uma categoria existente ou informe uma nova.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'produto', 'rr-1c', 'rr-2c', 'cap ', 'emulsao', 'asfalto' ),
			'guidance' => __( 'Para gerenciar produtos, abra Portal CAPTEC > Produtos. Você pode criar, editar, publicar, deixar em rascunho ou mover produtos para a lixeira. Informe ficha técnica somente depois de validada.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'aplicacao', 'aplicacoes' ),
			'guidance' => __( 'Para gerenciar aplicações, abra Portal CAPTEC > Aplicações. Defina título, linha de apoio, imagem, ordem e status Publicado/Rascunho. Os cards são exibidos na seção Aplicações da página Quem somos.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'filial', 'matriz', 'unidade', 'endereco', 'cnpj' ),
			'guidance' => __( 'Para atualizar matriz ou filiais, abra Portal CAPTEC > Matriz e filiais. Edite os dados e escolha Ativa/publicada ou Inativa/rascunho antes de salvar.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'cotacao', 'cotacoes', 'proposta' ),
			'guidance' => __( 'Para consultar solicitações, abra Portal CAPTEC > Cotações. Selecione um registro, altere a etapa do atendimento e salve uma anotação interna quando necessário.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'publicar atualizacoes', 'publicar alteracoes', 'rascunho', 'publicar configuracoes' ),
			'guidance' => __( 'Use Salvar rascunho nas configurações, abra Pré-visualizar portal, revise página e dispositivo e clique em Publicar atualizações somente depois da conferência. Produtos, páginas e outros itens usam seus próprios botões Publicado/Rascunho.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'previa', 'previsualizar', 'computador', 'tablet', 'celular', 'responsivo' ),
			'guidance' => __( 'Para revisar o portal antes de publicar, abra Portal CAPTEC > Pré-visualizar portal. Selecione a página desejada e alterne entre Computador, Tablet e Celular.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'manutencao', 'funcionalidade', 'desativar', 'ativar', 'visualizar funcionalidade' ),
			'guidance' => __( 'Para controlar funcionalidades ou o modo de manutenção, abra Portal CAPTEC > Funcionalidades. Use o botão Visualizar para abrir um pop-up com a página atual antes de salvar.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'analise', 'acessos', 'analytics', 'google analytics', 'trafego', 'cliques', 'permanencia' ),
			'guidance' => __( 'Para consultar acessos, abra Portal CAPTEC > Análise do portal. O dashboard local mostra visualizações, cliques e permanência após o consentimento de cookies analíticos. A configuração GA4 exige conta de serviço de leitura.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'privacidade', 'lgpd', 'cookie', 'pixel' ),
			'guidance' => __( 'Para LGPD e integrações, abra Portal CAPTEC > Integrações e LGPD. Informe links das políticas revisadas e identificadores aprovados antes de publicar.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'log', 'historico', 'atividades', 'atividade' ),
			'guidance' => __( 'Para consultar alterações, abra Portal CAPTEC > Log de atividades. O histórico identifica a ação, a pessoa usuária e data/hora, mantendo registros por até seis meses.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'manual', 'orientacoes', 'ajuda' ),
			'guidance' => __( 'Na janela do assistente, selecione Sim em “Deseja o manual de orientações do portal de administração?” para abrir o Manual do Portal CAPTEC em PDF.', 'captec-portal-admin' ),
		),
		array(
			'keywords' => array( 'cidade', 'municipio' ),
			'guidance' => __( 'No formulário Solicitar Cotação, selecione primeiro o estado. A lista de municípios será carregada automaticamente a partir da fonte pública do IBGE.', 'captec-portal-admin' ),
		),
	);
}

# Tráfego CAPTEC

Plugin de análise própria para o portal CAPTEC Asfaltos.

## O que mede

- visualizações de página;
- sessões técnicas únicas;
- cliques em links e botões;
- tempo de permanência por página;
- páginas mais acessadas;
- elementos mais clicados;
- atividade diária;
- domínios de origem.

## Privacidade

A coleta só começa após a pessoa visitante aceitar a categoria de cookies analíticos do portal. O plugin não registra endereço IP, nome, e-mail, conteúdo de formulários ou dados de cotações.

## Dashboard

Acesse **Portal CAPTEC > Tráfego do Portal**. Use os filtros Hoje, 7 dias, 30 dias, 90 dias, este ano ou intervalo personalizado.

## Retenção

Eventos de tráfego são excluídos automaticamente após 12 meses.

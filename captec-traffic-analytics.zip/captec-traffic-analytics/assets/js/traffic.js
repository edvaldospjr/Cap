/* Tráfego CAPTEC — coleta local de visualizações, cliques e tempo, somente após consentimento analítico. */
(function () {
  'use strict';
  var config = window.CaptecTraffic || {};
  var started = false;
  var startedAt = 0;
  var sentEngagement = false;

  function storageGet(key) { try { return window.localStorage.getItem(key); } catch (e) { return null; } }
  function storageSet(key, value) { try { window.localStorage.setItem(key, value); } catch (e) {} }
  function consented() { return storageGet('captec-cookie-consent') === 'all'; }
  function sessionId() {
    var now = Date.now();
    var raw = storageGet('captec-traffic-session');
    var data = null;
    try { data = raw ? JSON.parse(raw) : null; } catch (e) { data = null; }
    if (!data || !data.id || !data.last || now - data.last > 30 * 60 * 1000) {
      data = { id: 'ct_' + now.toString(36) + '_' + Math.random().toString(36).slice(2, 14), last: now };
    }
    data.last = now;
    storageSet('captec-traffic-session', JSON.stringify(data));
    return data.id;
  }
  function send(data) {
    if (!config.ajaxUrl || !config.action || !consented()) return;
    data.action = config.action;
    data.session = sessionId();
    data.page_path = config.pagePath || window.location.pathname || '/';
    data.page_title = config.pageTitle || document.title || '';
    data.referrer = document.referrer || '';
    var form = new FormData();
    Object.keys(data).forEach(function (key) { form.append(key, data[key]); });
    if (navigator.sendBeacon && navigator.sendBeacon(config.ajaxUrl, form)) {
      return;
    }
    if (window.fetch) {
      window.fetch(config.ajaxUrl, { method: 'POST', body: form, credentials: 'same-origin', keepalive: true }).catch(function () {});
    }
  }
  function elementLabel(target) {
    if (!target) return '';
    var text = (target.getAttribute && (target.getAttribute('aria-label') || target.getAttribute('title'))) || target.textContent || target.value || '';
    text = String(text).replace(/\s+/g, ' ').trim();
    if (!text && target.href) text = target.href;
    return text.slice(0, 220);
  }
  function sendEngagement() {
    if (!started || sentEngagement) return;
    var seconds = Math.round((Date.now() - startedAt) / 1000);
    if (seconds >= 3) {
      sentEngagement = true;
      send({ event_type: 'engagement', duration_seconds: Math.min(seconds, 7200) });
    }
  }
  function begin() {
    if (started || !consented()) return;
    started = true;
    startedAt = Date.now();
    send({ event_type: 'pageview', duration_seconds: 0 });
    document.addEventListener('click', function (event) {
      var target = event.target.closest ? event.target.closest('a,button,input[type="submit"],input[type="button"]') : null;
      if (!target) return;
      send({ event_type: 'click', element_label: elementLabel(target), duration_seconds: 0 });
    }, { passive: true });
    window.addEventListener('pagehide', sendEngagement, { passive: true });
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') sendEngagement(); }, { passive: true });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', begin);
  else begin();
  window.addEventListener('captec:analytics-consent', begin);
}());

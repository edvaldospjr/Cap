<?php
/**
 * Plugin Name: Tráfego CAPTEC
 * Description: Análise própria de visualizações, cliques e tempo de permanência para o portal CAPTEC, respeitando a escolha de cookies analíticos.
 * Version: 1.1.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: CAPTEC Asfaltos
 * Text Domain: captec-traffic-analytics
 */

defined( 'ABSPATH' ) || exit;

final class CAPTEC_Traffic_Analytics {
	const VERSION    = '1.1.0';
	const CAPABILITY = 'captec_manage_portal';
	const SLUG       = 'captec-traffic';
	const TABLE      = 'captec_traffic_event';

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'maybe_install' ), 5 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_tracker' ) );
		add_action( 'admin_menu', array( $this, 'register_menu' ), 30 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
		add_action( 'wp_ajax_nopriv_captec_traffic_event', array( $this, 'ajax_event' ) );
		add_action( 'wp_ajax_captec_traffic_event', array( $this, 'ajax_event' ) );
		add_action( 'wp_ajax_captec_traffic_report', array( $this, 'ajax_report' ) );
		add_action( 'wp_ajax_captec_traffic_health', array( $this, 'ajax_health' ) );
		add_action( 'captec_traffic_cleanup', array( $this, 'cleanup_events' ) );
	}

	public static function activate() {
		$administrator = get_role( 'administrator' );
		if ( $administrator ) {
			$administrator->add_cap( self::CAPABILITY );
		}
		self::install_table();
		if ( ! wp_next_scheduled( 'captec_traffic_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'captec_traffic_cleanup' );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( 'captec_traffic_cleanup' );
	}

	public static function install_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = $wpdb->prefix . self::TABLE;
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			session_hash char(64) NOT NULL,
			event_type varchar(24) NOT NULL,
			page_path varchar(255) NOT NULL,
			page_title varchar(255) NOT NULL DEFAULT '',
			element_label varchar(500) NOT NULL DEFAULT '',
			referrer_host varchar(255) NOT NULL DEFAULT '',
			duration_seconds int(10) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY session_hash (session_hash),
			KEY event_type (event_type),
			KEY page_path (page_path(120))
		) $charset;";
		dbDelta( $sql );
		update_option( 'captec_traffic_version', self::VERSION, false );
	}

	private function table() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	private function table_exists() {
		global $wpdb;
		$table = $this->table();
		return $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
	}

	public function maybe_install() {
		if ( get_option( 'captec_traffic_version' ) !== self::VERSION || ! $this->table_exists() ) {
			self::install_table();
		}
		if ( ! wp_next_scheduled( 'captec_traffic_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'captec_traffic_cleanup' );
		}
	}

	private function can_view() {
		return current_user_can( self::CAPABILITY ) || current_user_can( 'manage_options' );
	}

	public function enqueue_tracker() {
		if ( is_admin() || is_feed() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '/';
		$path = $path ? substr( sanitize_text_field( $path ), 0, 255 ) : '/';
		$script = plugin_dir_path( __FILE__ ) . 'assets/js/traffic.js';
		wp_enqueue_script( 'captec-traffic', plugin_dir_url( __FILE__ ) . 'assets/js/traffic.js', array(), file_exists( $script ) ? (string) filemtime( $script ) : self::VERSION, true );
		wp_localize_script( 'captec-traffic', 'CaptecTraffic', array(
			'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
			'action'    => 'captec_traffic_event',
			'pagePath'  => $path,
			'pageTitle' => wp_get_document_title(),
		) );
	}

	public function register_menu() {
		$parent = 'captec-portal';
		global $menu;
		$parent_exists = false;
		foreach ( (array) $menu as $item ) {
			if ( isset( $item[2] ) && $parent === $item[2] ) {
				$parent_exists = true;
				break;
			}
		}
		if ( $parent_exists ) {
			add_submenu_page( $parent, __( 'Tráfego do Portal', 'captec-traffic-analytics' ), __( 'Tráfego do Portal', 'captec-traffic-analytics' ), self::CAPABILITY, self::SLUG, array( $this, 'render_dashboard' ) );
		} else {
			add_menu_page( __( 'Tráfego CAPTEC', 'captec-traffic-analytics' ), __( 'Tráfego CAPTEC', 'captec-traffic-analytics' ), self::CAPABILITY, self::SLUG, array( $this, 'render_dashboard' ), 'dashicons-chart-area', 3 );
		}
	}

	public function enqueue_admin_assets( $hook ) {
		if ( false === strpos( $hook, self::SLUG ) ) {
			return;
		}
		$css = plugin_dir_path( __FILE__ ) . 'assets/css/traffic-admin.css';
		$js  = plugin_dir_path( __FILE__ ) . 'assets/js/traffic-admin.js';
		wp_enqueue_style( 'captec-traffic-admin', plugin_dir_url( __FILE__ ) . 'assets/css/traffic-admin.css', array(), file_exists( $css ) ? (string) filemtime( $css ) : self::VERSION );
		wp_enqueue_script( 'captec-traffic-admin', plugin_dir_url( __FILE__ ) . 'assets/js/traffic-admin.js', array(), file_exists( $js ) ? (string) filemtime( $js ) : self::VERSION, true );
		wp_localize_script( 'captec-traffic-admin', 'CaptecTrafficAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'captec_traffic_admin' ),
		) );
	}

	public function render_dashboard() {
		if ( ! $this->can_view() ) {
			wp_die( esc_html__( 'Você não tem permissão para visualizar a análise de tráfego.', 'captec-traffic-analytics' ) );
		}
		?>
		<div id="captec-traffic-dashboard" class="captec-traffic-dashboard"><div class="captec-traffic-loading"><strong>CAPTEC</strong><span><?php esc_html_e( 'Carregando análise de tráfego…', 'captec-traffic-analytics' ); ?></span></div></div>
		<?php
	}

	private function event_session_hash( $raw ) {
		return hash_hmac( 'sha256', sanitize_text_field( $raw ), wp_salt( 'auth' ) );
	}

	public function ajax_event() {
		$type = isset( $_POST['event_type'] ) ? sanitize_key( wp_unslash( $_POST['event_type'] ) ) : '';
		$allowed = array( 'pageview', 'engagement', 'click' );
		if ( ! in_array( $type, $allowed, true ) ) {
			wp_send_json_error( array( 'message' => 'Evento inválido.' ), 400 );
		}
		$session = isset( $_POST['session'] ) ? sanitize_text_field( wp_unslash( $_POST['session'] ) ) : '';
		if ( strlen( $session ) < 12 || strlen( $session ) > 128 ) {
			wp_send_json_error( array( 'message' => 'Sessão inválida.' ), 400 );
		}
		$path = isset( $_POST['page_path'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_POST['page_path'] ) ), PHP_URL_PATH ) : '/';
		$path = $path ? substr( sanitize_text_field( $path ), 0, 255 ) : '/';
		$title = isset( $_POST['page_title'] ) ? substr( sanitize_text_field( wp_unslash( $_POST['page_title'] ) ), 0, 255 ) : '';
		$label = isset( $_POST['element_label'] ) ? substr( sanitize_text_field( wp_unslash( $_POST['element_label'] ) ), 0, 500 ) : '';
		$duration = isset( $_POST['duration_seconds'] ) ? min( 7200, max( 0, absint( $_POST['duration_seconds'] ) ) ) : 0;
		$referrer = isset( $_POST['referrer'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_POST['referrer'] ) ), PHP_URL_HOST ) : '';
		$hash = $this->event_session_hash( $session );

		// Limita visualizações duplicadas no mesmo caminho e sessão a uma a cada 30 segundos.
		if ( 'pageview' === $type ) {
			$limit_key = 'captec_traffic_pv_' . md5( $hash . '|' . $path );
			if ( get_transient( $limit_key ) ) {
				wp_send_json_success();
			}
			set_transient( $limit_key, 1, 30 );
		}
		global $wpdb;
		$this->maybe_install();
		$wpdb->insert( $this->table(), array(
			'session_hash'     => $hash,
			'event_type'       => $type,
			'page_path'        => $path,
			'page_title'       => $title,
			'element_label'    => $label,
			'referrer_host'    => $referrer ? sanitize_text_field( $referrer ) : '',
			'duration_seconds' => $duration,
			'created_at'       => current_time( 'mysql', true ),
		), array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s' ) );
		wp_send_json_success();
	}

	private function admin_guard() {
		if ( ! check_ajax_referer( 'captec_traffic_admin', 'nonce', false ) || ! $this->can_view() ) {
			wp_send_json_error( array( 'message' => __( 'Sem permissão para consultar a análise.', 'captec-traffic-analytics' ) ), 403 );
		}
	}

	private function range( $period, $start = '', $end = '' ) {
		$now = current_time( 'timestamp', true );
		$period = sanitize_key( $period );
		$map = array(
			'today' => array( 'start' => gmdate( 'Y-m-d 00:00:00', $now ), 'end' => gmdate( 'Y-m-d 23:59:59', $now ), 'label' => __( 'Hoje', 'captec-traffic-analytics' ) ),
			'7days' => array( 'start' => gmdate( 'Y-m-d 00:00:00', $now - 6 * DAY_IN_SECONDS ), 'end' => gmdate( 'Y-m-d 23:59:59', $now ), 'label' => __( 'Últimos 7 dias', 'captec-traffic-analytics' ) ),
			'30days'=> array( 'start' => gmdate( 'Y-m-d 00:00:00', $now - 29 * DAY_IN_SECONDS ), 'end' => gmdate( 'Y-m-d 23:59:59', $now ), 'label' => __( 'Últimos 30 dias', 'captec-traffic-analytics' ) ),
			'90days'=> array( 'start' => gmdate( 'Y-m-d 00:00:00', $now - 89 * DAY_IN_SECONDS ), 'end' => gmdate( 'Y-m-d 23:59:59', $now ), 'label' => __( 'Últimos 90 dias', 'captec-traffic-analytics' ) ),
			'year'  => array( 'start' => gmdate( 'Y-01-01 00:00:00', $now ), 'end' => gmdate( 'Y-m-d 23:59:59', $now ), 'label' => __( 'Este ano', 'captec-traffic-analytics' ) ),
		);
		if ( 'custom' === $period && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $start ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $end ) && $start <= $end ) {
			return array( 'start' => $start . ' 00:00:00', 'end' => $end . ' 23:59:59', 'label' => $start . ' até ' . $end );
		}
		return isset( $map[ $period ] ) ? $map[ $period ] : $map['30days'];
	}

	private function report( $range ) {
		global $wpdb;
		$this->maybe_install();
		$table = $this->table();
		$where = $wpdb->prepare( 'created_at BETWEEN %s AND %s', $range['start'], $range['end'] );
		$totals = $wpdb->get_results( "SELECT event_type, COUNT(*) AS total, COUNT(DISTINCT session_hash) AS sessions, SUM(duration_seconds) AS seconds FROM $table WHERE $where GROUP BY event_type", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$summary = array( 'pageviews' => 0, 'sessions' => 0, 'clicks' => 0, 'engagement_seconds' => 0, 'engagement_events' => 0 );
		foreach ( $totals as $row ) {
			if ( 'pageview' === $row['event_type'] ) { $summary['pageviews'] = (int) $row['total']; $summary['sessions'] = (int) $row['sessions']; }
			if ( 'click' === $row['event_type'] ) { $summary['clicks'] = (int) $row['total']; }
			if ( 'engagement' === $row['event_type'] ) { $summary['engagement_seconds'] = (int) $row['seconds']; $summary['engagement_events'] = (int) $row['total']; }
		}
		$summary['average_seconds'] = $summary['engagement_events'] ? (int) round( $summary['engagement_seconds'] / $summary['engagement_events'] ) : 0;

		$page_rows = $wpdb->get_results( "SELECT page_path, MAX(page_title) AS page_title, event_type, COUNT(*) AS total, SUM(duration_seconds) AS seconds FROM $table WHERE $where GROUP BY page_path, event_type", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$pages = array();
		foreach ( $page_rows as $row ) {
			$key = $row['page_path'];
			if ( ! isset( $pages[ $key ] ) ) { $pages[ $key ] = array( 'page_path' => $key, 'page_title' => $row['page_title'], 'views' => 0, 'clicks' => 0, 'seconds' => 0, 'engagement_events' => 0 ); }
			if ( 'pageview' === $row['event_type'] ) { $pages[ $key ]['views'] = (int) $row['total']; }
			if ( 'click' === $row['event_type'] ) { $pages[ $key ]['clicks'] = (int) $row['total']; }
			if ( 'engagement' === $row['event_type'] ) { $pages[ $key ]['seconds'] = (int) $row['seconds']; $pages[ $key ]['engagement_events'] = (int) $row['total']; }
		}
		foreach ( $pages as &$page ) { $page['average_seconds'] = $page['engagement_events'] ? (int) round( $page['seconds'] / $page['engagement_events'] ) : 0; unset( $page['seconds'], $page['engagement_events'] ); }
		unset( $page );
		$pages = array_values( $pages );
		usort( $pages, static function( $a, $b ) { return $b['views'] <=> $a['views']; } );

		$clicks = $wpdb->get_results( "SELECT element_label, page_path, COUNT(*) AS total FROM $table WHERE $where AND event_type = 'click' AND element_label != '' GROUP BY element_label, page_path ORDER BY total DESC LIMIT 12", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$days = $wpdb->get_results( "SELECT DATE(created_at) AS date, SUM(CASE WHEN event_type = 'pageview' THEN 1 ELSE 0 END) AS views, SUM(CASE WHEN event_type = 'click' THEN 1 ELSE 0 END) AS clicks FROM $table WHERE $where GROUP BY DATE(created_at) ORDER BY date ASC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$referrers = $wpdb->get_results( "SELECT referrer_host, COUNT(*) AS total FROM $table WHERE $where AND event_type = 'pageview' AND referrer_host != '' GROUP BY referrer_host ORDER BY total DESC LIMIT 8", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array( 'range' => $range, 'summary' => $summary, 'pages' => $pages, 'clicks' => $clicks, 'days' => $days, 'referrers' => $referrers );
	}

	public function get_portal_report( $period = '30days', $start = '', $end = '' ) {
		return $this->report( $this->range( $period, $start, $end ) );
	}

	public function health() {
		global $wpdb;
		$this->maybe_install();
		$table = $this->table();
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$last = $wpdb->get_var( "SELECT created_at FROM $table ORDER BY created_at DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return array(
			'table_ready' => $this->table_exists(),
			'events'      => $count,
			'last_event'  => $last ? $last : '',
			'consent_note'=> __( 'A coleta começa após o consentimento de cookies analíticos.', 'captec-traffic-analytics' ),
		);
	}

	public function ajax_report() {
		$this->admin_guard();
		$period = isset( $_POST['period'] ) ? wp_unslash( $_POST['period'] ) : '30days';
		$start  = isset( $_POST['start'] ) ? sanitize_text_field( wp_unslash( $_POST['start'] ) ) : '';
		$end    = isset( $_POST['end'] ) ? sanitize_text_field( wp_unslash( $_POST['end'] ) ) : '';
		wp_send_json_success( array( 'report' => $this->report( $this->range( $period, $start, $end ) ) ) );
	}

	public function ajax_health() {
		$this->admin_guard();
		wp_send_json_success( array( 'health' => $this->health() ) );
	}

	public function cleanup_events() {
		global $wpdb;
		if ( ! $this->table_exists() ) { return; }
		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-12 months' ) );
		$table = $this->table();
		$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE created_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
}

register_activation_hook( __FILE__, array( 'CAPTEC_Traffic_Analytics', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CAPTEC_Traffic_Analytics', 'deactivate' ) );
CAPTEC_Traffic_Analytics::instance();
